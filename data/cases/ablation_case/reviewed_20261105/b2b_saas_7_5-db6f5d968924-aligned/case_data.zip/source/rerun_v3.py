"""Isolated AWM case reruns. No writes to source data or shared method code."""
import argparse, copy, fcntl, hashlib, importlib.util, json, os, re, shutil, sqlite3, sys, traceback
from pathlib import Path
import httpx
import time
from concurrent.futures import ThreadPoolExecutor
from fastapi.testclient import TestClient
from awm.core.reset import reset_single_database

BASE = Path('/mnt/genming/Arctic-AWM-BitDistiller-full')
DATA = BASE/'arctic_quant/common/data/awm_source'
ROOT = Path(os.environ.get('CASE_ROOT','/mnt/genming/case-rerun-20261103/cases'))
SOURCE = Path('/mnt/genming/case-selection-20261101')

def dump(p,x):
    p=Path(p);p.parent.mkdir(parents=True,exist_ok=True)
    tmp=p.with_suffix(p.suffix+'.tmp');tmp.write_text(json.dumps(x,ensure_ascii=False,indent=2,default=str));tmp.replace(p)

def load(p): return json.loads(Path(p).read_text())
def case_paths():
    keys=set(json.loads(os.environ.get('CASE_KEYS','[]')))
    return [p for p in sorted(ROOT.glob('*/prepared.json')) if not keys or load(p)['task_key'] in keys]
def digest(p): return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def rows(name):
    with (DATA/name).open() as f:
        for l in f: yield json.loads(l)

def normalize(m):
    m=copy.deepcopy(m);out={'role':m['role'],'content':m.get('content') or ''}
    if m.get('tool_call_id'):out['tool_call_id']=m['tool_call_id']
    if m.get('tool_calls'):
        out['tool_calls']=[]
        for c in m['tool_calls']:
            f=c.get('function',c);a=f.get('arguments',{})
            out['tool_calls'].append({'id':c['id'],'type':'function','function':{'name':f['name'],'arguments':a if isinstance(a,str) else json.dumps(a)}})
    return out

class Environment:
    def __init__(self,scenario,db,work):
        original=next(x['full_code'] for x in rows('gen_envs.jsonl') if x['scenario']==scenario)
        lines=[]
        for line in original.splitlines():
            if 'create_engine(' in line:
                line=line.split('create_engine(')[0]+f'create_engine("sqlite:///{db}", connect_args={{"check_same_thread": False}})'
            lines.append(line)
        p=work/'environment.py';p.write_text('\n'.join(lines))
        name='case_env_'+hashlib.sha256(str(p).encode()).hexdigest()[:16]
        spec=importlib.util.spec_from_file_location(name,p);mod=importlib.util.module_from_spec(spec);sys.modules[name]=mod;spec.loader.exec_module(mod)
        self.mod=mod
        mod.app.router.routes.sort(key=lambda r:(sum('{' in x for x in getattr(r,'path','').split('/')),-len(getattr(r,'path',''))))
        self.client=TestClient(mod.app,raise_server_exceptions=False)
        self.openapi=mod.app.openapi()
        self.routes={v['operationId']:(path,method,v) for path,ops in self.openapi['paths'].items() for method,v in ops.items() if isinstance(v,dict) and 'operationId' in v}
        dump(work/'openapi.json',self.openapi)

    def execute(self,name,args):
        name=name.removeprefix('mcp_server_')
        if isinstance(args,str):
            try:args=json.loads(args)
            except ValueError:return {'error':'Invalid JSON arguments','executed':False}
        if name not in self.routes:return {'error':'Unknown tool '+name,'executed':False}
        path,method,op=self.routes[name];params={};body=dict(args);headers={}
        for p in op.get('parameters',[]):
            key=p['name']
            if key not in args:continue
            val=body.pop(key)
            if p['in']=='path':path=path.replace('{'+key+'}',str(val))
            elif p['in']=='query':params[key]=val
            elif p['in']=='header':headers[key]=str(val)
        kw={'params':params,'headers':headers}
        if op.get('requestBody'):kw['json']=body.get('body',body)
        response=self.client.request(method.upper(),path,**kw)
        try:result=response.json()
        except ValueError:result={'body':response.text}
        return {'executed':True,'status_code':response.status_code,'tool':name,'arguments':args,'response':result}

def prepare(limit):
    store=BASE/'arctic_quant/gemma4_12b/q_resteer_w4a16/skill_store/events.jsonl'
    records={}
    for l in store.open():
        r=json.loads(l)
        for s in r.get('steer_steps',[]):records[s['step_id']]=(r,s)
    for candidate in load(os.environ.get('CASE_CANDIDATES','/mnt/genming/case-rerun-20261103/candidates.json'))[:limit]:
        work=ROOT/candidate['task_key'].replace(':','_');work.mkdir(parents=True,exist_ok=True)
        if (work/'prepared.json').exists():continue
        try:
            record,step=records[candidate['step_id']];scenario,tid=candidate['task_key'].split(':')
            raw=load(Path(candidate['before'])/'trajectory.json')
            initial=reset_single_database(str(DATA/'gen_db.jsonl'),str(DATA/'gen_sample.jsonl'),scenario,str(work/'reset'))
            shutil.copy2(initial,work/'initial.db');shutil.copy2(initial,work/'pre_state.db')
            env=Environment(scenario,work/'pre_state.db',work)
            messages=[];prefix=[];turn=0
            for m in raw['messages']:
                if m['role']=='assistant':
                    if turn==int(step['assistant_turn']):break
                    turn+=1
                if m['role']=='tool':continue
                n=normalize(m);messages.append(n)
                for c in n.get('tool_calls',[]):
                    f=c['function'];result=env.execute(f['name'],f['arguments']);prefix.append(result)
                    # Rebuild observations using THIS saved initial state, never stale timestamps/IDs.
                    messages.append({'role':'tool','tool_call_id':c['id'],'content':json.dumps(result.get('response',result),ensure_ascii=False)})
                    if not result.get('executed') or result.get('status_code',500)>=400:raise RuntimeError('Prefix replay failed; candidate requires a different verified intervention point')
            verifier=next(x for x in rows('gen_verifier.pure_code.jsonl') if x['scenario']==scenario and int(x['task_idx'])==int(tid))
            (work/'task_verifier.py').write_text(verifier['verification']['code'])
            tools=[{'type':'function','function':{'name':t['name'],'description':t.get('description',''),'parameters':t['inputSchema']}} for t in raw['native_tools']]
            reference=load(Path(candidate['teacher_reference'])/'trajectory.json')
            payload={'task':raw['task'],'current_context':messages,'failed_trajectory':raw['messages'],'successful_reference':reference['messages'],'tools':raw['native_tools']}
            dump(work/'analysis_context.json',payload);dump(work/'tools.json',tools);dump(work/'prefix_replay.json',prefix);dump(work/'context.json',messages)
            dump(work/'prepared.json',{'task_key':candidate['task_key'],'scenario':scenario,'task_id':int(tid),'intervention_turn':step['assistant_turn'],'initial_sha256':digest(work/'initial.db'),'pre_state_sha256':digest(work/'pre_state.db'),'verifier_sha256':digest(work/'task_verifier.py'),'historical_reference_only':True,'student_checkpoint':str(BASE/'arctic_quant/gemma4_12b/q_resteer_w4a16/checkpoints/initial-clipped-int4-g64-awq-runtime')})
            print('PREPARED',candidate['task_key'],flush=True)
        except Exception as e:
            dump(work/'prepare_error.json',{'error':str(e),'traceback':traceback.format_exc()});print('PREPARE_ERROR',candidate['task_key'],str(e),flush=True)

def request(payload,dest,endpoint,headers=None):
    dump(dest/'request.json',payload)
    for attempt in range(3):
        try:
            timeout=httpx.Timeout(connect=30,read=float(os.environ.get('CASE_LLM_READ_TIMEOUT', '1200')),write=60,pool=30)
            response=httpx.post(endpoint+'/chat/completions',json=payload,headers=headers,timeout=timeout,trust_env=False)
            if response.status_code>=400:
                dump(dest/f'http-error-{attempt}.json',{'status':response.status_code,'body':response.text})
            response.raise_for_status();out=response.json();dump(dest/'response.json',out)
            return out
        except (httpx.TransportError,httpx.HTTPStatusError) as e:
            dump(dest/f'transport-error-{attempt}.json',{'type':type(e).__name__,'error':str(e)})
            retry=isinstance(e,httpx.TransportError) or e.response.status_code in [408,429,500,502,503,504]
            if not retry or attempt==2:raise
            time.sleep(3*(attempt+1))

def locked_call(fn,p,variant,phase):
    dest=p.parent/variant;dest.mkdir(exist_ok=True)
    with open(dest/(phase+'.lock'),'w') as lock:
        fcntl.flock(lock,fcntl.LOCK_EX)
        return fn(p)

def extract_first_guidance(text):
    decoder=json.JSONDecoder();required=['precondition','decision_rule','expected_transition','recovery_check']
    for match in re.finditer(r'\{',text):
        try:obj,n=decoder.raw_decode(text[match.start():])
        except ValueError:continue
        if isinstance(obj,dict) and all(isinstance(obj.get(k),str) and obj[k].strip() for k in required):
            start=match.start();end=start+n
            return text[start:end],{'rule':'first complete object with four nonempty string fields; identical rule for all structured advisors','start':start,'end':end,'discarded_suffix_chars':len(text)-end}
    raise ValueError('No complete four-field guidance in final content; excluded, not a model failure')

def analyze(variant,endpoint):
    headers=None
    if variant=='external_structured':
        import tomllib
        config=tomllib.loads(Path('/mnt/genming/.codex/config.toml').read_text())
        auth=load('/mnt/genming/.codex/auth.json')
        endpoint=config['openai_base_url'].rstrip('/')
        headers={'Authorization':'Bearer '+auth['OPENAI_API_KEY']}
    def one(p):
        work=p.parent;dest=work/variant
        if (dest/'guidance.json').exists():return
        dest.mkdir(exist_ok=True)
        try:
            context=load(work/'analysis_context.json')
            prompt='Analyze the current decision using the task, environment observations and successful reference. Do not label a valid alternative erroneous merely because its action differs. Give a short procedural steer that helps finish the task. Do not fabricate environment prerequisites. '
            prompt += 'Give concise free-form prose.' if variant=='teacher_freeform' else 'Return JSON fields precondition, decision_rule, expected_transition, recovery_check.'
            payload={'model':'case-model','messages':[{'role':'system','content':prompt},{'role':'user','content':json.dumps(context,ensure_ascii=False)}],'temperature':0,'seed':42,'max_tokens':8192,'chat_template_kwargs':{'enable_thinking':False}}
            if variant=='external_structured':
                payload['model']='gpt-5.6-sol'
                for k in ['stop_token_ids','chat_template_kwargs','seed']:payload.pop(k,None)
            cached=(dest/'response.json').exists() and (dest/'request.json').exists() and load(dest/'request.json')==payload
            out=load(dest/'response.json') if cached else request(payload,dest,endpoint,headers)
            choice=out['choices'][0];text=choice['message'].get('content') or ''
            extraction=None
            if variant=='teacher_freeform':
                if choice['finish_reason']=='length' or not text.strip():raise RuntimeError('Incomplete freeform guidance: '+choice['finish_reason'])
            else:
                text,extraction=extract_first_guidance(text)
            dump(dest/'guidance.json',{'text':text,'variant':variant,'finish_reason':choice['finish_reason'],'analysis_protocol':'v3_first_complete_json_uniform','max_tokens':8192,'extraction':extraction,'cached_raw_response':cached,'raw_response_sha256':digest(dest/'response.json')})
            print('GUIDANCE',variant,work.name,flush=True)
        except Exception as e:
            dump(dest/'analysis_error.json',{'error':str(e),'traceback':traceback.format_exc()});print('ANALYSIS_ERROR',variant,work.name,str(e),flush=True)

    with ThreadPoolExecutor(max_workers=int(os.environ.get('CASE_WORKERS','2'))) as pool:
        list(pool.map(lambda p: locked_call(one,p,variant,'analyze'),case_paths()))

def rollout(variant,endpoint):
    def one(p):
        work=p.parent;dest=work/variant/'student'
        if (dest/'result.json').exists():return
        if variant!='unsteered' and not (work/variant/'guidance.json').exists():return
        dest.mkdir(parents=True,exist_ok=True)
        try:
            meta=load(p);shutil.copy2(work/'initial.db',dest/'initial.db');shutil.copy2(work/'pre_state.db',dest/'final.db')
            assert digest(dest/'final.db')==meta['pre_state_sha256']
            env=Environment(meta['scenario'],dest/'final.db',dest)
            messages=load(work/'context.json');tools=load(work/'tools.json')
            if variant!='unsteered':messages[0]['content']+='\n\nProcedural guidance. Independently choose and execute actions:\n'+load(work/variant/'guidance.json')['text']
            events=[];answer='';finish='turn_limit'
            for turn in range(32):
                payload={'model':'case-model','messages':messages,'tools':tools,'temperature':0,'seed':42,'max_tokens':8192,'stop_token_ids':[1,50,106],'chat_template_kwargs':{'enable_thinking':True}}
                out=request(payload,dest/f'turn-{turn:03}',endpoint);choice=out['choices'][0];m=choice['message'];messages.append(normalize(m))
                if choice['finish_reason']=='length':finish='length';break
                calls=m.get('tool_calls') or []
                if not calls:answer=m.get('content') or '';finish='final_response';break
                for c in calls:
                    f=c['function'];res=env.execute(f['name'],f['arguments']);events.append(res)
                    messages.append({'role':'tool','tool_call_id':c['id'],'content':json.dumps(res.get('response',res),ensure_ascii=False)})
                dump(dest/'trajectory.json',{'messages':messages,'execution':events})
            dump(dest/'trajectory.json',{'messages':messages,'execution':events})
            ns={};exec((work/'task_verifier.py').read_text(),ns)
            result=ns['verify_task_completion'](str(dest/'initial.db'),str(dest/'final.db'),answer)
            dump(dest/'result.json',{'task':meta['task_key'],'variant':variant,'finish':finish,'turns':turn+1,'verification':result,'pre_state_sha256':meta['pre_state_sha256'],'student_checkpoint':meta['student_checkpoint'],'protocol':'v3_first_complete_json_student_execution_unchanged','has_http_500':any(e.get('status_code',0)>=500 for e in events)})
            print('RESULT',meta['task_key'],variant,finish,result,flush=True)
        except Exception as e:
            dump(dest/'infrastructure_error.json',{'error':str(e),'traceback':traceback.format_exc()});print('ROLLOUT_ERROR',work.name,variant,str(e),flush=True)

    with ThreadPoolExecutor(max_workers=int(os.environ.get('CASE_WORKERS','2'))) as pool:
        list(pool.map(lambda p: locked_call(one,p,variant,'rollout'),case_paths()))

if __name__=='__main__':
    a=argparse.ArgumentParser();a.add_argument('phase',choices=['prepare','analyze','rollout']);a.add_argument('--variant');a.add_argument('--endpoint',default='http://127.0.0.1:18951/v1');a.add_argument('--limit',type=int,default=20);args=a.parse_args()
    ROOT.mkdir(exist_ok=True)
    if args.phase=='prepare':prepare(args.limit)
    elif args.phase=='analyze':analyze(args.variant,args.endpoint)
    else:rollout(args.variant,args.endpoint)
