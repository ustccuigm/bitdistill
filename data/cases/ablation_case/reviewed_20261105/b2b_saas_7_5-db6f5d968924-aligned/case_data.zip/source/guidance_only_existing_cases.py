"""Vary the guidance while keeping the student decoder fixed and deterministic.

Post-guidance identical rendered contexts cannot establish a guidance contrast.
All proposed failures remain provisional until their actual state is reviewed.
"""
import copy
import fcntl
import hashlib
import json
from pathlib import Path
import time
import traceback
from concurrent.futures import ThreadPoolExecutor

import httpx
import balanced_existing_gemma_cases as b

m=b.m
R=Path('/mnt/genming/ablation-guidance-only-followup-20261105')
GSEEDS=[42,43,44,45]


def request(payload,dest,endpoint,headers=None):
    payload=copy.deepcopy(payload)
    if 'sampled-guidance' in Path(dest).parts:
        payload['temperature']=.6
        if endpoint in [m.TEACHER,m.STUDENT]:payload['seed']=int(Path(dest).name.split('-')[-1])
    return b.request(payload,dest,endpoint,headers)


def fixed_actor(messages,tools,dest,seed,guidance=''):
    submitted=copy.deepcopy(messages)
    if guidance:submitted[0]['content']+='\n\nLocal steering for this response only:\n'+guidance
    payload=dict(model='case-model',messages=submitted,tools=tools,temperature=0.0,seed=42,
        max_tokens=32768,stop_token_ids=[49,106],add_generation_prompt=True,min_tokens=16,
        chat_template_kwargs={'enable_thinking':True})
    raw=b.request(payload,dest,m.STUDENT)
    choice=raw['choices'][0];msg=choice['message']
    if choice['finish_reason']=='length':raise ValueError('Truncated actor output excluded')
    if not msg.get('tool_calls') and not (msg.get('content') or '').strip():raise ValueError('Empty output excluded')
    return m.normalize(msg)


def rendered_identity(sample):
    p=Path(sample)/'turn-001/request.json'
    if not p.exists():return None
    req=m.load(p)
    payload={k:req[k] for k in ['model','messages','tools','chat_template_kwargs','add_generation_prompt'] if k in req}
    response=httpx.post(m.STUDENT.removesuffix('/v1')+'/tokenize',json=payload,timeout=60,trust_env=False)
    response.raise_for_status();info=response.json()
    if info.get('tokens') is None:raise ValueError('Rendered-token audit unavailable')
    return hashlib.sha256(json.dumps(info['tokens']).encode()).hexdigest()


def reference_tools(case):
    receipt=m.load(case/'reference-alignment/receipt.json')
    turn=receipt['alignment']['reference_turn']
    events=m.load(case/'reference-alignment'/turn/'execution.json')
    return [e['tool'] for e in events]


def branch(case,role,common,ours=None):
    history=[];expected_tools=reference_tools(case)
    for gseed in GSEEDS:
        out=case/'sampled-guidance'/role/f'guide-{gseed}'
        b.emit('guidance_sample',case=case.name,variant=role,guidance_seed=gseed)
        try:
            m.advisor(case,role,out,common.get('retry_feedback',[]))
            assert b.evidence(out)==common,'Guidance sources must receive the same fixed evidence'
            record=b.rollout(case,role+f'/guide-{gseed}',out/'guidance.json',42)
            if record is None:continue
            record['guidance_seed']=gseed
            record['actor_temperature']=0.0
            record['guide_temperature']=.6
            first=m.load(Path(record['sample'])/'turn-000/execution.json')
            actual_tools=[e['tool'] for e in first]
            # A same-operation mismatch is only a candidate: it may still be a
            # valid alternative value, which the manual reviewer must reject.
            same_operation_mismatch=(not record['local_accepted'] and bool(first) and actual_tools==expected_tools)
            record['same_operation_local_mismatch_candidate']=same_operation_mismatch
            eligible=(record['local_accepted'] and record['whole_task_passed'] and record['unsteered_requests']>0) if role=='teacher_structured' else (
                not record['whole_task_passed'] or record['actual_first_tool_rejected'] or same_operation_mismatch)
            if eligible and role!='teacher_structured' and ours:
                own_hash=rendered_identity(ours['selected']['sample'])
                control_hash=rendered_identity(record['sample'])
                neutral=own_hash is not None and own_hash==control_hash
                record['post_steer_context_audit']=dict(method=own_hash,control=control_hash,identical=neutral)
                if neutral:
                    record['not_a_guidance_contrast']=True
                    eligible=False
            history.append(record)
            m.dump(case/'sampled-outcomes'/role/'all-trials.json',history)
            if eligible:return dict(found=True,selected=record,history=history)
        except b.ApprovedTargetReached:raise
        except Exception as exc:
            m.dump(out/'excluded-error.json',dict(error=str(exc),traceback=traceback.format_exc(),excluded_not_a_semantic_failure=True))
    return dict(found=False,history=history)


def run(name):
    if b.target_reached():return
    case=R/'cases'/name
    if (case/'comparison.json').exists():return
    try:
        case,tguide,common=b.copy_case(name);b.revalidate_reference(case)
        ours=branch(case,'teacher_structured',common);controls={};audits={}
        if ours['found']:
            for index,role in enumerate(['teacher_freeform','student_structured','external_structured']):
                controls[role]=branch(case,role,common,ours)
                count=sum(v['found'] for v in controls.values())
                if count>=2 or count+(2-index)<2:break
            if sum(v['found'] for v in controls.values())>=2:
                for role,record in {'teacher_structured':ours['selected'],**{k:v['selected'] for k,v in controls.items() if v['found']}}.items():
                    audits[role]=b.audit(case,record,role)
        qualified=ours['found'] and sum(v['found'] for v in controls.values())>=2
        m.dump(case/'comparison.json',dict(task=m.load(case/'protocol.json')['task'],qualified=qualified,
            ours=ours,controls=controls,replay_audits=audits,manual_quality_review_required=qualified,
            actor_temperature=0.0,actor_seed=42,guidance_temperature=.6,guidance_seed_budget=GSEEDS,
            same_evidence_for_every_guidance_source=True,
            candidate_local_mismatches_require_semantic_review=True,
            post_guidance_identical_contexts_excluded_from_contrasts=True,
            no_aggregate_performance_claim=True))
    except b.ApprovedTargetReached:b.emit('approved_target_reached',case=name);return
    except Exception as exc:m.dump(case/'needs-review.json',dict(error=str(exc),traceback=traceback.format_exc(),excluded_not_a_model_failure=True))
    with b.LOCK:
        rows=[m.load(p) for p in (R/'cases').glob('*/comparison.json')]
        m.dump(R/'progress.json',dict(completed=len(rows),replay_verified_candidates=[v['task'] for v in rows if v['qualified']],manual_quality_review_required=True))


def viable_cases():
    candidates=[]
    for path in sorted(b.SOURCE.glob('*/ablation-outcome.json')):
        record=m.load(path);own=record.get('ours',{})
        if own.get('local_status')=='pass' and (own.get('final_verification') or {}).get('result')=='complete':
            candidates.append((path.parent.name,record['task']))
    # Prefer aligned current checkpoints, then try other existing versions only
    # when the fixed reference of that task cannot actually be revalidated.
    candidates.sort(key=lambda v:(not ('aligned' in v[0]),not ('current-policy' in v[0]),v[1]))
    selected=[];seen=set()
    for name,task in candidates:
        if task in seen or task in m.OLD_TASKS:continue
        if task=='billing_payments_3:5':
            m.dump(R/'reference-exclusions'/(name+'.json'),dict(reason='Remaining trial-related subgoal requires separate manual audit; not used in this case batch.'))
            continue
        if b.target_reached():break
        try:
            b.emit('revalidating_existing_reference',case=name)
            case,_,_=b.copy_case(name);b.revalidate_reference(case)
            selected.append(name);seen.add(task)
            m.dump(R/'validated-queue.json',dict(cases=selected,unique_tasks=len(selected),only_existing_measured_cases=True))
            yield name
        except Exception as exc:
            m.dump(R/'reference-exclusions'/(name+'.json'),dict(error=str(exc),traceback=traceback.format_exc(),not_a_qualified_case=True))
    m.dump(R/'validated-queue.json',dict(cases=selected,unique_tasks=len(selected),only_existing_measured_cases=True))


def main():
    R.mkdir(parents=True,exist_ok=True)
    lock=(R/'controller.lock').open('w');fcntl.flock(lock,fcntl.LOCK_EX | fcntl.LOCK_NB)
    b.R=R;m.R=R;b.ACTOR_TEMPERATURE=0.0;b.actor=fixed_actor;m.cached_request=request
    m.dump(R/'protocol.json',dict(source='existing measured Gemma recovery checkpoints',
        actor_temperature=0.0,actor_seed=42,guidance_temperature=.6,guidance_seeds=GSEEDS,
        thinking=True,requested_max_tokens=32768,
        actor_task_prompt_state_and_verifier_unchanged=True,
        all_guidance_variants_share_evidence_and_sampling_budget=True,
        same_post_steer_context_cannot_establish_a_guidance_effect=True,
        local_mismatch_is_a_candidate_not_automatic_semantic_failure=True,
        manual_review_required_before_counting=True,stop_at_manually_approved_cases=10))
    with ThreadPoolExecutor(max_workers=2) as pool:
        futures=[]
        for name in viable_cases():
            if b.target_reached():break
            futures.append(pool.submit(run,name))
        for future in futures:future.result()
    b.emit('guidance_only_followup_complete')


if __name__=='__main__':main()
