def verify_task_completion(initial_db_path: str, final_db_path: str, final_answer: str | None = None) -> dict:
    import sqlite3
    
    def safe_query(db_path: str, query: str, params: tuple = ()) -> list:
        try:
            conn = sqlite3.connect(f"file:{db_path}?mode=ro", uri=True)
            cursor = conn.cursor()
            cursor.execute(query, params)
            results = cursor.fetchall()
            conn.close()
            return results
        except Exception:
            return []
    
    # Step 1: Get location_id for 'Uptown Bistro'
    location_result = safe_query(final_db_path, "SELECT id FROM locations WHERE name = ?", ("Uptown Bistro",))
    if not location_result:
        return {"result": "others"}
    location_id = location_result[0][0]
    
    # Step 2: Get menu_item_id for 'Grilled Salmon with Quinoa'
    menu_item_result = safe_query(final_db_path, "SELECT id FROM menu_items WHERE display_name = ?", ("Grilled Salmon with Quinoa",))
    if not menu_item_result:
        return {"result": "others"}
    menu_item_id = menu_item_result[0][0]
    
    # Step 3: Check location_menu_items for override_selling_price = 28.0
    # We need to find a record with this location, menu_item, and override price
    lmi_query = """
        SELECT id, override_selling_price 
        FROM location_menu_items 
        WHERE location_id = ? AND menu_item_id = ? AND override_selling_price IS NOT NULL
    """
    lmi_results = safe_query(final_db_path, lmi_query, (location_id, menu_item_id))
    
    # Filter to find one with price 28.0 (checking float equality with tolerance)
    matching_lmi = [r for r in lmi_results if r[1] is not None and abs(r[1] - 28.0) < 0.01]
    if not matching_lmi:
        return {"result": "others"}
    
    location_menu_item_id = matching_lmi[0][0]
    
    # Step 4: Check availability windows - must have exactly Friday(4), Saturday(5), Sunday(6) with 17:00-22:00
    availability_query = """
        SELECT day_of_week, start_time, end_time 
        FROM location_menu_item_availability 
        WHERE location_menu_item_id = ?
        ORDER BY day_of_week
    """
    availability_results = safe_query(final_db_path, availability_query, (location_menu_item_id,))
    
    # Must have exactly 3 records
    if len(availability_results) != 3:
        return {"result": "others"}
    
    # Verify each day and time
    expected_windows = [
        (4, "17:00", "22:00"),  # Friday
        (5, "17:00", "22:00"),  # Saturday
        (6, "17:00", "22:00")   # Sunday
    ]
    
    for i, (expected_day, expected_start, expected_end) in enumerate(expected_windows):
        if i >= len(availability_results):
            return {"result": "others"}
        
        actual_day, actual_start, actual_end = availability_results[i]
        
        # Check day matches
        if actual_day != expected_day:
            return {"result": "others"}
        
        # Check times match (normalize format)
        if actual_start != expected_start or actual_end != expected_end:
            return {"result": "others"}
    
    # Step 5: Verify this represents a change from initial state
    # Check if the override price or availability windows are different in initial DB
    initial_lmi = safe_query(initial_db_path, lmi_query, (location_id, menu_item_id))
    initial_matching = [r for r in initial_lmi if r[1] is not None and abs(r[1] - 28.0) < 0.01]
    
    if initial_matching:
        # Price override already existed, check if availability changed
        initial_lmi_id = initial_matching[0][0]
        initial_availability = safe_query(initial_db_path, availability_query, (initial_lmi_id,))
        
        # If availability is exactly the same, no change was made
        if len(initial_availability) == 3:
            all_same = True
            for i, (expected_day, expected_start, expected_end) in enumerate(expected_windows):
                if i < len(initial_availability):
                    actual_day, actual_start, actual_end = initial_availability[i]
                    if actual_day != expected_day or actual_start != expected_start or actual_end != expected_end:
                        all_same = False
                        break
            if all_same:
                # No change detected - task may not have been executed
                pass  # We'll still consider it complete if current state matches requirements
    
    # All checks passed
    return {"result": "complete"}