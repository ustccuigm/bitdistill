from fastapi import FastAPI, Query, Path, Body
from pydantic import BaseModel, Field, ConfigDict
from typing import Optional, List, Dict
from sqlalchemy import create_engine, Column, Integer, String, DateTime, Text, ForeignKey, UniqueConstraint, Index, Date, Float, CheckConstraint
from sqlalchemy.orm import declarative_base, relationship, sessionmaker
from datetime import datetime
import os

database_url = os.getenv("DATABASE_PATH", "sqlite:///outputs/databases/chefcraft_cloud_menu_studio.db")
engine = create_engine("sqlite:////mnt/genming/ablation-history-expanded-20261104/cases/b2b_saas_7_5-db6f5d968924-aligned/reference-search-0/final.db", connect_args={"check_same_thread": False})
SessionLocal = sessionmaker(bind=engine, autoflush=False, autocommit=False)
Base = declarative_base()

class User(Base):
    __tablename__ = "users"
    id = Column(Integer, primary_key=True)
    username = Column(Text, nullable=False, unique=True)
    email = Column(Text, nullable=False, unique=True)
    full_name = Column(Text)
    profile_json = Column(Text)
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime)

class Supplier(Base):
    __tablename__ = "suppliers"
    id = Column(Integer, primary_key=True)
    name = Column(Text, nullable=False, unique=True)
    contact_info = Column(Text)
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime)

class Ingredient(Base):
    __tablename__ = "ingredients"
    id = Column(Integer, primary_key=True)
    name = Column(Text, nullable=False, unique=True)
    storage_type = Column(Text, nullable=False)
    base_unit = Column(Text, nullable=False)
    unit_cost = Column(Float, nullable=False)
    allergen_flags = Column(Text)
    is_leaf_lettuce = Column(Integer, nullable=False, default=0)
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime)

class IngredientSupplier(Base):
    __tablename__ = "ingredient_suppliers"
    id = Column(Integer, primary_key=True)
    ingredient_id = Column(Integer, ForeignKey("ingredients.id", ondelete="CASCADE"), nullable=False)
    supplier_id = Column(Integer, ForeignKey("suppliers.id", ondelete="CASCADE"), nullable=False)
    supplier_sku = Column(Text)
    unit_cost = Column(Float)
    price_list_id = Column(Integer, ForeignKey("price_lists.id", ondelete="SET NULL"))
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime)

class PriceList(Base):
    __tablename__ = "price_lists"
    id = Column(Integer, primary_key=True)
    name = Column(Text, nullable=False, unique=True)
    region = Column(Text)
    start_date = Column(Date)
    end_date = Column(Date)
    notes = Column(Text)
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime)

class Recipe(Base):
    __tablename__ = "recipes"
    id = Column(Integer, primary_key=True)
    name = Column(Text, nullable=False, unique=True)
    yield_quantity = Column(Float, nullable=False)
    yield_unit = Column(Text, nullable=False)
    prep_time_minutes = Column(Integer)
    active = Column(Integer, nullable=False, default=1)
    created_by = Column(Integer, ForeignKey("users.id"))
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime)

class RecipeIngredientLine(Base):
    __tablename__ = "recipe_ingredient_lines"
    id = Column(Integer, primary_key=True)
    recipe_id = Column(Integer, ForeignKey("recipes.id", ondelete="CASCADE"), nullable=False)
    ingredient_id = Column(Integer, ForeignKey("ingredients.id"), nullable=False)
    position = Column(Integer, nullable=False)
    quantity = Column(Float, nullable=False)
    unit = Column(Text, nullable=False)
    line_allergen_flags = Column(Text)
    notes = Column(Text)
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime)

class RecipeStep(Base):
    __tablename__ = "recipe_steps"
    id = Column(Integer, primary_key=True)
    recipe_id = Column(Integer, ForeignKey("recipes.id", ondelete="CASCADE"), nullable=False)
    step_number = Column(Integer, nullable=False)
    description = Column(Text, nullable=False)
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime)

class MenuItem(Base):
    __tablename__ = "menu_items"
    id = Column(Integer, primary_key=True)
    internal_name = Column(Text, nullable=False, unique=True)
    recipe_id = Column(Integer, ForeignKey("recipes.id"))
    display_name = Column(Text, nullable=False)
    menu_description = Column(Text)
    base_selling_price = Column(Float)
    active = Column(Integer, nullable=False, default=1)
    food_cost_percent = Column(Float)
    suggested_price_min = Column(Float)
    suggested_price_max = Column(Float)
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime)

class MenuItemTag(Base):
    __tablename__ = "menu_item_tags"
    id = Column(Integer, primary_key=True)
    menu_item_id = Column(Integer, ForeignKey("menu_items.id", ondelete="CASCADE"), nullable=False)
    tag = Column(Text, nullable=False)
    created_at = Column(DateTime, default=datetime.utcnow)

class AvailabilityWindow(Base):
    __tablename__ = "availability_windows"
    id = Column(Integer, primary_key=True)
    owner_type = Column(Text, nullable=False)
    owner_id = Column(Integer, nullable=False)
    day_of_week = Column(Integer, nullable=False)
    start_time = Column(Text, nullable=False)
    end_time = Column(Text, nullable=False)
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime)

class Menu(Base):
    __tablename__ = "menus"
    id = Column(Integer, primary_key=True)
    name = Column(Text, nullable=False, unique=True)
    season = Column(Text)
    is_template = Column(Integer, nullable=False, default=0)
    base_menu_id = Column(Integer, ForeignKey("menus.id"))
    default_daypart = Column(Text)
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime)

class MenuSection(Base):
    __tablename__ = "menu_sections"
    id = Column(Integer, primary_key=True)
    menu_id = Column(Integer, ForeignKey("menus.id", ondelete="CASCADE"), nullable=False)
    name = Column(Text, nullable=False)
    position = Column(Integer, nullable=False)
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime)

class MenuSectionItem(Base):
    __tablename__ = "menu_section_items"
    id = Column(Integer, primary_key=True)
    menu_section_id = Column(Integer, ForeignKey("menu_sections.id", ondelete="CASCADE"), nullable=False)
    menu_item_id = Column(Integer, ForeignKey("menu_items.id"), nullable=False)
    position = Column(Integer, nullable=False)
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime)

class Location(Base):
    __tablename__ = "locations"
    id = Column(Integer, primary_key=True)
    name = Column(Text, nullable=False, unique=True)
    region = Column(Text)
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime)

class LocationMenuTemplate(Base):
    __tablename__ = "location_menu_templates"
    id = Column(Integer, primary_key=True)
    location_id = Column(Integer, ForeignKey("locations.id", ondelete="CASCADE"), nullable=False)
    menu_id = Column(Integer, ForeignKey("menus.id", ondelete="CASCADE"), nullable=False)
    weekends_only = Column(Integer, nullable=False, default=0)
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime)

class LocationMenuVersion(Base):
    __tablename__ = "location_menu_versions"
    id = Column(Integer, primary_key=True)
    location_id = Column(Integer, ForeignKey("locations.id", ondelete="CASCADE"), nullable=False)
    menu_id = Column(Integer, ForeignKey("menus.id", ondelete="CASCADE"), nullable=False)
    version_number = Column(Integer, nullable=False)
    is_published = Column(Integer, nullable=False, default=0)
    published_at = Column(DateTime)
    audit_note = Column(Text)
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime)
    created_by = Column(Integer, ForeignKey("users.id"))

class LocationMenuItem(Base):
    __tablename__ = "location_menu_items"
    id = Column(Integer, primary_key=True)
    location_id = Column(Integer, ForeignKey("locations.id", ondelete="CASCADE"), nullable=False)
    menu_item_id = Column(Integer, ForeignKey("menu_items.id", ondelete="CASCADE"), nullable=False)
    menu_version_id = Column(Integer, ForeignKey("location_menu_versions.id", ondelete="CASCADE"))
    override_selling_price = Column(Float)
    is_published = Column(Integer, nullable=False, default=1)
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime)

class LocationMenuItemAvailability(Base):
    __tablename__ = "location_menu_item_availability"
    id = Column(Integer, primary_key=True)
    location_menu_item_id = Column(Integer, ForeignKey("location_menu_items.id", ondelete="CASCADE"), nullable=False)
    day_of_week = Column(Integer, nullable=False)
    start_time = Column(Text, nullable=False)
    end_time = Column(Text, nullable=False)
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime)

class MenuItemCostCache(Base):
    __tablename__ = "menu_item_cost_cache"
    id = Column(Integer, primary_key=True)
    menu_item_id = Column(Integer, ForeignKey("menu_items.id", ondelete="CASCADE"), nullable=False, unique=True)
    last_calculated_at = Column(DateTime)
    total_ingredient_cost = Column(Float)
    food_cost_percent = Column(Float)
    suggested_price_min = Column(Float)
    suggested_price_max = Column(Float)
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime)

Base.metadata.create_all(engine)

app = FastAPI(title="ChefCraft Cloud Menu Studio Simplified API")

class SupplierModel(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: int = Field(..., description="Supplier unique identifier", example=3)
    name: str = Field(..., description="Supplier name", example="FarmFresh Produce Co.")
    contact_info: Optional[str] = Field(None, description="Free-form contact info JSON or text", example='{"phone":"555-123-4567"}')
    created_at: Optional[datetime] = Field(None, description="Created timestamp", example="2025-01-15T10:23:45Z")
    updated_at: Optional[datetime] = Field(None, description="Updated timestamp", example="2025-02-01T08:00:00Z")

class SuppliersListResponse(BaseModel):
    suppliers: List[SupplierModel] = Field(..., description="List of suppliers", example=[])

class IngredientModel(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: int = Field(..., description="Ingredient unique identifier", example=42)
    name: str = Field(..., description="Ingredient name", example="Organic Roma Tomato")
    storage_type: str = Field(..., description="Storage type for the ingredient", example="refrigerated")
    base_unit: str = Field(..., description="Base unit for costing and inventory", example="lb")
    unit_cost: float = Field(..., description="Base unit cost in USD", example=1.2)
    allergen_flags: Optional[str] = Field(None, description="Allergen flags stored as text", example="")
    is_leaf_lettuce: int = Field(..., description="1 if leaf lettuce, else 0", example=0)
    created_at: Optional[datetime] = Field(None, description="Created timestamp", example="2025-02-01T09:00:00Z")
    updated_at: Optional[datetime] = Field(None, description="Updated timestamp", example="2025-02-01T09:00:00Z")

class IngredientCreateRequest(BaseModel):
    name: str = Field(..., description="Ingredient name (must be unique)", example="Organic Roma Tomato")
    storage_type: str = Field(..., description="Storage type for the ingredient", example="refrigerated")
    base_unit: str = Field(..., description="Base unit for costing and inventory", example="lb")
    unit_cost: float = Field(..., description="Base unit cost in USD", example=1.2)
    allergen_flags: Optional[str] = Field(None, description="Comma-separated allergen flags or JSON string; empty if none", example="")
    is_leaf_lettuce: Optional[int] = Field(0, description="Flag 1 if this ingredient is leaf lettuce, else 0", example=0)

class IngredientsListResponse(BaseModel):
    ingredients: List[IngredientModel] = Field(..., description="List of ingredients", example=[])

class IngredientPatchRequest(BaseModel):
    name: Optional[str] = Field(None, description="New ingredient name", example="Organic Green Leaf Lettuce")
    storage_type: Optional[str] = Field(None, description="New storage type", example="refrigerated")
    base_unit: Optional[str] = Field(None, description="New base unit", example="lb")
    unit_cost: Optional[float] = Field(None, description="New unit cost", example=1.35)
    allergen_flags: Optional[str] = Field(None, description="Updated allergen flags string", example="sesame")
    is_leaf_lettuce: Optional[int] = Field(None, description="1 if now treated as leaf lettuce, else 0", example=1)

class IngredientSupplierModel(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: int = Field(..., description="Ingredient-supplier link ID", example=100)
    ingredient_id: int = Field(..., description="Linked ingredient ID", example=42)
    supplier_id: int = Field(..., description="Linked supplier ID", example=3)
    supplier_sku: Optional[str] = Field(None, description="Supplier SKU", example="FF-RT-001")
    unit_cost: Optional[float] = Field(None, description="Supplier-specific unit cost", example=1.2)
    price_list_id: Optional[int] = Field(None, description="Associated price list ID or null", example=5)
    created_at: Optional[datetime] = Field(None, description="Created timestamp", example="2025-02-01T09:05:00Z")
    updated_at: Optional[datetime] = Field(None, description="Updated timestamp", example="2025-02-01T09:05:00Z")

class IngredientSupplierCreateRequest(BaseModel):
    ingredient_id: int = Field(..., description="ID of ingredient being supplied", example=42)
    supplier_id: int = Field(..., description="ID of supplier providing the ingredient", example=3)
    supplier_sku: Optional[str] = Field(None, description="Supplier-specific SKU identifier", example="FF-RT-001")
    unit_cost: Optional[float] = Field(None, description="Supplier-specific unit cost override", example=1.2)
    price_list_id: Optional[int] = Field(None, description="Associated price_list ID if this cost belongs to a list", example=5)

class IngredientSuppliersListResponse(BaseModel):
    ingredient_suppliers: List[IngredientSupplierModel] = Field(..., description="List of ingredient-supplier links", example=[])

class IngredientSupplierPatchRequest(BaseModel):
    supplier_sku: Optional[str] = Field(None, description="New supplier SKU", example="FF-RT-001-NEW")
    unit_cost: Optional[float] = Field(None, description="New unit cost for this link", example=1.25)
    price_list_id: Optional[int] = Field(None, description="New price list ID or null", example=6)

class PriceListModel(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: int = Field(..., description="Price list ID", example=5)
    name: str = Field(..., description="Price list name", example="Northeast Produce Q1 2026")
    region: Optional[str] = Field(None, description="Region that this price list applies to", example="Northeast")
    start_date: Optional[datetime] = Field(None, description="Start date", example="2026-01-01T00:00:00Z")
    end_date: Optional[datetime] = Field(None, description="End date", example="2026-03-31T00:00:00Z")
    notes: Optional[str] = Field(None, description="Additional notes for this price list", example="Seasonal produce supplier pricing")
    created_at: Optional[datetime] = Field(None, description="Created timestamp", example="2025-12-01T10:00:00Z")
    updated_at: Optional[datetime] = Field(None, description="Updated timestamp", example="2025-12-15T10:00:00Z")

class PriceListsListResponse(BaseModel):
    price_lists: List[PriceListModel] = Field(..., description="List of price lists", example=[])

class BulkIncreaseLeafLettuceCostsRequest(BaseModel):
    percentage_increase: float = Field(..., description="Percentage increase to apply", example=5.0)

class BulkIncreaseLeafLettuceCostsResponse(BaseModel):
    price_list_id: int = Field(..., description="Affected price list ID", example=5)
    percentage_increase: float = Field(..., description="Applied percentage increase", example=5.0)
    updated_rows: int = Field(..., description="Number of rows updated", example=12)

class RecipeModel(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: int = Field(..., description="Recipe ID", example=200)
    name: str = Field(..., description="Recipe name", example="Classic Margherita Pizza")
    yield_quantity: float = Field(..., description="Yield quantity", example=1.0)
    yield_unit: str = Field(..., description="Yield unit", example="pizza")
    prep_time_minutes: Optional[int] = Field(None, description="Preparation time in minutes", example=18)
    active: int = Field(..., description="Active flag", example=1)
    created_by: Optional[int] = Field(None, description="ID of user who created the recipe", example=1)
    created_at: Optional[datetime] = Field(None, description="Created timestamp", example="2025-02-01T09:10:00Z")
    updated_at: Optional[datetime] = Field(None, description="Updated timestamp", example="2025-02-01T09:10:00Z")

class RecipeCreateRequest(BaseModel):
    name: str = Field(..., description="Recipe name (unique)", example="Classic Margherita Pizza")
    yield_quantity: float = Field(..., description="Total yield quantity", example=1.0)
    yield_unit: str = Field(..., description="Yield unit label", example="pizza")
    prep_time_minutes: Optional[int] = Field(None, description="Preparation time in minutes", example=18)
    active: Optional[int] = Field(1, description="1 if recipe is active, 0 otherwise", example=1)

class RecipesListResponse(BaseModel):
    recipes: List[RecipeModel] = Field(..., description="List of recipes", example=[])

class RecipePatchRequest(BaseModel):
    name: Optional[str] = Field(None, description="New recipe name", example="Updated")
    yield_quantity: Optional[float] = Field(None, description="New yield quantity", example=4.0)
    yield_unit: Optional[str] = Field(None, description="New yield unit", example="portions")
    prep_time_minutes: Optional[int] = Field(None, description="New prep time in minutes", example=30)
    active: Optional[int] = Field(None, description="1 if active, 0 if inactive", example=1)

class RecipeIngredientLineModel(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: int = Field(..., description="Ingredient line ID", example=300)
    recipe_id: int = Field(..., description="Parent recipe ID", example=200)
    ingredient_id: int = Field(..., description="Ingredient ID", example=50)
    position: int = Field(..., description="Ordering position", example=1)
    quantity: float = Field(..., description="Ingredient quantity", example=4.0)
    unit: str = Field(..., description="Ingredient unit", example="oz")
    line_allergen_flags: Optional[str] = Field(None, description="Line-level allergen flags", example="")
    notes: Optional[str] = Field(None, description="Additional notes for this line", example="Use low-moisture mozzarella")
    created_at: Optional[datetime] = Field(None, description="Created timestamp", example="2025-02-01T09:15:00Z")
    updated_at: Optional[datetime] = Field(None, description="Updated timestamp", example="2025-02-01T09:15:00Z")

class RecipeIngredientLineCreateRequest(BaseModel):
    ingredient_id: int = Field(..., description="Ingredient ID used in the recipe", example=50)
    position: int = Field(..., description="Ordering position within the ingredient list", example=1)
    quantity: float = Field(..., description="Quantity of ingredient", example=4.0)
    unit: str = Field(..., description="Unit of measure for this ingredient line", example="oz")
    line_allergen_flags: Optional[str] = Field(None, description="Line-specific allergen flags", example="egg")
    notes: Optional[str] = Field(None, description="Optional preparation or sourcing notes", example="Use low-moisture mozzarella")

class RecipeIngredientLinesListResponse(BaseModel):
    ingredient_lines: List[RecipeIngredientLineModel] = Field(..., description="Ingredient lines", example=[])

class RecipeIngredientLinePatchRequest(BaseModel):
    position: Optional[int] = Field(None, description="New ordering position", example=3)
    quantity: Optional[float] = Field(None, description="New quantity for this line", example=5.0)
    unit: Optional[str] = Field(None, description="New unit of measure", example="oz")
    line_allergen_flags: Optional[str] = Field(None, description="New allergen flags value", example="egg")
    notes: Optional[str] = Field(None, description="New notes", example="Contains egg from buttermilk")

class RecipeStepModel(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: int = Field(..., description="Recipe step ID", example=400)
    recipe_id: int = Field(..., description="Parent recipe ID", example=200)
    step_number: int = Field(..., description="Step order number", example=1)
    description: str = Field(..., description="Step description text", example="Stretch the dough.")
    created_at: Optional[datetime] = Field(None, description="Created timestamp", example="2025-02-01T09:20:00Z")
    updated_at: Optional[datetime] = Field(None, description="Updated timestamp", example="2025-02-01T09:20:00Z")

class RecipeStepCreateRequest(BaseModel):
    step_number: int = Field(..., description="Sequential step number, starting from 1", example=1)
    description: str = Field(..., description="Text describing the preparation step", example="Stretch the dough.")

class RecipeStepsListResponse(BaseModel):
    steps: List[RecipeStepModel] = Field(..., description="Steps", example=[])

class RecipeStepPatchRequest(BaseModel):
    step_number: Optional[int] = Field(None, description="New step order number", example=3)
    description: Optional[str] = Field(None, description="New step description text", example="Bake at 500F.")

class MenuItemModel(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: int = Field(..., description="Menu item ID", example=500)
    internal_name: str = Field(..., description="Internal name", example="vegan_spicy_ramen")
    recipe_id: Optional[int] = Field(None, description="Linked recipe ID", example=250)
    display_name: str = Field(..., description="Display name", example="Vegan Spicy Ramen Bowl")
    menu_description: Optional[str] = Field(None, description="Menu description", example="Rich vegetable broth")
    base_selling_price: Optional[float] = Field(None, description="Base selling price", example=16.5)
    active: int = Field(..., description="Active flag", example=1)
    food_cost_percent: Optional[float] = Field(None, description="Cached food cost percent", example=32.5)
    suggested_price_min: Optional[float] = Field(None, description="Cached suggested minimum price", example=15.0)
    suggested_price_max: Optional[float] = Field(None, description="Cached suggested maximum price", example=19.0)
    created_at: Optional[datetime] = Field(None, description="Created timestamp", example="2025-02-01T09:30:00Z")
    updated_at: Optional[datetime] = Field(None, description="Updated timestamp", example="2025-02-01T09:30:00Z")

class MenuItemCreateRequest(BaseModel):
    internal_name: str = Field(..., description="Internal name (unique)", example="vegan_spicy_ramen")
    recipe_id: Optional[int] = Field(None, description="Linked recipe ID", example=250)
    display_name: str = Field(..., description="Customer-facing display name", example="Vegan Spicy Ramen Bowl")
    menu_description: Optional[str] = Field(None, description="Description shown on menu", example="Rich vegetable broth")
    base_selling_price: Optional[float] = Field(None, description="Default selling price", example=16.5)
    active: Optional[int] = Field(1, description="1 if item is active, 0 otherwise", example=1)

class MenuItemsListResponse(BaseModel):
    menu_items: List[MenuItemModel] = Field(..., description="Menu items", example=[])

class MenuItemPatchRequest(BaseModel):
    internal_name: Optional[str] = Field(None, description="New internal name", example="grilled_salmon_quinoa_dinner")
    recipe_id: Optional[int] = Field(None, description="New linked recipe ID", example=260)
    display_name: Optional[str] = Field(None, description="New display name", example="Grilled Salmon with Quinoa")
    menu_description: Optional[str] = Field(None, description="New menu description", example="Dinner portion")
    base_selling_price: Optional[float] = Field(None, description="New base selling price", example=27.0)
    active: Optional[int] = Field(None, description="1 to activate, 0 to deactivate", example=1)

class MenuItemTagModel(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: int = Field(..., description="Menu item tag ID", example=600)
    menu_item_id: int = Field(..., description="Linked menu item ID", example=500)
    tag: str = Field(..., description="Tag value", example="vegan")
    created_at: Optional[datetime] = Field(None, description="Created timestamp", example="2025-02-01T09:35:00Z")

class MenuItemTagCreateRequest(BaseModel):
    tag: str = Field(..., description="Tag label", example="vegan")

class MenuItemTagsListResponse(BaseModel):
    tags: List[MenuItemTagModel] = Field(..., description="Menu item tags", example=[])

class DeleteResponse(BaseModel):
    deleted: bool = Field(..., description="True if deletion succeeded", example=True)

class AvailabilityWindowModel(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: int = Field(..., description="Availability window ID", example=700)
    owner_type: str = Field(..., description="Owner type", example="menu_item")
    owner_id: int = Field(..., description="Owner ID", example=500)
    day_of_week: int = Field(..., description="Day of week (0-6)", example=0)
    start_time: str = Field(..., description="Start time (HH:MM)", example="11:00")
    end_time: str = Field(..., description="End time (HH:MM)", example="15:00")
    created_at: Optional[datetime] = Field(None, description="Created timestamp", example="2025-02-01T09:40:00Z")
    updated_at: Optional[datetime] = Field(None, description="Updated timestamp", example="2025-02-01T09:40:00Z")

class AvailabilityWindowCreateRequest(BaseModel):
    owner_type: str = Field(..., description="Type of owner", example="menu_item")
    owner_id: int = Field(..., description="ID of the owner entity", example=500)
    day_of_week: int = Field(..., description="Day of week (0=Monday, 6=Sunday)", example=0)
    start_time: str = Field(..., description="Start time (HH:MM)", example="11:00")
    end_time: str = Field(..., description="End time (HH:MM)", example="15:00")

class AvailabilityWindowsListResponse(BaseModel):
    availability_windows: List[AvailabilityWindowModel] = Field(..., description="Availability windows", example=[])

class MenuModel(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: int = Field(..., description="Menu ID", example=30)
    name: str = Field(..., description="Menu name", example="Downtown Dinner Winter 2025")
    season: Optional[str] = Field(None, description="Season metadata label", example="Winter 2025")
    is_template: int = Field(..., description="1 if template, 0 if concrete menu", example=0)
    base_menu_id: Optional[int] = Field(None, description="Base menu template ID, if any", example=25)
    default_daypart: Optional[str] = Field(None, description="Default daypart label", example="dinner")
    created_at: Optional[datetime] = Field(None, description="Created timestamp", example="2024-12-01T10:00:00Z")
    updated_at: Optional[datetime] = Field(None, description="Updated timestamp", example="2025-01-05T11:00:00Z")

class MenusListResponse(BaseModel):
    menus: List[MenuModel] = Field(..., description="Menus", example=[])

class MenuCreateRequest(BaseModel):
    name: str = Field(..., description="Menu name (unique)", example="Summer 2025 Brunch Menu")
    season: Optional[str] = Field(None, description="Season metadata label", example="Summer 2025")
    is_template: int = Field(..., description="1 if template, 0 if location-specific base", example=1)
    base_menu_id: Optional[int] = Field(None, description="ID of base menu if this menu is derived", example=35)
    default_daypart: Optional[str] = Field(None, description="Default daypart for menu", example="brunch")

class MenuPatchRequest(BaseModel):
    name: Optional[str] = Field(None, description="New menu name", example="Updated")
    season: Optional[str] = Field(None, description="New season label", example="Spring 2025")
    is_template: Optional[int] = Field(None, description="1 if template, 0 otherwise", example=1)
    base_menu_id: Optional[int] = Field(None, description="New base menu ID", example=35)
    default_daypart: Optional[str] = Field(None, description="New default daypart", example="brunch")

class MenuSectionModel(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: int = Field(..., description="Menu section ID", example=800)
    menu_id: int = Field(..., description="Parent menu ID", example=30)
    name: str = Field(..., description="Section name", example="Winter Specials")
    position: int = Field(..., description="Section position", example=3)
    created_at: Optional[datetime] = Field(None, description="Created timestamp", example="2025-02-01T10:00:00Z")
    updated_at: Optional[datetime] = Field(None, description="Updated timestamp", example="2025-02-01T10:00:00Z")

class MenuSectionCreateRequest(BaseModel):
    name: str = Field(..., description="Section name", example="Winter Specials")
    position: int = Field(..., description="Section ordering position within the menu", example=3)

class MenuSectionsListResponse(BaseModel):
    sections: List[MenuSectionModel] = Field(..., description="Sections", example=[])

class MenuSectionPatchRequest(BaseModel):
    name: Optional[str] = Field(None, description="New section name", example="Mains")
    position: Optional[int] = Field(None, description="New section position", example=3)

class MenuSectionItemModel(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: int = Field(..., description="Menu section item ID", example=900)
    menu_section_id: int = Field(..., description="Linked section ID", example=800)
    menu_item_id: int = Field(..., description="Linked menu item ID", example=520)
    position: int = Field(..., description="Position in section", example=1)
    created_at: Optional[datetime] = Field(None, description="Created timestamp", example="2025-02-01T10:15:00Z")
    updated_at: Optional[datetime] = Field(None, description="Updated timestamp", example="2025-02-01T10:15:00Z")

class MenuSectionItemCreateRequest(BaseModel):
    menu_item_id: int = Field(..., description="Menu item ID to include in this section", example=520)
    position: int = Field(..., description="Ordering position within the section", example=1)

class MenuSectionItemsListResponse(BaseModel):
    section_items: List[MenuSectionItemModel] = Field(..., description="Section items", example=[])

class MenuSectionItemPatchRequest(BaseModel):
    menu_item_id: Optional[int] = Field(None, description="New menu item ID for this position", example=521)
    position: Optional[int] = Field(None, description="New ordering position", example=2)

class LocationModel(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: int = Field(..., description="Location ID", example=10)
    name: str = Field(..., description="Location name", example="Uptown Bistro")
    region: Optional[str] = Field(None, description="Region label", example="Northeast")
    created_at: Optional[datetime] = Field(None, description="Created timestamp", example="2023-06-01T10:00:00Z")
    updated_at: Optional[datetime] = Field(None, description="Updated timestamp", example="2024-01-01T10:00:00Z")

class LocationsListResponse(BaseModel):
    locations: List[LocationModel] = Field(..., description="Locations", example=[])

class LocationMenuTemplateModel(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: int = Field(..., description="Location-menu template link ID", example=1000)
    location_id: int = Field(..., description="Location ID", example=10)
    menu_id: int = Field(..., description="Menu template ID", example=45)
    weekends_only: int = Field(..., description="Weekends-only flag", example=1)
    created_at: Optional[datetime] = Field(None, description="Created timestamp", example="2025-03-01T09:00:00Z")
    updated_at: Optional[datetime] = Field(None, description="Updated timestamp", example="2025-03-01T09:00:00Z")

class LocationMenuTemplateCreateRequest(BaseModel):
    location_id: int = Field(..., description="Location ID", example=10)
    menu_id: int = Field(..., description="Menu template ID", example=45)
    weekends_only: Optional[int] = Field(0, description="1 if weekends only", example=1)

class LocationMenuTemplatesListResponse(BaseModel):
    location_menu_templates: List[LocationMenuTemplateModel] = Field(..., description="Location menu templates", example=[])

class LocationMenuTemplatePatchRequest(BaseModel):
    location_id: Optional[int] = Field(None, description="New location ID", example=11)
    menu_id: Optional[int] = Field(None, description="New menu ID", example=46)
    weekends_only: Optional[int] = Field(None, description="Updated weekends-only flag", example=1)

class LocationMenuVersionModel(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: int = Field(..., description="Location menu version ID", example=1100)
    location_id: int = Field(..., description="Location ID", example=20)
    menu_id: int = Field(..., description="Menu ID", example=60)
    version_number: int = Field(..., description="Version number", example=2)
    is_published: int = Field(..., description="Published flag", example=0)
    published_at: Optional[datetime] = Field(None, description="Published timestamp or null", example=None)
    audit_note: Optional[str] = Field(None, description="Audit note text", example="Added Korean-inspired snacks")
    created_at: Optional[datetime] = Field(None, description="Created timestamp", example="2025-04-01T22:00:00Z")
    updated_at: Optional[datetime] = Field(None, description="Updated timestamp", example="2025-04-01T22:00:00Z")
    created_by: Optional[int] = Field(None, description="User ID who created version", example=1)

class LocationMenuVersionCreateRequest(BaseModel):
    location_id: int = Field(..., description="Location ID", example=20)
    menu_id: int = Field(..., description="Menu ID", example=60)
    version_number: int = Field(..., description="Version number for this menu at the location", example=2)
    is_published: Optional[int] = Field(0, description="1 if published, 0 if draft", example=0)
    audit_note: Optional[str] = Field(None, description="Audit note describing purpose of this version", example="Added Korean-inspired snacks")

class LocationMenuVersionPatchRequest(BaseModel):
    version_number: Optional[int] = Field(None, description="New version number", example=3)
    is_published: Optional[int] = Field(None, description="Set 1 to publish, 0 to unpublish", example=1)
    published_at: Optional[datetime] = Field(None, description="Explicit published timestamp or null", example="2025-04-01T22:05:00Z")
    audit_note: Optional[str] = Field(None, description="Updated audit note", example="Shifted to new snacks")

class LocationMenuVersionsListResponse(BaseModel):
    location_menu_versions: List[LocationMenuVersionModel] = Field(..., description="Location menu versions", example=[])

class LocationMenuItemModel(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: int = Field(..., description="Location menu item ID", example=1200)
    location_id: int = Field(..., description="Location ID", example=10)
    menu_item_id: int = Field(..., description="Menu item ID", example=510)
    menu_version_id: Optional[int] = Field(None, description="Menu version ID or null", example=1100)
    override_selling_price: Optional[float] = Field(None, description="Override price or null", example=28.0)
    is_published: int = Field(..., description="Published flag at location", example=1)
    created_at: Optional[datetime] = Field(None, description="Created timestamp", example="2025-02-01T10:30:00Z")
    updated_at: Optional[datetime] = Field(None, description="Updated timestamp", example="2025-02-01T10:30:00Z")

class LocationMenuItemCreateRequest(BaseModel):
    location_id: int = Field(..., description="Location ID", example=10)
    menu_item_id: int = Field(..., description="Menu item ID", example=510)
    menu_version_id: Optional[int] = Field(None, description="Location menu version ID", example=1100)
    override_selling_price: Optional[float] = Field(None, description="Location-specific selling price", example=28.0)
    is_published: Optional[int] = Field(1, description="1 if item is published at location, else 0", example=1)

class LocationMenuItemsListResponse(BaseModel):
    location_menu_items: List[LocationMenuItemModel] = Field(..., description="Location menu items", example=[])

class LocationMenuItemPatchRequest(BaseModel):
    menu_version_id: Optional[int] = Field(None, description="New menu version ID or null", example=1101)
    override_selling_price: Optional[float] = Field(None, description="New override selling price", example=28.0)
    is_published: Optional[int] = Field(None, description="New published flag", example=1)

class LocationMenuItemAvailabilityModel(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: int = Field(..., description="Location menu item availability ID", example=1300)
    location_menu_item_id: int = Field(..., description="Location menu item ID", example=1200)
    day_of_week: int = Field(..., description="Day of week (0-6)", example=4)
    start_time: str = Field(..., description="Start time", example="17:00")
    end_time: str = Field(..., description="End time", example="22:00")
    created_at: Optional[datetime] = Field(None, description="Created timestamp", example="2025-02-01T11:10:00Z")
    updated_at: Optional[datetime] = Field(None, description="Updated timestamp", example="2025-02-01T11:10:00Z")

class LocationMenuItemAvailabilityCreateRequest(BaseModel):
    day_of_week: int = Field(..., description="Day of week (0=Monday, 6=Sunday)", example=4)
    start_time: str = Field(..., description="Start time (HH:MM, 24-hour)", example="17:00")
    end_time: str = Field(..., description="End time (HH:MM, 24-hour)", example="22:00")

class LocationMenuItemAvailabilityListResponse(BaseModel):
    availability: List[LocationMenuItemAvailabilityModel] = Field(..., description="Availability entries", example=[])

class MenuItemCostCacheEntryModel(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    menu_item_id: int = Field(..., description="Menu item ID", example=510)
    last_calculated_at: Optional[datetime] = Field(None, description="Last calculation timestamp", example="2026-01-10T12:00:00Z")
    total_ingredient_cost: Optional[float] = Field(None, description="Total ingredient cost per serving", example=9.0)
    food_cost_percent: Optional[float] = Field(None, description="Food cost percent", example=33.0)
    suggested_price_min: Optional[float] = Field(None, description="Suggested minimum price", example=25.0)
    suggested_price_max: Optional[float] = Field(None, description="Suggested maximum price", example=30.0)

class MenuItemCostCacheRecalculateRequest(BaseModel):
    menu_item_ids: Optional[List[int]] = Field(None, description="Optional list of menu_item IDs", example=[500, 510, 520])

class MenuItemCostCacheRecalculateItemModel(BaseModel):
    menu_item_id: int = Field(..., description="Menu item ID", example=510)
    total_ingredient_cost: float = Field(..., description="Total ingredient cost per serving", example=9.0)
    food_cost_percent: float = Field(..., description="Calculated food cost percent", example=33.0)
    suggested_price_min: float = Field(..., description="Calculated suggested minimum price", example=25.0)
    suggested_price_max: float = Field(..., description="Calculated suggested maximum price", example=30.0)
    last_calculated_at: datetime = Field(..., description="Timestamp when calculation was performed", example="2026-01-10T12:00:00Z")

class MenuItemCostCacheRecalculateResponse(BaseModel):
    recalculated_items: List[MenuItemCostCacheRecalculateItemModel] = Field(..., description="Recalculated items", example=[])

class MenuItemCostCacheListResponse(BaseModel):
    cost_cache_entries: List[MenuItemCostCacheEntryModel] = Field(..., description="Cost cache entries", example=[])

class WorstMarginItemModel(BaseModel):
    location_id: Optional[int] = Field(None, description="Location ID or null for template-level", example=10)
    location_name: Optional[str] = Field(None, description="Location name", example="Uptown Bistro")
    daypart: Optional[str] = Field(None, description="Menu default_daypart associated with the item", example="dinner")
    menu_item_id: int = Field(..., description="Menu item ID", example=510)
    menu_item_display_name: str = Field(..., description="Menu item display name", example="Grilled Salmon with Quinoa")
    recipe_id: Optional[int] = Field(None, description="Associated recipe ID", example=260)
    current_selling_price: Optional[float] = Field(None, description="Effective selling price considering location override", example=28.0)
    suggested_price_min: Optional[float] = Field(None, description="Suggested minimum price from cost cache", example=29.0)
    suggested_price_max: Optional[float] = Field(None, description="Suggested maximum price from cost cache", example=34.0)
    food_cost_percent: Optional[float] = Field(None, description="Current food cost percent", example=36.0)

class WorstMarginItemsResponse(BaseModel):
    items: List[WorstMarginItemModel] = Field(..., description="Worst-margin items", example=[])

class PriceListMarginImpactRequest(BaseModel):
    price_list_id: int = Field(..., description="Price list that was updated", example=5)
    margin_threshold_percent: Optional[float] = Field(70.0, description="Minimum acceptable margin", example=70.0)

class PriceListMarginImpactItemModel(BaseModel):
    menu_item_id: int = Field(..., description="Menu item ID", example=520)
    menu_item_display_name: str = Field(..., description="Menu item name", example="Caesar Salad with Baby Kale")
    location_id: Optional[int] = Field(None, description="Location ID or null for generic", example=None)
    location_name: Optional[str] = Field(None, description="Location name or empty for generic menu level", example="")
    current_selling_price: Optional[float] = Field(None, description="Effective selling price", example=16.0)
    total_ingredient_cost: float = Field(..., description="Recalculated total ingredient cost", example=5.5)
    food_cost_percent: float = Field(..., description="Resulting food cost percent", example=34.4)
    margin_percent: float = Field(..., description="Computed margin percent", example=65.6)
    suggested_price_min: float = Field(..., description="Suggested minimum price after recalculation", example=17.0)
    suggested_price_max: float = Field(..., description="Suggested maximum price after recalculation", example=20.0)

class PriceListMarginImpactResponse(BaseModel):
    price_list_id: int = Field(..., description="Price list ID for which the report was generated", example=5)
    margin_threshold_percent: float = Field(..., description="Margin percent threshold used in report", example=70.0)
    affected_menu_items: List[PriceListMarginImpactItemModel] = Field(..., description="Affected menu items", example=[])

class CloneMenuRequest(BaseModel):
    new_name: str = Field(..., description="Name for the cloned menu", example="Summer 2025 Brunch Menu")
    new_season: Optional[str] = Field(None, description="Optional new season label for cloned menu", example="Summer 2025")
    is_template: Optional[int] = Field(1, description="Template flag for cloned menu (1 or 0)", example=1)

class CloneMenuNewMenuModel(BaseModel):
    id: int = Field(..., description="New cloned menu ID", example=45)
    name: str = Field(..., description="New cloned menu name", example="Summer 2025 Brunch Menu")
    season: Optional[str] = Field(None, description="New cloned menu season", example="Summer 2025")
    is_template: int = Field(..., description="Template flag for cloned menu", example=1)
    base_menu_id: Optional[int] = Field(None, description="Original menu ID this clone is based on", example=40)
    default_daypart: Optional[str] = Field(None, description="Default daypart cloned from source menu", example="brunch")

class ClonedSectionModel(BaseModel):
    old_section_id: int = Field(..., description="Original section ID", example=780)
    new_section_id: int = Field(..., description="New section ID", example=880)
    name: str = Field(..., description="Section name", example="Egg Dishes")
    position: int = Field(..., description="Section position", example=1)

class ClonedSectionItemModel(BaseModel):
    old_section_item_id: int = Field(..., description="Original section item ID", example=900)
    new_section_item_id: int = Field(..., description="New section item ID", example=950)
    new_section_id: int = Field(..., description="New section ID where item is placed", example=880)
    menu_item_id: int = Field(..., description="Menu item ID (unchanged)", example=520)
    position: int = Field(..., description="Item position within new section", example=1)

class CloneMenuResponse(BaseModel):
    new_menu: CloneMenuNewMenuModel = Field(..., description="New cloned menu", example={})
    cloned_sections: List[ClonedSectionModel] = Field(..., description="Cloned sections", example=[])
    cloned_section_items: List[ClonedSectionItemModel] = Field(..., description="Cloned section items", example=[])

@app.get("/api/suppliers", response_model=SuppliersListResponse, summary="List suppliers", description="List suppliers with optional name filter", tags=["suppliers"], operation_id="list_suppliers")
async def list_suppliers(name: Optional[str] = Query(None, description="Filter suppliers by exact or partial name match", example="FarmFresh"), limit: Optional[int] = Query(20, description="Maximum number of suppliers to return", example=20), offset: Optional[int] = Query(0, description="Number of suppliers to skip for pagination", example=0)) -> SuppliersListResponse:
    session = SessionLocal()
    query = session.query(Supplier)
    if name is not None:
        query = query.filter(Supplier.name.ilike(f"%{name}%"))
    if offset is not None:
        query = query.offset(offset)
    if limit is not None:
        query = query.limit(limit)
    rows = query.all()
    session.close()
    return SuppliersListResponse(suppliers=rows)

@app.get("/api/suppliers/{supplier_id}", response_model=SupplierModel, summary="Get supplier", description="Get a single supplier by ID", tags=["suppliers"], operation_id="get_supplier")
async def get_supplier(supplier_id: int = Path(..., description="Supplier ID to fetch", example=3)) -> SupplierModel:
    session = SessionLocal()
    row = session.query(Supplier).filter(Supplier.id == supplier_id).first()
    session.close()
    if row is None:
        return SupplierModel(id=0, name="", contact_info=None, created_at=None, updated_at=None)
    return row

@app.post("/api/ingredients", response_model=IngredientModel, summary="Create ingredient", description="Create a new ingredient", tags=["ingredients"], operation_id="create_ingredient")
async def create_ingredient(body: IngredientCreateRequest = Body(..., description="Ingredient payload")) -> IngredientModel:
    session = SessionLocal()
    now = datetime.utcnow()
    obj = Ingredient(
        name=body.name,
        storage_type=body.storage_type,
        base_unit=body.base_unit,
        unit_cost=body.unit_cost,
        allergen_flags=body.allergen_flags,
        is_leaf_lettuce=body.is_leaf_lettuce if body.is_leaf_lettuce is not None else 0,
        created_at=now,
        updated_at=now,
    )
    session.add(obj)
    session.commit()
    session.refresh(obj)
    session.close()
    return obj

@app.get("/api/ingredients", response_model=IngredientsListResponse, summary="List ingredients", description="List ingredients with optional filters", tags=["ingredients"], operation_id="list_ingredients")
async def list_ingredients(name: Optional[str] = Query(None, description="Filter ingredients by exact or partial name", example="Fresh Mozzarella"), is_leaf_lettuce: Optional[int] = Query(None, description="Filter by lettuce flag (1 = leaf lettuce, 0 = not)", example=1), limit: Optional[int] = Query(50, description="Maximum number of ingredients to return", example=50), offset: Optional[int] = Query(0, description="Number of ingredients to skip for pagination", example=0)) -> IngredientsListResponse:
    session = SessionLocal()
    query = session.query(Ingredient)
    if name is not None:
        query = query.filter(Ingredient.name.ilike(f"%{name}%"))
    if is_leaf_lettuce is not None:
        query = query.filter(Ingredient.is_leaf_lettuce == is_leaf_lettuce)
    if offset is not None:
        query = query.offset(offset)
    if limit is not None:
        query = query.limit(limit)
    rows = query.all()
    session.close()
    return IngredientsListResponse(ingredients=rows)

@app.patch("/api/ingredients/{ingredient_id}", response_model=IngredientModel, summary="Patch ingredient", description="Update an ingredient partially", tags=["ingredients"], operation_id="patch_ingredient")
async def patch_ingredient(ingredient_id: int = Path(..., description="Ingredient ID to update", example=15), body: IngredientPatchRequest = Body(..., description="Fields to update")) -> IngredientModel:
    session = SessionLocal()
    obj = session.query(Ingredient).filter(Ingredient.id == ingredient_id).first()
    if obj is not None:
        if body.name is not None:
            obj.name = body.name
        if body.storage_type is not None:
            obj.storage_type = body.storage_type
        if body.base_unit is not None:
            obj.base_unit = body.base_unit
        if body.unit_cost is not None:
            obj.unit_cost = body.unit_cost
        if body.allergen_flags is not None:
            obj.allergen_flags = body.allergen_flags
        if body.is_leaf_lettuce is not None:
            obj.is_leaf_lettuce = body.is_leaf_lettuce
        obj.updated_at = datetime.utcnow()
        session.commit()
        session.refresh(obj)
    session.close()
    if obj is None:
        return IngredientModel(id=0, name="", storage_type="", base_unit="", unit_cost=0.0, allergen_flags=None, is_leaf_lettuce=0, created_at=None, updated_at=None)
    return obj

@app.post("/api/ingredient-suppliers", response_model=IngredientSupplierModel, summary="Create ingredient-supplier", description="Link ingredient to supplier with optional price", tags=["ingredient_suppliers"], operation_id="create_ingredient_supplier")
async def create_ingredient_supplier(body: IngredientSupplierCreateRequest = Body(..., description="Ingredient supplier link payload")) -> IngredientSupplierModel:
    session = SessionLocal()
    now = datetime.utcnow()
    obj = IngredientSupplier(
        ingredient_id=body.ingredient_id,
        supplier_id=body.supplier_id,
        supplier_sku=body.supplier_sku,
        unit_cost=body.unit_cost,
        price_list_id=body.price_list_id,
        created_at=now,
        updated_at=now,
    )
    session.add(obj)
    session.commit()
    session.refresh(obj)
    session.close()
    return obj

@app.get("/api/ingredient-suppliers", response_model=IngredientSuppliersListResponse, summary="List ingredient-suppliers", description="List ingredient-supplier links", tags=["ingredient_suppliers"], operation_id="list_ingredient_suppliers")
async def list_ingredient_suppliers(ingredient_id: Optional[int] = Query(None, description="Filter by ingredient ID", example=42), supplier_id: Optional[int] = Query(None, description="Filter by supplier ID", example=3), price_list_id: Optional[int] = Query(None, description="Filter by price list ID", example=5), limit: Optional[int] = Query(100, description="Maximum rows to return", example=100), offset: Optional[int] = Query(0, description="Rows to skip", example=0)) -> IngredientSuppliersListResponse:
    session = SessionLocal()
    query = session.query(IngredientSupplier)
    if ingredient_id is not None:
        query = query.filter(IngredientSupplier.ingredient_id == ingredient_id)
    if supplier_id is not None:
        query = query.filter(IngredientSupplier.supplier_id == supplier_id)
    if price_list_id is not None:
        query = query.filter(IngredientSupplier.price_list_id == price_list_id)
    if offset is not None:
        query = query.offset(offset)
    if limit is not None:
        query = query.limit(limit)
    rows = query.all()
    session.close()
    return IngredientSuppliersListResponse(ingredient_suppliers=rows)

@app.patch("/api/ingredient-suppliers/{id}", response_model=IngredientSupplierModel, summary="Patch ingredient-supplier", description="Update ingredient-supplier link partially", tags=["ingredient_suppliers"], operation_id="patch_ingredient_supplier")
async def patch_ingredient_supplier(id: int = Path(..., description="Ingredient-supplier row ID", example=100), body: IngredientSupplierPatchRequest = Body(..., description="Fields to update")) -> IngredientSupplierModel:
    session = SessionLocal()
    obj = session.query(IngredientSupplier).filter(IngredientSupplier.id == id).first()
    if obj is not None:
        if body.supplier_sku is not None:
            obj.supplier_sku = body.supplier_sku
        if body.unit_cost is not None:
            obj.unit_cost = body.unit_cost
        if body.price_list_id is not None:
            obj.price_list_id = body.price_list_id
        obj.updated_at = datetime.utcnow()
        session.commit()
        session.refresh(obj)
    session.close()
    if obj is None:
        return IngredientSupplierModel(id=0, ingredient_id=0, supplier_id=0, supplier_sku=None, unit_cost=None, price_list_id=None, created_at=None, updated_at=None)
    return obj

@app.get("/api/price-lists", response_model=PriceListsListResponse, summary="List price lists", description="List price lists with optional filters", tags=["price_lists"], operation_id="list_price_lists")
async def list_price_lists(name: Optional[str] = Query(None, description="Filter price lists by exact or partial name", example="Northeast Produce Q1 2026"), region: Optional[str] = Query(None, description="Filter by region name", example="Northeast"), active_on: Optional[str] = Query(None, description="ISO date; between start_date and end_date", example="2026-02-15"), limit: Optional[int] = Query(20, description="Max rows to return", example=20), offset: Optional[int] = Query(0, description="Rows to skip", example=0)) -> PriceListsListResponse:
    session = SessionLocal()
    query = session.query(PriceList)
    if name is not None:
        query = query.filter(PriceList.name.ilike(f"%{name}%"))
    if region is not None:
        query = query.filter(PriceList.region == region)
    if active_on is not None:
        try:
            date_val = datetime.fromisoformat(active_on).date()
            query = query.filter(PriceList.start_date <= date_val).filter(PriceList.end_date >= date_val)
        except Exception:
            pass
    if offset is not None:
        query = query.offset(offset)
    if limit is not None:
        query = query.limit(limit)
    rows = query.all()
    session.close()
    return PriceListsListResponse(price_lists=rows)

@app.post("/api/price-lists/{price_list_id}/leaf-lettuce-costs/increase", response_model=BulkIncreaseLeafLettuceCostsResponse, summary="Increase lettuce costs", description="Bulk increase leaf-lettuce costs for a price list", tags=["price_lists", "bulk_updates"], operation_id="bulk_increase_leaf_lettuce_costs")
async def bulk_increase_leaf_lettuce_costs(price_list_id: int = Path(..., description="Target price list ID", example=5), body: BulkIncreaseLeafLettuceCostsRequest = Body(..., description="Increase percentage")) -> BulkIncreaseLeafLettuceCostsResponse:
    session = SessionLocal()
    rows = session.query(IngredientSupplier).join(Ingredient, IngredientSupplier.ingredient_id == Ingredient.id).filter(Ingredient.is_leaf_lettuce == 1).filter(IngredientSupplier.price_list_id == price_list_id).all()
    updated_rows = 0
    if body.percentage_increase != 0:
        factor = 1.0 + body.percentage_increase / 100.0
        for row in rows:
            if row.unit_cost is not None:
                row.unit_cost = row.unit_cost * factor
                row.updated_at = datetime.utcnow()
                updated_rows += 1
        session.commit()
    session.close()
    return BulkIncreaseLeafLettuceCostsResponse(price_list_id=price_list_id, percentage_increase=body.percentage_increase, updated_rows=updated_rows)

@app.post("/api/recipes", response_model=RecipeModel, summary="Create recipe", description="Create a new recipe", tags=["recipes"], operation_id="create_recipe")
async def create_recipe(body: RecipeCreateRequest = Body(..., description="Recipe payload")) -> RecipeModel:
    session = SessionLocal()
    now = datetime.utcnow()
    obj = Recipe(
        name=body.name,
        yield_quantity=body.yield_quantity,
        yield_unit=body.yield_unit,
        prep_time_minutes=body.prep_time_minutes,
        active=body.active if body.active is not None else 1,
        created_by=1,
        created_at=now,
        updated_at=now,
    )
    session.add(obj)
    session.commit()
    session.refresh(obj)
    session.close()
    return obj

@app.get("/api/recipes", response_model=RecipesListResponse, summary="List recipes", description="List recipes with optional filters", tags=["recipes"], operation_id="list_recipes")
async def list_recipes(name: Optional[str] = Query(None, description="Filter recipes by exact or partial name", example="Gluten-Free Fried Chicken"), active: Optional[int] = Query(None, description="Filter by active flag (1 or 0)", example=1), limit: Optional[int] = Query(50, description="Max recipes to return", example=50), offset: Optional[int] = Query(0, description="Recipes to skip", example=0)) -> RecipesListResponse:
    session = SessionLocal()
    query = session.query(Recipe)
    if name is not None:
        query = query.filter(Recipe.name.ilike(f"%{name}%"))
    if active is not None:
        query = query.filter(Recipe.active == active)
    if offset is not None:
        query = query.offset(offset)
    if limit is not None:
        query = query.limit(limit)
    rows = query.all()
    session.close()
    return RecipesListResponse(recipes=rows)

@app.patch("/api/recipes/{recipe_id}", response_model=RecipeModel, summary="Patch recipe", description="Update a recipe header partially", tags=["recipes"], operation_id="patch_recipe")
async def patch_recipe(recipe_id: int = Path(..., description="Recipe ID to update", example=210), body: RecipePatchRequest = Body(..., description="Fields to update")) -> RecipeModel:
    session = SessionLocal()
    obj = session.query(Recipe).filter(Recipe.id == recipe_id).first()
    if obj is not None:
        if body.name is not None:
            obj.name = body.name
        if body.yield_quantity is not None:
            obj.yield_quantity = body.yield_quantity
        if body.yield_unit is not None:
            obj.yield_unit = body.yield_unit
        if body.prep_time_minutes is not None:
            obj.prep_time_minutes = body.prep_time_minutes
        if body.active is not None:
            obj.active = body.active
        obj.updated_at = datetime.utcnow()
        session.commit()
        session.refresh(obj)
    session.close()
    if obj is None:
        return RecipeModel(id=0, name="", yield_quantity=0.0, yield_unit="", prep_time_minutes=None, active=0, created_by=None, created_at=None, updated_at=None)
    return obj

@app.post("/api/recipes/{recipe_id}/ingredient-lines", response_model=RecipeIngredientLineModel, summary="Create ingredient line", description="Add an ingredient line to a recipe", tags=["recipes", "recipe_ingredient_lines"], operation_id="create_recipe_ingredient_line")
async def create_recipe_ingredient_line(recipe_id: int = Path(..., description="Parent recipe ID", example=200), body: RecipeIngredientLineCreateRequest = Body(..., description="Ingredient line payload")) -> RecipeIngredientLineModel:
    session = SessionLocal()
    now = datetime.utcnow()
    obj = RecipeIngredientLine(
        recipe_id=recipe_id,
        ingredient_id=body.ingredient_id,
        position=body.position,
        quantity=body.quantity,
        unit=body.unit,
        line_allergen_flags=body.line_allergen_flags,
        notes=body.notes,
        created_at=now,
        updated_at=now,
    )
    session.add(obj)
    session.commit()
    session.refresh(obj)
    session.close()
    return obj

@app.get("/api/recipes/{recipe_id}/ingredient-lines", response_model=RecipeIngredientLinesListResponse, summary="List ingredient lines", description="List ingredient lines for a recipe", tags=["recipes", "recipe_ingredient_lines"], operation_id="list_recipe_ingredient_lines")
async def list_recipe_ingredient_lines(recipe_id: int = Path(..., description="Recipe ID", example=210)) -> RecipeIngredientLinesListResponse:
    session = SessionLocal()
    rows = session.query(RecipeIngredientLine).filter(RecipeIngredientLine.recipe_id == recipe_id).order_by(RecipeIngredientLine.position.asc()).all()
    session.close()
    return RecipeIngredientLinesListResponse(ingredient_lines=rows)

@app.patch("/api/recipe-ingredient-lines/{line_id}", response_model=RecipeIngredientLineModel, summary="Patch ingredient line", description="Update a recipe ingredient line partially", tags=["recipe_ingredient_lines"], operation_id="patch_recipe_ingredient_line")
async def patch_recipe_ingredient_line(line_id: int = Path(..., description="Ingredient line ID", example=305), body: RecipeIngredientLinePatchRequest = Body(..., description="Fields to update")) -> RecipeIngredientLineModel:
    session = SessionLocal()
    obj = session.query(RecipeIngredientLine).filter(RecipeIngredientLine.id == line_id).first()
    if obj is not None:
        if body.position is not None:
            obj.position = body.position
        if body.quantity is not None:
            obj.quantity = body.quantity
        if body.unit is not None:
            obj.unit = body.unit
        if body.line_allergen_flags is not None:
            obj.line_allergen_flags = body.line_allergen_flags
        if body.notes is not None:
            obj.notes = body.notes
        obj.updated_at = datetime.utcnow()
        session.commit()
        session.refresh(obj)
    session.close()
    if obj is None:
        return RecipeIngredientLineModel(id=0, recipe_id=0, ingredient_id=0, position=0, quantity=0.0, unit="", line_allergen_flags=None, notes=None, created_at=None, updated_at=None)
    return obj

@app.post("/api/recipes/{recipe_id}/steps", response_model=RecipeStepModel, summary="Create recipe step", description="Add a preparation step to a recipe", tags=["recipes", "recipe_steps"], operation_id="create_recipe_step")
async def create_recipe_step(recipe_id: int = Path(..., description="Parent recipe ID", example=200), body: RecipeStepCreateRequest = Body(..., description="Step payload")) -> RecipeStepModel:
    session = SessionLocal()
    now = datetime.utcnow()
    obj = RecipeStep(
        recipe_id=recipe_id,
        step_number=body.step_number,
        description=body.description,
        created_at=now,
        updated_at=now,
    )
    session.add(obj)
    session.commit()
    session.refresh(obj)
    session.close()
    return obj

@app.get("/api/recipes/{recipe_id}/steps", response_model=RecipeStepsListResponse, summary="List recipe steps", description="List preparation steps for a recipe", tags=["recipes", "recipe_steps"], operation_id="list_recipe_steps")
async def list_recipe_steps(recipe_id: int = Path(..., description="Recipe ID", example=200)) -> RecipeStepsListResponse:
    session = SessionLocal()
    rows = session.query(RecipeStep).filter(RecipeStep.recipe_id == recipe_id).order_by(RecipeStep.step_number.asc()).all()
    session.close()
    return RecipeStepsListResponse(steps=rows)

@app.patch("/api/recipe-steps/{step_id}", response_model=RecipeStepModel, summary="Patch recipe step", description="Update a recipe step partially", tags=["recipe_steps"], operation_id="patch_recipe_step")
async def patch_recipe_step(step_id: int = Path(..., description="Recipe step ID", example=400), body: RecipeStepPatchRequest = Body(..., description="Fields to update")) -> RecipeStepModel:
    session = SessionLocal()
    obj = session.query(RecipeStep).filter(RecipeStep.id == step_id).first()
    if obj is not None:
        if body.step_number is not None:
            obj.step_number = body.step_number
        if body.description is not None:
            obj.description = body.description
        obj.updated_at = datetime.utcnow()
        session.commit()
        session.refresh(obj)
    session.close()
    if obj is None:
        return RecipeStepModel(id=0, recipe_id=0, step_number=0, description="", created_at=None, updated_at=None)
    return obj

@app.post("/api/menu-items", response_model=MenuItemModel, summary="Create menu item", description="Create a new menu item", tags=["menu_items"], operation_id="create_menu_item")
async def create_menu_item(body: MenuItemCreateRequest = Body(..., description="Menu item payload")) -> MenuItemModel:
    session = SessionLocal()
    now = datetime.utcnow()
    obj = MenuItem(
        internal_name=body.internal_name,
        recipe_id=body.recipe_id,
        display_name=body.display_name,
        menu_description=body.menu_description,
        base_selling_price=body.base_selling_price,
        active=body.active if body.active is not None else 1,
        created_at=now,
        updated_at=now,
    )
    session.add(obj)
    session.commit()
    session.refresh(obj)
    session.close()
    return obj

@app.get("/api/menu-items", response_model=MenuItemsListResponse, summary="List menu items", description="List menu items with optional filters", tags=["menu_items"], operation_id="list_menu_items")
async def list_menu_items(internal_name: Optional[str] = Query(None, description="Filter by exact or partial internal_name", example="grilled_salmon"), recipe_id: Optional[int] = Query(None, description="Filter by linked recipe ID", example=260), max_food_cost_percent: Optional[float] = Query(None, description="Return items with food_cost_percent <= this value", example=35.0), min_food_cost_percent: Optional[float] = Query(None, description="Return items with food_cost_percent >= this value", example=30.0), active: Optional[int] = Query(None, description="Filter by active flag (1 or 0)", example=1), limit: Optional[int] = Query(100, description="Max menu items to return", example=100), offset: Optional[int] = Query(0, description="Menu items to skip", example=0)) -> MenuItemsListResponse:
    session = SessionLocal()
    query = session.query(MenuItem)
    if internal_name is not None:
        query = query.filter(MenuItem.internal_name.ilike(f"%{internal_name}%"))
    if recipe_id is not None:
        query = query.filter(MenuItem.recipe_id == recipe_id)
    if max_food_cost_percent is not None:
        query = query.filter(MenuItem.food_cost_percent <= max_food_cost_percent)
    if min_food_cost_percent is not None:
        query = query.filter(MenuItem.food_cost_percent >= min_food_cost_percent)
    if active is not None:
        query = query.filter(MenuItem.active == active)
    if offset is not None:
        query = query.offset(offset)
    if limit is not None:
        query = query.limit(limit)
    rows = query.all()
    session.close()
    return MenuItemsListResponse(menu_items=rows)

@app.patch("/api/menu-items/{menu_item_id}", response_model=MenuItemModel, summary="Patch menu item", description="Update a menu item partially", tags=["menu_items"], operation_id="patch_menu_item")
async def patch_menu_item(menu_item_id: int = Path(..., description="Menu item ID", example=510), body: MenuItemPatchRequest = Body(..., description="Fields to update")) -> MenuItemModel:
    session = SessionLocal()
    obj = session.query(MenuItem).filter(MenuItem.id == menu_item_id).first()
    if obj is not None:
        if body.internal_name is not None:
            obj.internal_name = body.internal_name
        if body.recipe_id is not None:
            obj.recipe_id = body.recipe_id
        if body.display_name is not None:
            obj.display_name = body.display_name
        if body.menu_description is not None:
            obj.menu_description = body.menu_description
        if body.base_selling_price is not None:
            obj.base_selling_price = body.base_selling_price
        if body.active is not None:
            obj.active = body.active
        obj.updated_at = datetime.utcnow()
        session.commit()
        session.refresh(obj)
    session.close()
    if obj is None:
        return MenuItemModel(id=0, internal_name="", recipe_id=None, display_name="", menu_description=None, base_selling_price=None, active=0, food_cost_percent=None, suggested_price_min=None, suggested_price_max=None, created_at=None, updated_at=None)
    return obj

@app.post("/api/menu-items/{menu_item_id}/tags", response_model=MenuItemTagModel, summary="Create menu item tag", description="Add a tag to a menu item", tags=["menu_items", "menu_item_tags"], operation_id="create_menu_item_tag")
async def create_menu_item_tag(menu_item_id: int = Path(..., description="Menu item ID to tag", example=500), body: MenuItemTagCreateRequest = Body(..., description="Tag payload")) -> MenuItemTagModel:
    session = SessionLocal()
    now = datetime.utcnow()
    obj = MenuItemTag(menu_item_id=menu_item_id, tag=body.tag, created_at=now)
    session.add(obj)
    session.commit()
    session.refresh(obj)
    session.close()
    return obj

@app.get("/api/menu-items/{menu_item_id}/tags", response_model=MenuItemTagsListResponse, summary="List menu item tags", description="List tags for a menu item", tags=["menu_items", "menu_item_tags"], operation_id="list_menu_item_tags")
async def list_menu_item_tags(menu_item_id: int = Path(..., description="Menu item ID", example=500)) -> MenuItemTagsListResponse:
    session = SessionLocal()
    rows = session.query(MenuItemTag).filter(MenuItemTag.menu_item_id == menu_item_id).all()
    session.close()
    return MenuItemTagsListResponse(tags=rows)

@app.delete("/api/menu-item-tags/{tag_id}", response_model=DeleteResponse, summary="Delete menu item tag", description="Delete a menu item tag", tags=["menu_item_tags"], operation_id="delete_menu_item_tag")
async def delete_menu_item_tag(tag_id: int = Path(..., description="Menu item tag ID to delete", example=600)) -> DeleteResponse:
    session = SessionLocal()
    obj = session.query(MenuItemTag).filter(MenuItemTag.id == tag_id).first()
    deleted = False
    if obj is not None:
        session.delete(obj)
        session.commit()
        deleted = True
    session.close()
    return DeleteResponse(deleted=deleted)

@app.post("/api/availability-windows", response_model=AvailabilityWindowModel, summary="Create availability window", description="Create a generic availability window", tags=["availability", "menu_items", "menus"], operation_id="create_availability_window")
async def create_availability_window(body: AvailabilityWindowCreateRequest = Body(..., description="Availability window payload")) -> AvailabilityWindowModel:
    session = SessionLocal()
    now = datetime.utcnow()
    obj = AvailabilityWindow(
        owner_type=body.owner_type,
        owner_id=body.owner_id,
        day_of_week=body.day_of_week,
        start_time=body.start_time,
        end_time=body.end_time,
        created_at=now,
        updated_at=now,
    )
    session.add(obj)
    session.commit()
    session.refresh(obj)
    session.close()
    return obj

@app.get("/api/availability-windows", response_model=AvailabilityWindowsListResponse, summary="List availability windows", description="List availability windows with filters", tags=["availability"], operation_id="list_availability_windows")
async def list_availability_windows(owner_type: Optional[str] = Query(None, description="Owner type filter", example="menu_item"), owner_id: Optional[int] = Query(None, description="Owner ID filter", example=500), day_of_week: Optional[int] = Query(None, description="Day of week filter", example=4), limit: Optional[int] = Query(100, description="Max windows to return", example=100), offset: Optional[int] = Query(0, description="Windows to skip", example=0)) -> AvailabilityWindowsListResponse:
    session = SessionLocal()
    query = session.query(AvailabilityWindow)
    if owner_type is not None:
        query = query.filter(AvailabilityWindow.owner_type == owner_type)
    if owner_id is not None:
        query = query.filter(AvailabilityWindow.owner_id == owner_id)
    if day_of_week is not None:
        query = query.filter(AvailabilityWindow.day_of_week == day_of_week)
    if offset is not None:
        query = query.offset(offset)
    if limit is not None:
        query = query.limit(limit)
    rows = query.all()
    session.close()
    return AvailabilityWindowsListResponse(availability_windows=rows)

@app.delete("/api/availability-windows/{id}", response_model=DeleteResponse, summary="Delete availability window", description="Delete an availability window", tags=["availability"], operation_id="delete_availability_window")
async def delete_availability_window(id: int = Path(..., description="Availability window ID", example=700)) -> DeleteResponse:
    session = SessionLocal()
    obj = session.query(AvailabilityWindow).filter(AvailabilityWindow.id == id).first()
    deleted = False
    if obj is not None:
        session.delete(obj)
        session.commit()
        deleted = True
    session.close()
    return DeleteResponse(deleted=deleted)

@app.get("/api/menus", response_model=MenusListResponse, summary="List menus", description="List menus with optional filters", tags=["menus"], operation_id="list_menus")
async def list_menus(name: Optional[str] = Query(None, description="Filter by exact or partial menu name", example="Downtown Dinner Winter 2025"), is_template: Optional[int] = Query(None, description="Filter templates (1) vs menus (0)", example=1), season: Optional[str] = Query(None, description="Filter by season label", example="Spring 2025"), base_menu_id: Optional[int] = Query(None, description="Filter by base menu ID", example=20), limit: Optional[int] = Query(50, description="Max menus to return", example=50), offset: Optional[int] = Query(0, description="Menus to skip", example=0)) -> MenusListResponse:
    session = SessionLocal()
    query = session.query(Menu)
    if name is not None:
        query = query.filter(Menu.name.ilike(f"%{name}%"))
    if is_template is not None:
        query = query.filter(Menu.is_template == is_template)
    if season is not None:
        query = query.filter(Menu.season == season)
    if base_menu_id is not None:
        query = query.filter(Menu.base_menu_id == base_menu_id)
    if offset is not None:
        query = query.offset(offset)
    if limit is not None:
        query = query.limit(limit)
    rows = query.all()
    session.close()
    return MenusListResponse(menus=rows)

@app.post("/api/menus", response_model=MenuModel, summary="Create menu", description="Create a new menu", tags=["menus"], operation_id="create_menu")
async def create_menu(body: MenuCreateRequest = Body(..., description="Menu payload")) -> MenuModel:
    session = SessionLocal()
    now = datetime.utcnow()
    obj = Menu(
        name=body.name,
        season=body.season,
        is_template=body.is_template,
        base_menu_id=body.base_menu_id,
        default_daypart=body.default_daypart,
        created_at=now,
        updated_at=now,
    )
    session.add(obj)
    session.commit()
    session.refresh(obj)
    session.close()
    return obj

@app.patch("/api/menus/{menu_id}", response_model=MenuModel, summary="Patch menu", description="Update a menu partially", tags=["menus"], operation_id="patch_menu")
async def patch_menu(menu_id: int = Path(..., description="Menu ID to update", example=40), body: MenuPatchRequest = Body(..., description="Fields to update")) -> MenuModel:
    session = SessionLocal()
    obj = session.query(Menu).filter(Menu.id == menu_id).first()
    if obj is not None:
        if body.name is not None:
            obj.name = body.name
        if body.season is not None:
            obj.season = body.season
        if body.is_template is not None:
            obj.is_template = body.is_template
        if body.base_menu_id is not None:
            obj.base_menu_id = body.base_menu_id
        if body.default_daypart is not None:
            obj.default_daypart = body.default_daypart
        obj.updated_at = datetime.utcnow()
        session.commit()
        session.refresh(obj)
    session.close()
    if obj is None:
        return MenuModel(id=0, name="", season=None, is_template=0, base_menu_id=None, default_daypart=None, created_at=None, updated_at=None)
    return obj

@app.post("/api/menus/{menu_id}/sections", response_model=MenuSectionModel, summary="Create menu section", description="Create a new menu section", tags=["menus", "menu_sections"], operation_id="create_menu_section")
async def create_menu_section(menu_id: int = Path(..., description="Parent menu ID", example=30), body: MenuSectionCreateRequest = Body(..., description="Section payload")) -> MenuSectionModel:
    session = SessionLocal()
    now = datetime.utcnow()
    obj = MenuSection(
        menu_id=menu_id,
        name=body.name,
        position=body.position,
        created_at=now,
        updated_at=now,
    )
    session.add(obj)
    session.commit()
    session.refresh(obj)
    session.close()
    return obj

@app.get("/api/menus/{menu_id}/sections", response_model=MenuSectionsListResponse, summary="List menu sections", description="List sections for a menu", tags=["menus", "menu_sections"], operation_id="list_menu_sections")
async def list_menu_sections(menu_id: int = Path(..., description="Menu ID", example=30)) -> MenuSectionsListResponse:
    session = SessionLocal()
    rows = session.query(MenuSection).filter(MenuSection.menu_id == menu_id).order_by(MenuSection.position.asc()).all()
    session.close()
    return MenuSectionsListResponse(sections=rows)

@app.patch("/api/menu-sections/{section_id}", response_model=MenuSectionModel, summary="Patch menu section", description="Update a menu section partially", tags=["menu_sections"], operation_id="patch_menu_section")
async def patch_menu_section(section_id: int = Path(..., description="Section ID", example=780), body: MenuSectionPatchRequest = Body(..., description="Fields to update")) -> MenuSectionModel:
    session = SessionLocal()
    obj = session.query(MenuSection).filter(MenuSection.id == section_id).first()
    if obj is not None:
        if body.name is not None:
            obj.name = body.name
        if body.position is not None:
            obj.position = body.position
        obj.updated_at = datetime.utcnow()
        session.commit()
        session.refresh(obj)
    session.close()
    if obj is None:
        return MenuSectionModel(id=0, menu_id=0, name="", position=0, created_at=None, updated_at=None)
    return obj

@app.post("/api/menu-sections/{section_id}/items", response_model=MenuSectionItemModel, summary="Create menu section item", description="Add a menu item to a section", tags=["menu_sections", "menu_section_items"], operation_id="create_menu_section_item")
async def create_menu_section_item(section_id: int = Path(..., description="Menu section ID", example=800), body: MenuSectionItemCreateRequest = Body(..., description="Section item payload")) -> MenuSectionItemModel:
    session = SessionLocal()
    now = datetime.utcnow()
    obj = MenuSectionItem(
        menu_section_id=section_id,
        menu_item_id=body.menu_item_id,
        position=body.position,
        created_at=now,
        updated_at=now,
    )
    session.add(obj)
    session.commit()
    session.refresh(obj)
    session.close()
    return obj

@app.get("/api/menu-sections/{section_id}/items", response_model=MenuSectionItemsListResponse, summary="List menu section items", description="List items in a menu section", tags=["menu_sections", "menu_section_items"], operation_id="list_menu_section_items")
async def list_menu_section_items(section_id: int = Path(..., description="Menu section ID", example=800)) -> MenuSectionItemsListResponse:
    session = SessionLocal()
    rows = session.query(MenuSectionItem).filter(MenuSectionItem.menu_section_id == section_id).order_by(MenuSectionItem.position.asc()).all()
    session.close()
    return MenuSectionItemsListResponse(section_items=rows)

@app.patch("/api/menu-section-items/{section_item_id}", response_model=MenuSectionItemModel, summary="Patch menu section item", description="Update a menu section item partially", tags=["menu_section_items"], operation_id="patch_menu_section_item")
async def patch_menu_section_item(section_item_id: int = Path(..., description="Menu section item ID", example=900), body: MenuSectionItemPatchRequest = Body(..., description="Fields to update")) -> MenuSectionItemModel:
    session = SessionLocal()
    obj = session.query(MenuSectionItem).filter(MenuSectionItem.id == section_item_id).first()
    if obj is not None:
        if body.menu_item_id is not None:
            obj.menu_item_id = body.menu_item_id
        if body.position is not None:
            obj.position = body.position
        obj.updated_at = datetime.utcnow()
        session.commit()
        session.refresh(obj)
    session.close()
    if obj is None:
        return MenuSectionItemModel(id=0, menu_section_id=0, menu_item_id=0, position=0, created_at=None, updated_at=None)
    return obj

@app.get("/api/locations", response_model=LocationsListResponse, summary="List locations", description="List locations with optional filters", tags=["locations"], operation_id="list_locations")
async def list_locations(name: Optional[str] = Query(None, description="Filter by exact or partial location name", example="Uptown Bistro"), region: Optional[str] = Query(None, description="Filter by region tag", example="Northeast"), limit: Optional[int] = Query(20, description="Max locations to return", example=20), offset: Optional[int] = Query(0, description="Locations to skip", example=0)) -> LocationsListResponse:
    session = SessionLocal()
    query = session.query(Location)
    if name is not None:
        query = query.filter(Location.name.ilike(f"%{name}%"))
    if region is not None:
        query = query.filter(Location.region == region)
    if offset is not None:
        query = query.offset(offset)
    if limit is not None:
        query = query.limit(limit)
    rows = query.all()
    session.close()
    return LocationsListResponse(locations=rows)

@app.post("/api/location-menu-templates", response_model=LocationMenuTemplateModel, summary="Create location menu template", description="Attach a menu template to a location", tags=["locations", "menus", "location_menu_templates"], operation_id="create_location_menu_template")
async def create_location_menu_template(body: LocationMenuTemplateCreateRequest = Body(..., description="Location menu template payload")) -> LocationMenuTemplateModel:
    session = SessionLocal()
    now = datetime.utcnow()
    obj = LocationMenuTemplate(
        location_id=body.location_id,
        menu_id=body.menu_id,
        weekends_only=body.weekends_only if body.weekends_only is not None else 0,
        created_at=now,
        updated_at=now,
    )
    session.add(obj)
    session.commit()
    session.refresh(obj)
    session.close()
    return obj

@app.get("/api/location-menu-templates", response_model=LocationMenuTemplatesListResponse, summary="List location menu templates", description="List location menu templates", tags=["location_menu_templates"], operation_id="list_location_menu_templates")
async def list_location_menu_templates(location_id: Optional[int] = Query(None, description="Filter by location ID", example=10), menu_id: Optional[int] = Query(None, description="Filter by menu ID", example=45)) -> LocationMenuTemplatesListResponse:
    session = SessionLocal()
    query = session.query(LocationMenuTemplate)
    if location_id is not None:
        query = query.filter(LocationMenuTemplate.location_id == location_id)
    if menu_id is not None:
        query = query.filter(LocationMenuTemplate.menu_id == menu_id)
    rows = query.all()
    session.close()
    return LocationMenuTemplatesListResponse(location_menu_templates=rows)

@app.patch("/api/location-menu-templates/{id}", response_model=LocationMenuTemplateModel, summary="Patch location menu template", description="Update a location menu template link", tags=["location_menu_templates"], operation_id="patch_location_menu_template")
async def patch_location_menu_template(id: int = Path(..., description="Location-menu template link ID", example=1000), body: LocationMenuTemplatePatchRequest = Body(..., description="Fields to update")) -> LocationMenuTemplateModel:
    session = SessionLocal()
    obj = session.query(LocationMenuTemplate).filter(LocationMenuTemplate.id == id).first()
    if obj is not None:
        if body.location_id is not None:
            obj.location_id = body.location_id
        if body.menu_id is not None:
            obj.menu_id = body.menu_id
        if body.weekends_only is not None:
            obj.weekends_only = body.weekends_only
        obj.updated_at = datetime.utcnow()
        session.commit()
        session.refresh(obj)
    session.close()
    if obj is None:
        return LocationMenuTemplateModel(id=0, location_id=0, menu_id=0, weekends_only=0, created_at=None, updated_at=None)
    return obj

@app.post("/api/location-menu-versions", response_model=LocationMenuVersionModel, summary="Create location menu version", description="Create a new location menu version", tags=["location_menu_versions"], operation_id="create_location_menu_version")
async def create_location_menu_version(body: LocationMenuVersionCreateRequest = Body(..., description="Location menu version payload")) -> LocationMenuVersionModel:
    session = SessionLocal()
    now = datetime.utcnow()
    obj = LocationMenuVersion(
        location_id=body.location_id,
        menu_id=body.menu_id,
        version_number=body.version_number,
        is_published=body.is_published if body.is_published is not None else 0,
        published_at=None,
        audit_note=body.audit_note,
        created_at=now,
        updated_at=now,
        created_by=1,
    )
    session.add(obj)
    session.commit()
    session.refresh(obj)
    session.close()
    return obj

@app.patch("/api/location-menu-versions/{version_id}", response_model=LocationMenuVersionModel, summary="Patch location menu version", description="Update a location menu version partially", tags=["location_menu_versions"], operation_id="patch_location_menu_version")
async def patch_location_menu_version(version_id: int = Path(..., description="Location menu version ID", example=1100), body: LocationMenuVersionPatchRequest = Body(..., description="Fields to update")) -> LocationMenuVersionModel:
    session = SessionLocal()
    obj = session.query(LocationMenuVersion).filter(LocationMenuVersion.id == version_id).first()
    if obj is not None:
        if body.version_number is not None:
            obj.version_number = body.version_number
        if body.is_published is not None:
            obj.is_published = body.is_published
        if body.published_at is not None or body.is_published == 0:
            obj.published_at = body.published_at
        if body.audit_note is not None:
            obj.audit_note = body.audit_note
        obj.updated_at = datetime.utcnow()
        session.commit()
        session.refresh(obj)
    session.close()
    if obj is None:
        return LocationMenuVersionModel(id=0, location_id=0, menu_id=0, version_number=0, is_published=0, published_at=None, audit_note=None, created_at=None, updated_at=None, created_by=None)
    return obj

@app.get("/api/location-menu-versions", response_model=LocationMenuVersionsListResponse, summary="List location menu versions", description="List location menu versions", tags=["location_menu_versions"], operation_id="list_location_menu_versions")
async def list_location_menu_versions(location_id: Optional[int] = Query(None, description="Filter by location ID", example=20), menu_id: Optional[int] = Query(None, description="Filter by menu ID", example=60), is_published: Optional[int] = Query(None, description="Filter by published flag (1/0)", example=1)) -> LocationMenuVersionsListResponse:
    session = SessionLocal()
    query = session.query(LocationMenuVersion)
    if location_id is not None:
        query = query.filter(LocationMenuVersion.location_id == location_id)
    if menu_id is not None:
        query = query.filter(LocationMenuVersion.menu_id == menu_id)
    if is_published is not None:
        query = query.filter(LocationMenuVersion.is_published == is_published)
    rows = query.all()
    session.close()
    return LocationMenuVersionsListResponse(location_menu_versions=rows)

@app.post("/api/location-menu-items", response_model=LocationMenuItemModel, summary="Create location menu item", description="Create a location-specific menu item override", tags=["location_menu_items"], operation_id="create_location_menu_item")
async def create_location_menu_item(body: LocationMenuItemCreateRequest = Body(..., description="Location menu item payload")) -> LocationMenuItemModel:
    session = SessionLocal()
    now = datetime.utcnow()
    obj = LocationMenuItem(
        location_id=body.location_id,
        menu_item_id=body.menu_item_id,
        menu_version_id=body.menu_version_id,
        override_selling_price=body.override_selling_price,
        is_published=body.is_published if body.is_published is not None else 1,
        created_at=now,
        updated_at=now,
    )
    session.add(obj)
    session.commit()
    session.refresh(obj)
    session.close()
    return obj

@app.get("/api/location-menu-items", response_model=LocationMenuItemsListResponse, summary="List location menu items", description="List location-specific menu items", tags=["location_menu_items"], operation_id="list_location_menu_items")
async def list_location_menu_items(location_id: Optional[int] = Query(None, description="Filter by location ID", example=10), menu_item_id: Optional[int] = Query(None, description="Filter by menu item ID", example=510), menu_version_id: Optional[int] = Query(None, description="Filter by menu version ID", example=1100), is_published: Optional[int] = Query(None, description="Filter by published flag (1/0)", example=1)) -> LocationMenuItemsListResponse:
    session = SessionLocal()
    query = session.query(LocationMenuItem)
    if location_id is not None:
        query = query.filter(LocationMenuItem.location_id == location_id)
    if menu_item_id is not None:
        query = query.filter(LocationMenuItem.menu_item_id == menu_item_id)
    if menu_version_id is not None:
        query = query.filter(LocationMenuItem.menu_version_id == menu_version_id)
    if is_published is not None:
        query = query.filter(LocationMenuItem.is_published == is_published)
    rows = query.all()
    session.close()
    return LocationMenuItemsListResponse(location_menu_items=rows)

@app.patch("/api/location-menu-items/{id}", response_model=LocationMenuItemModel, summary="Patch location menu item", description="Update a location menu item override", tags=["location_menu_items"], operation_id="patch_location_menu_item")
async def patch_location_menu_item(id: int = Path(..., description="Location menu item ID", example=1200), body: LocationMenuItemPatchRequest = Body(..., description="Fields to update")) -> LocationMenuItemModel:
    session = SessionLocal()
    obj = session.query(LocationMenuItem).filter(LocationMenuItem.id == id).first()
    if obj is not None:
        if body.menu_version_id is not None or body.menu_version_id is None:
            obj.menu_version_id = body.menu_version_id
        if body.override_selling_price is not None:
            obj.override_selling_price = body.override_selling_price
        if body.is_published is not None:
            obj.is_published = body.is_published
        obj.updated_at = datetime.utcnow()
        session.commit()
        session.refresh(obj)
    session.close()
    if obj is None:
        return LocationMenuItemModel(id=0, location_id=0, menu_item_id=0, menu_version_id=None, override_selling_price=None, is_published=0, created_at=None, updated_at=None)
    return obj

@app.post("/api/location-menu-items/{location_menu_item_id}/availability", response_model=LocationMenuItemAvailabilityModel, summary="Create location menu item availability", description="Add availability to a location menu item", tags=["location_menu_items", "location_menu_item_availability"], operation_id="create_location_menu_item_availability")
async def create_location_menu_item_availability(location_menu_item_id: int = Path(..., description="Location menu item ID", example=1200), body: LocationMenuItemAvailabilityCreateRequest = Body(..., description="Availability payload")) -> LocationMenuItemAvailabilityModel:
    session = SessionLocal()
    now = datetime.utcnow()
    obj = LocationMenuItemAvailability(
        location_menu_item_id=location_menu_item_id,
        day_of_week=body.day_of_week,
        start_time=body.start_time,
        end_time=body.end_time,
        created_at=now,
        updated_at=now,
    )
    session.add(obj)
    session.commit()
    session.refresh(obj)
    session.close()
    return obj

@app.get("/api/location-menu-items/{location_menu_item_id}/availability", response_model=LocationMenuItemAvailabilityListResponse, summary="List location menu item availability", description="List availability for a location menu item", tags=["location_menu_item_availability"], operation_id="list_location_menu_item_availability")
async def list_location_menu_item_availability(location_menu_item_id: int = Path(..., description="Location menu item ID", example=1200)) -> LocationMenuItemAvailabilityListResponse:
    session = SessionLocal()
    rows = session.query(LocationMenuItemAvailability).filter(LocationMenuItemAvailability.location_menu_item_id == location_menu_item_id).all()
    session.close()
    return LocationMenuItemAvailabilityListResponse(availability=rows)

@app.delete("/api/location-menu-item-availability/{id}", response_model=DeleteResponse, summary="Delete location menu item availability", description="Delete location menu item availability", tags=["location_menu_item_availability"], operation_id="delete_location_menu_item_availability")
async def delete_location_menu_item_availability(id: int = Path(..., description="Location menu item availability ID", example=1300)) -> DeleteResponse:
    session = SessionLocal()
    obj = session.query(LocationMenuItemAvailability).filter(LocationMenuItemAvailability.id == id).first()
    deleted = False
    if obj is not None:
        session.delete(obj)
        session.commit()
        deleted = True
    session.close()
    return DeleteResponse(deleted=deleted)

@app.post("/api/menu-item-cost-cache/recalculate", response_model=MenuItemCostCacheRecalculateResponse, summary="Recalculate cost cache", description="Recalculate cost cache for menu items", tags=["analytics", "menu_item_cost_cache"], operation_id="recalculate_menu_item_cost_cache")
async def recalculate_menu_item_cost_cache(body: MenuItemCostCacheRecalculateRequest = Body(None, description="Optional list of menu item IDs")) -> MenuItemCostCacheRecalculateResponse:
    session = SessionLocal()
    query = session.query(MenuItem).filter(MenuItem.recipe_id.isnot(None))
    if body is not None and body.menu_item_ids is not None and len(body.menu_item_ids) > 0:
        query = query.filter(MenuItem.id.in_(body.menu_item_ids))
    menu_items = query.all()
    recalculated_list: List[MenuItemCostCacheRecalculateItemModel] = []
    now = datetime.utcnow()
    for item in menu_items:
        recipe = session.query(Recipe).filter(Recipe.id == item.recipe_id).first()
        if recipe is None or recipe.yield_quantity is None or recipe.yield_quantity == 0:
            continue
        lines = session.query(RecipeIngredientLine).filter(RecipeIngredientLine.recipe_id == recipe.id).all()
        total_cost = 0.0
        for line in lines:
            ing = session.query(Ingredient).filter(Ingredient.id == line.ingredient_id).first()
            if ing is not None and ing.unit_cost is not None:
                total_cost += ing.unit_cost * line.quantity
        cost_per_serving = total_cost / recipe.yield_quantity if recipe.yield_quantity != 0 else 0.0
        if item.base_selling_price is not None and item.base_selling_price > 0:
            food_cost_percent = cost_per_serving / item.base_selling_price * 100.0
        else:
            food_cost_percent = 0.0
        suggested_price_min = cost_per_serving * 3.0
        suggested_price_max = cost_per_serving * 4.0
        cache = session.query(MenuItemCostCache).filter(MenuItemCostCache.menu_item_id == item.id).first()
        if cache is None:
            cache = MenuItemCostCache(
                menu_item_id=item.id,
                last_calculated_at=now,
                total_ingredient_cost=cost_per_serving,
                food_cost_percent=food_cost_percent,
                suggested_price_min=suggested_price_min,
                suggested_price_max=suggested_price_max,
                created_at=now,
                updated_at=now,
            )
            session.add(cache)
        else:
            cache.last_calculated_at = now
            cache.total_ingredient_cost = cost_per_serving
            cache.food_cost_percent = food_cost_percent
            cache.suggested_price_min = suggested_price_min
            cache.suggested_price_max = suggested_price_max
            cache.updated_at = now
        item.food_cost_percent = food_cost_percent
        item.suggested_price_min = suggested_price_min
        item.suggested_price_max = suggested_price_max
        item.updated_at = now
        recalculated_list.append(
            MenuItemCostCacheRecalculateItemModel(
                menu_item_id=item.id,
                total_ingredient_cost=cost_per_serving,
                food_cost_percent=food_cost_percent,
                suggested_price_min=suggested_price_min,
                suggested_price_max=suggested_price_max,
                last_calculated_at=now,
            )
        )
    session.commit()
    session.close()
    return MenuItemCostCacheRecalculateResponse(recalculated_items=recalculated_list)

@app.get("/api/menu-item-cost-cache", response_model=MenuItemCostCacheListResponse, summary="List cost cache", description="List menu item cost cache entries", tags=["analytics", "menu_item_cost_cache"], operation_id="list_menu_item_cost_cache")
async def list_menu_item_cost_cache(menu_item_id: Optional[int] = Query(None, description="Filter by a specific menu_item ID", example=510), min_food_cost_percent: Optional[float] = Query(None, description="Filter entries where food_cost_percent >= value", example=35.0), max_food_cost_percent: Optional[float] = Query(None, description="Filter entries where food_cost_percent <= value", example=50.0)) -> MenuItemCostCacheListResponse:
    session = SessionLocal()
    query = session.query(MenuItemCostCache)
    if menu_item_id is not None:
        query = query.filter(MenuItemCostCache.menu_item_id == menu_item_id)
    if min_food_cost_percent is not None:
        query = query.filter(MenuItemCostCache.food_cost_percent >= min_food_cost_percent)
    if max_food_cost_percent is not None:
        query = query.filter(MenuItemCostCache.food_cost_percent <= max_food_cost_percent)
    rows = query.all()
    session.close()
    entries: List[MenuItemCostCacheEntryModel] = []
    for row in rows:
        entries.append(
            MenuItemCostCacheEntryModel(
                menu_item_id=row.menu_item_id,
                last_calculated_at=row.last_calculated_at,
                total_ingredient_cost=row.total_ingredient_cost,
                food_cost_percent=row.food_cost_percent,
                suggested_price_min=row.suggested_price_min,
                suggested_price_max=row.suggested_price_max,
            )
        )
    return MenuItemCostCacheListResponse(cost_cache_entries=entries)

@app.get("/api/analytics/worst-margin-items", response_model=WorstMarginItemsResponse, summary="Worst-margin items", description="Get worst-margin menu items grouped by location and daypart", tags=["analytics"], operation_id="get_worst_margin_items")
async def get_worst_margin_items(threshold_percent: Optional[float] = Query(35.0, description="Minimum food_cost_percent to consider as bad margin", example=35.0), limit: Optional[int] = Query(10, description="Total number of worst-margin items to return", example=10)) -> WorstMarginItemsResponse:
    session = SessionLocal()
    rows = []
    loc_items = session.query(LocationMenuItem, MenuItem, Location, MenuItemCostCache).join(MenuItem, LocationMenuItem.menu_item_id == MenuItem.id).join(Location, LocationMenuItem.location_id == Location.id).outerjoin(MenuItemCostCache, MenuItemCostCache.menu_item_id == MenuItem.id).filter(LocationMenuItem.is_published == 1).all()
    for loc_item, item, loc, cache in loc_items:
        if cache is None or cache.food_cost_percent is None:
            continue
        if threshold_percent is not None and cache.food_cost_percent < threshold_percent:
            continue
        sections = session.query(MenuSection, Menu).join(Menu, MenuSection.menu_id == Menu.id).join(MenuSectionItem, MenuSectionItem.menu_section_id == MenuSection.id).filter(MenuSectionItem.menu_item_id == item.id).first()
        daypart = None
        if sections is not None:
            sec, menu = sections
            daypart = menu.default_daypart
        price = loc_item.override_selling_price if loc_item.override_selling_price is not None else item.base_selling_price
        rows.append(
            WorstMarginItemModel(
                location_id=loc.id,
                location_name=loc.name,
                daypart=daypart,
                menu_item_id=item.id,
                menu_item_display_name=item.display_name,
                recipe_id=item.recipe_id,
                current_selling_price=price,
                suggested_price_min=cache.suggested_price_min,
                suggested_price_max=cache.suggested_price_max,
                food_cost_percent=cache.food_cost_percent,
            )
        )
    rows.sort(key=lambda x: (x.food_cost_percent if x.food_cost_percent is not None else 0.0), reverse=True)
    if limit is not None:
        rows = rows[:limit]
    session.close()
    return WorstMarginItemsResponse(items=rows)

@app.post("/api/analytics/price-list-margin-impact-report", response_model=PriceListMarginImpactResponse, summary="Price list margin impact", description="Generate margin impact report for a price list", tags=["analytics", "price_lists"], operation_id="generate_price_list_margin_impact_report")
async def generate_price_list_margin_impact_report(body: PriceListMarginImpactRequest = Body(..., description="Price list margin impact payload")) -> PriceListMarginImpactResponse:
    session = SessionLocal()
    threshold_margin = body.margin_threshold_percent if body.margin_threshold_percent is not None else 70.0
    ing_costs: Dict[int, float] = {}
    ing_sup_rows = session.query(IngredientSupplier).filter(IngredientSupplier.price_list_id == body.price_list_id).all()
    for row in ing_sup_rows:
        if row.unit_cost is not None:
            ing_costs[row.ingredient_id] = row.unit_cost
    affected_items: List[PriceListMarginImpactItemModel] = []
    items = session.query(MenuItem).filter(MenuItem.recipe_id.isnot(None)).all()
    now = datetime.utcnow()
    for item in items:
        recipe = session.query(Recipe).filter(Recipe.id == item.recipe_id).first()
        if recipe is None or recipe.yield_quantity is None or recipe.yield_quantity == 0:
            continue
        lines = session.query(RecipeIngredientLine).filter(RecipeIngredientLine.recipe_id == recipe.id).all()
        total_cost = 0.0
        for line in lines:
            cost_override = ing_costs.get(line.ingredient_id)
            if cost_override is not None:
                total_cost += cost_override * line.quantity
            else:
                ing = session.query(Ingredient).filter(Ingredient.id == line.ingredient_id).first()
                if ing is not None and ing.unit_cost is not None:
                    total_cost += ing.unit_cost * line.quantity
        cost_per_serving = total_cost / recipe.yield_quantity if recipe.yield_quantity != 0 else 0.0
        effective_price = item.base_selling_price if item.base_selling_price is not None else 0.0
        food_cost_percent = cost_per_serving / effective_price * 100.0 if effective_price > 0 else 0.0
        margin_percent = 100.0 - food_cost_percent
        suggested_price_min = cost_per_serving * 3.0
        suggested_price_max = cost_per_serving * 4.0
        if margin_percent < threshold_margin:
            affected_items.append(
                PriceListMarginImpactItemModel(
                    menu_item_id=item.id,
                    menu_item_display_name=item.display_name,
                    location_id=None,
                    location_name="",
                    current_selling_price=effective_price,
                    total_ingredient_cost=cost_per_serving,
                    food_cost_percent=food_cost_percent,
                    margin_percent=margin_percent,
                    suggested_price_min=suggested_price_min,
                    suggested_price_max=suggested_price_max,
                )
            )
        cache = session.query(MenuItemCostCache).filter(MenuItemCostCache.menu_item_id == item.id).first()
        if cache is None:
            cache = MenuItemCostCache(
                menu_item_id=item.id,
                last_calculated_at=now,
                total_ingredient_cost=cost_per_serving,
                food_cost_percent=food_cost_percent,
                suggested_price_min=suggested_price_min,
                suggested_price_max=suggested_price_max,
                created_at=now,
                updated_at=now,
            )
            session.add(cache)
        else:
            cache.last_calculated_at = now
            cache.total_ingredient_cost = cost_per_serving
            cache.food_cost_percent = food_cost_percent
            cache.suggested_price_min = suggested_price_min
            cache.suggested_price_max = suggested_price_max
            cache.updated_at = now
        item.food_cost_percent = food_cost_percent
        item.suggested_price_min = suggested_price_min
        item.suggested_price_max = suggested_price_max
        item.updated_at = now
    session.commit()
    session.close()
    return PriceListMarginImpactResponse(price_list_id=body.price_list_id, margin_threshold_percent=threshold_margin, affected_menu_items=affected_items)

@app.post("/api/menus/{menu_id}/clone", response_model=CloneMenuResponse, summary="Clone menu", description="Clone a menu with sections and items", tags=["menus", "cloning"], operation_id="clone_menu_with_structure")
async def clone_menu_with_structure(menu_id: int = Path(..., description="Source menu ID to clone", example=40), body: CloneMenuRequest = Body(..., description="Clone menu payload")) -> CloneMenuResponse:
    session = SessionLocal()
    src_menu = session.query(Menu).filter(Menu.id == menu_id).first()
    if src_menu is None:
        new_menu_model = CloneMenuNewMenuModel(id=0, name=body.new_name, season=body.new_season, is_template=body.is_template if body.is_template is not None else 1, base_menu_id=None, default_daypart=None)
        session.close()
        return CloneMenuResponse(new_menu=new_menu_model, cloned_sections=[], cloned_section_items=[])
    now = datetime.utcnow()
    new_menu = Menu(
        name=body.new_name,
        season=body.new_season if body.new_season is not None else src_menu.season,
        is_template=body.is_template if body.is_template is not None else src_menu.is_template,
        base_menu_id=src_menu.id,
        default_daypart=src_menu.default_daypart,
        created_at=now,
        updated_at=now,
    )
    session.add(new_menu)
    session.commit()
    session.refresh(new_menu)
    src_sections = session.query(MenuSection).filter(MenuSection.menu_id == src_menu.id).all()
    cloned_sections: List[ClonedSectionModel] = []
    section_id_map: Dict[int, int] = {}
    for sec in src_sections:
        new_sec = MenuSection(
            menu_id=new_menu.id,
            name=sec.name,
            position=sec.position,
            created_at=now,
            updated_at=now,
        )
        session.add(new_sec)
        session.commit()
        session.refresh(new_sec)
        section_id_map[sec.id] = new_sec.id
        cloned_sections.append(
            ClonedSectionModel(
                old_section_id=sec.id,
                new_section_id=new_sec.id,
                name=new_sec.name,
                position=new_sec.position,
            )
        )
    cloned_section_items: List[ClonedSectionItemModel] = []
    for sec in src_sections:
        new_sec_id = section_id_map.get(sec.id)
        if new_sec_id is None:
            continue
        items = session.query(MenuSectionItem).filter(MenuSectionItem.menu_section_id == sec.id).all()
        for it in items:
            new_it = MenuSectionItem(
                menu_section_id=new_sec_id,
                menu_item_id=it.menu_item_id,
                position=it.position,
                created_at=now,
                updated_at=now,
            )
            session.add(new_it)
            session.commit()
            session.refresh(new_it)
            cloned_section_items.append(
                ClonedSectionItemModel(
                    old_section_item_id=it.id,
                    new_section_item_id=new_it.id,
                    new_section_id=new_sec_id,
                    menu_item_id=new_it.menu_item_id,
                    position=new_it.position,
                )
            )
    session.close()
    new_menu_model = CloneMenuNewMenuModel(
        id=new_menu.id,
        name=new_menu.name,
        season=new_menu.season,
        is_template=new_menu.is_template,
        base_menu_id=new_menu.base_menu_id,
        default_daypart=new_menu.default_daypart,
    )
    return CloneMenuResponse(new_menu=new_menu_model, cloned_sections=cloned_sections, cloned_section_items=cloned_section_items)

if __name__ == "__main__":
    import uvicorn
    host = os.getenv("HOST", "127.0.0.1")
    port = int(os.getenv("PORT", "8000"))
    uvicorn.run(app, host=host, port=port)