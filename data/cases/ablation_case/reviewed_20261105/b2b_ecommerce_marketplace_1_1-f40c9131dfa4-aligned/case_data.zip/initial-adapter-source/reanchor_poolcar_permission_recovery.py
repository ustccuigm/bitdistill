"""Reanchor one real sampled failure after a student clears permissions.

No task, database business rules, model outputs, or native verifier are edited.
The fixed reference suffix is replayed from the newly saved failure state.
"""
import copy
import fcntl
import hashlib
import json
from pathlib import Path
import shutil
import sys

import guidance_only_existing_cases as g
from relational_ablation_candidates import logical_state, state_hash

b, m = g.b, g.m
R = Path('/mnt/genming/ablation-poolcar-reanchored-20261105')
NAME = 'poolcar-after-permission-clear'
SOURCE = Path('/mnt/genming/ablation-balanced-gemma-followup-20261105/cases/booking_and_reservations_4_4-2adb87325b31-aligned')


def common_evidence(case):
    receipt = m.load(case / 'reference-alignment/receipt.json')
    turn = receipt['alignment']['reference_turn']
    return dict(task=m.load(case / 'analysis_context.json')['task'],
        current_context=m.load(case / 'context.json'),
        failed_decision=m.load(case / 'before/response.json')['choices'][0]['message'],
        failed_execution=m.load(case / 'before/execution.json'), tools=m.load(case / 'tools.json'),
        aligned_reference_decision=m.load(case / 'reference' / turn / 'response.json')['choices'][0]['message'],
        aligned_reference_execution=m.load(case / 'reference-alignment' / turn / 'execution.json'),
        reference_verified=receipt['verifier'], retry_feedback=[])


def prepare(name):
    assert name == NAME
    case = R / 'cases' / name
    if (case / 'prepared.json').exists():
        return case, None, common_evidence(case)
    case.mkdir(parents=True, exist_ok=True)
    old = m.load(SOURCE / 'comparison.json')
    failed = Path(old['controls']['teacher_freeform']['selected']['sample'])
    failed_request = m.load(failed / 'turn-001/request.json')
    assert failed_request['messages'][0] == m.load(SOURCE / 'context.json')[0]
    assert not m.load(failed / 'turn-001/response.json')['choices'][0]['message'].get('tool_calls')
    for filename in ['initial.db', 'tools.json', 'task_verifier.py', 'state-projection.json']:
        shutil.copy2(SOURCE / filename, case / filename)
    original = Path('/mnt/genming/Arctic-AWM-BitDistiller-full/arctic_quant/common/data/awm_source/gen_verifier.pure_code.jsonl')
    verifier = next(json.loads(line)['verification']['code'] for line in original.read_text().splitlines()
                    if json.loads(line)['scenario'] == 'booking_and_reservations_4' and json.loads(line)['task_idx'] == 4)
    assert (case / 'task_verifier.py').read_text() == verifier
    m.dump(case / 'context.json', failed_request['messages'])
    m.dump(case / 'analysis_context.json', dict(task=m.load(SOURCE / 'analysis_context.json')['task']))
    shutil.copy2(failed / 'local_state.db', case / 'pre_state.db')
    spec = m.load(SOURCE / 'protocol.json')
    spec.update(mode='relational_transition', pre_state_sha256=m.digest(case / 'pre_state.db'),
                source_request=str(failed / 'turn-001/request.json'),
                guidance_scope='first revised response only',
                recovery_anchor='Actual student cleared policy 3 permissions and then stopped to ask for confirmation')
    m.dump(case / 'protocol.json', spec)
    # Verify the entire actual source action from its own exact starting state.
    prefix = case / 'student-prefix-replay'
    prefix.mkdir(exist_ok=True)
    db = prefix / 'replayed.db'
    shutil.copy2(SOURCE / 'pre_state.db', db)
    env = m.open_env(case, db, prefix)
    messages = copy.deepcopy(m.load(SOURCE / 'context.json'))
    msg = m.normalize(m.load(failed / 'turn-000/response.json')['choices'][0]['message'])
    events = m.execute(env, messages, msg, prefix / 'turn-000')
    assert events == m.load(failed / 'turn-000/execution.json')
    assert logical_state(db) == logical_state(case / 'pre_state.db')
    assert messages == failed_request['messages']
    m.dump(prefix / 'receipt.json', dict(verified=True, actual_student_actions_reexecuted=True,
           full_logical_state_equal=True, exact_context_equal=True, source=str(failed)))
    before = case / 'before'
    before.mkdir(exist_ok=True)
    for filename in ['request.json', 'response.json']:
        shutil.copy2(failed / 'turn-001' / filename, before / filename)
    shutil.copy2(case / 'pre_state.db', before / 'final.db')
    env = m.open_env(case, before / 'final.db', before)
    final_msg = m.normalize(m.load(before / 'response.json')['choices'][0]['message'])
    m.execute(env, copy.deepcopy(failed_request['messages']), final_msg, before)
    assert m.load(before / 'execution.json') == []
    failure = m.verifier(case, before / 'final.db', final_msg.get('content', ''))
    assert failure['result'] != 'complete'
    m.dump(before / 'evaluation.json', failure)
    # Only the real, later successful BF16 suffix is reused; no actions invented.
    ref = case / 'reference'
    ref.mkdir(exist_ok=True)
    for new_turn, old_turn in enumerate([5, 6]):
        dest = ref / f'turn-{new_turn:03d}'
        dest.mkdir(exist_ok=True)
        shutil.copy2(SOURCE / 'reference' / f'turn-{old_turn:03d}' / 'response.json', dest / 'response.json')
    db = ref / 'final.db'
    shutil.copy2(case / 'pre_state.db', db)
    env = m.open_env(case, db, ref)
    messages = copy.deepcopy(failed_request['messages'])
    events = []
    for path in sorted(ref.glob('turn-*/response.json')):
        msg = m.normalize(m.load(path)['choices'][0]['message'])
        events.extend(m.execute(env, messages, msg, path.parent))
    assert events[0]['tool'] == 'add_booking_policy_permission'
    assert events[0]['arguments'] == {'booking_policy_id': 3, 'permission_id': 3}
    result = m.verifier(case, db, msg.get('content', ''))
    assert result['result'] == 'complete'
    m.dump(ref / 'trajectory.json', dict(messages=messages, execution=events))
    m.dump(ref / 'evaluation.json', result)
    spec.update(expected_state_sha256=state_hash(db, spec.get('state_projection')),
                fixed_reference_sha256=m.digest(ref / 'trajectory.json'))
    m.dump(case / 'protocol.json', spec)
    assert not m.query(case / 'pre_state.db', spec)
    assert m.query(db, spec)
    aligned = case / 'reference-alignment'
    aligned.mkdir(exist_ok=True)
    shutil.copytree(ref / 'turn-000', aligned / 'turn-000', dirs_exist_ok=True)
    m.dump(aligned / 'receipt.json', dict(verified=True, exact_relational_state=True,
        restored_sha256=spec['pre_state_sha256'], verifier=result,
        alignment=dict(reference_turn='turn-000'),
        reference_suffix_source=str(SOURCE / 'reference/turn-005/response.json'),
        full_teacher_reference_replayed_from_new_anchor=True))
    m.dump(case / 'prepared.json', dict(verified=True, source_failure=str(failed / 'turn-001'),
        historical_failure_actor_temperature=m.load(failed / 'turn-001/request.json')['temperature'],
        all_new_guided_actor_branches_temperature=0.0, all_new_guided_actor_branches_seed=42,
        task_dataset_tools_and_native_verifier_unchanged=True,
        original_goal_already_met_but_actual_student_prefix_cleared_required_permissions=True,
        evaluation_scope='recovery of real student-created missing permission, not a fresh task success rate'))
    return case, None, common_evidence(case)


def main():
    R.mkdir(exist_ok=True)
    lock = (R / 'controller.lock').open('w')
    fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
    g.R = R
    b.R = R
    m.R = R
    b.copy_case = prepare
    b.ACTOR_TEMPERATURE = 0.0
    b.actor = g.fixed_actor
    m.cached_request = g.request
    m.dump(R / 'protocol.json', dict(task='booking_and_reservations_4:4',
        source='one real historical failure reanchored after actual student permission clear',
        actor_temperature=0.0, actor_seed=42, thinking=True, requested_max_tokens=32768,
        guidance_temperature=0.6, guidance_seeds=g.GSEEDS,
        same_context_state_reference_for_every_source=True,
        manual_review_required=True, stop_at_manually_approved_cases=10))
    if '--prepare-only' in sys.argv:
        prepare(NAME)
        print(json.dumps(dict(prepared=True, case=str(R / 'cases' / NAME))))
        return
    g.run(NAME)
    b.emit('reanchored_recovery_complete')


if __name__ == '__main__':
    main()
