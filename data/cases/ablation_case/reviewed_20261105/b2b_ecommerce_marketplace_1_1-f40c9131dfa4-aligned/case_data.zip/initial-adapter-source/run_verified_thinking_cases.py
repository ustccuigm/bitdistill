"""Matched guidance ablations with an explicit native student thinking budget.

Only reviewed historical failure anchors are considered. Read-only local gates
check acquisition of the needed entity, rather than exact reference list order.
All original task data, tools, and terminal native verifiers are retained.
"""
import fcntl
import hashlib
import json
from pathlib import Path
import shutil
import sys
import traceback
from concurrent.futures import ThreadPoolExecutor

import guidance_only_existing_cases as g
import minimum_thinking_actor as thinking
from reanchor_poolcar_permission_recovery import common_evidence

b, m = g.b, g.m
R = Path('/mnt/genming/ablation-verified-thinking-20261105')
OLD = Path('/mnt/genming/ablation-local-thinking-20261104/cases')
PLAN = {
    'poolcar-after-permission-clear': Path('/mnt/genming/ablation-poolcar-reanchored-20261105/cases/poolcar-after-permission-clear'),
    'b2b_ecommerce_marketplace_1_1-f40c9131dfa4-aligned': OLD / 'b2b_ecommerce_marketplace_1_1-f40c9131dfa4-aligned',
    'booking_and_scheduling_8_4-476f4f4dab0f-aligned': OLD / 'booking_and_scheduling_8_4-476f4f4dab0f-aligned',
    'b2b_commerce_1_7-e7946d05fe08-aligned': OLD / 'b2b_commerce_1_7-e7946d05fe08-aligned',
    'booking_and_scheduling_11_3-0c99a14727fe-aligned': OLD / 'booking_and_scheduling_11_3-0c99a14727fe-aligned',
    'b2b_ecommerce_marketplace_1_6-41a3e078faf0-aligned': OLD / 'b2b_ecommerce_marketplace_1_6-41a3e078faf0-aligned',
}
ORIGINAL_QUERY = m.query


def entities(value):
    if isinstance(value, dict):
        yield value
        for child in value.values():
            yield from entities(child)
    elif isinstance(value, list):
        for child in value:
            yield from entities(child)


def semantic_query(db, spec, events=None):
    condition = spec.get('semantic_local_acceptance')
    if not condition:
        return ORIGINAL_QUERY(db, spec, events)
    if events is None:
        return []
    required = condition['required_entity_fields']
    found = any(e.get('status_code') == 200 and any(
        all(entity.get(k) == v for k, v in required.items()) for entity in entities(e.get('response')))
        for e in events)
    return [dict(verified_required_entity=True)] if found else []


def copy_case(name):
    source = PLAN[name]
    case = R / 'cases' / name
    if not (case / 'prepared-thinking-case.json').exists():
        case.mkdir(parents=True, exist_ok=True)
        for filename in ['initial.db', 'pre_state.db', 'context.json', 'tools.json',
                         'task_verifier.py', 'analysis_context.json', 'protocol.json', 'state-projection.json']:
            shutil.copy2(source / filename, case / filename)
        for dirname in ['before', 'reference', 'reference-alignment']:
            shutil.copytree(source / dirname, case / dirname, dirs_exist_ok=True)
        for filename in ['historical-source.json', 'historical-student-trajectory.json', 'prepared.json',
                         'followup-source.json', 'semantic-admission-review.json']:
            if (source / filename).exists():
                shutil.copy2(source / filename, case / ('source-' + filename))
        spec = m.load(case / 'protocol.json')
        assert m.digest(case / 'pre_state.db') == spec['pre_state_sha256']
        assert m.digest(case / 'pre_state.db') == m.digest(source / 'pre_state.db')
        scenario, task = spec['task'].split(':')
        verifier_data = Path('/mnt/genming/Arctic-AWM-BitDistiller-full/arctic_quant/common/data/awm_source/gen_verifier.pure_code.jsonl')
        original = next(row['verification']['code'] for row in
                        (json.loads(line) for line in verifier_data.read_text().splitlines())
                        if row['scenario'] == scenario and str(row['task_idx']) == task)
        assert (case / 'task_verifier.py').read_text() == original
        # These checks are declared before generating any new guidance or actor response.
        if spec['task'] == 'b2b_ecommerce_marketplace_1:1':
            spec['semantic_local_acceptance'] = dict(
                required_entity_fields={'id': 2, 'supplier_id': 3, 'sku': 'LINEN-NAPKIN-SET4'},
                meaning='Resolve the requested product under its actual supplier; valid broader queries are allowed.')
        elif spec['task'] == 'booking_and_scheduling_8:4':
            spec['semantic_local_acceptance'] = dict(
                required_entity_fields={'id': 1, 'name': 'Podcast Mixer Bundle'},
                meaning='Retrieve the actual mixer bundle; valid filtered and unfiltered lookups are allowed.')
        m.dump(case / 'protocol.json', spec)
        result = m.verifier(case, case / 'pre_state.db', '')
        if result.get('result') == 'complete':
            raise ValueError('Goal already satisfied at intervention; excluded from this new recovery set')
        receipt = m.load(case / 'reference-alignment/receipt.json')
        turn = receipt['alignment']['reference_turn']
        if spec['mode'] == 'observed_transition':
            expected = m.load(case / 'reference-alignment' / turn / 'execution.json')
            if spec.get('semantic_local_acceptance'):
                assert semantic_query(case / 'pre_state.db', spec, expected), 'Reference does not retrieve required entity'
            elif all(not any(bool(v) for v in e.get('response', {}).values()) for e in expected):
                raise ValueError('Empty reference observation is not accepted as a successful lookup')
        m.dump(case / 'prepared-thinking-case.json', dict(source=str(source),
            original_task_verifier_matches=True, task_and_tool_text_unchanged=True,
            pre_intervention_native_goal=result, semantic_gate_declared_before_new_generations=True,
            student_thinking_minimum=thinking.MIN_THINKING_TOKENS,
            all_student_actor_branches_use_the_same_decoder=True))
    b.revalidate_reference(case)
    return case, None, common_evidence(case)


def check_actor_thinking(case):
    checked = []
    for path in case.glob('new-trials/*/guide-*/seed-*/turn-*/thinking-verification.json'):
        receipt = m.load(path)
        assert receipt['verified'] and receipt['actual_thinking_phase_generated_tokens'] >= thinking.MIN_THINKING_TOKENS
        assert receipt['actual_total_generated_tokens'] <= thinking.TOTAL_COMPLETION_BUDGET
        request = m.load(path.parent / 'request.json')
        actual_prefill = request['messages'][-1]
        assert actual_prefill['role'] == 'assistant'
        assert hashlib.sha256(actual_prefill['reasoning'].encode()).hexdigest() == receipt['reasoning_sha256']
        checked.append(dict(path=str(path), tokens=receipt['actual_thinking_phase_generated_tokens']))
    m.dump(case / 'actor-thinking-audit.json', dict(verified=bool(checked), turns=checked,
        total_verified_turns=len(checked), minimum_thinking_tokens=thinking.MIN_THINKING_TOKENS,
        native_reasoning_prefill_generated_by_same_student=True,
        not_a_native_single_pass_reasoning_usage_claim=True))


def run(name):
    g.run(name)
    case = R / 'cases' / name
    try:
        check_actor_thinking(case)
        comparison = case / 'comparison.json'
        if comparison.exists():
            result = m.load(comparison)
            result['student_thinking_protocol'] = dict(minimum_tokens=thinking.MIN_THINKING_TOKENS,
                total_completion_budget=thinking.TOTAL_COMPLETION_BUDGET,
                two_native_generations_same_checkpoint=True,
                terminal_task_verifier_unchanged=True)
            m.dump(comparison, result)
    except Exception as exc:
        m.dump(case / 'thinking-audit-error.json', dict(error=str(exc), traceback=traceback.format_exc()))


def main():
    R.mkdir(exist_ok=True)
    lock = (R / 'controller.lock').open('w')
    fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
    g.R = R
    b.R = R
    m.R = R
    b.copy_case = copy_case
    b.ACTOR_TEMPERATURE = 0.0
    b.actor = thinking.actor
    g.rendered_identity = thinking.rendered_identity
    m.cached_request = g.request
    m.query = semantic_query
    m.dump(R / 'protocol.json', dict(source='six reviewed existing real failure anchors',
        requested_max_tokens=thinking.TOTAL_COMPLETION_BUDGET,
        student_minimum_thinking_tokens=thinking.MIN_THINKING_TOKENS,
        actor_temperature=0.0, actor_seed=42, thinking=True,
        guidance_temperature=0.6, guidance_seeds=g.GSEEDS,
        logical_task_messages_tools_and_native_verifier_unchanged=True,
        thinking_protocol='Native model-generated thought then continuation of that exact assistant prefill',
        positive_student_thinking_verified_from_native_generation_not_flags=True,
        task_specific_readonly_gate_allows_valid_query_alternatives=True,
        prior_results_not_overwritten=True, manual_quality_review_required=True,
        stop_at_manually_approved_cases=10))
    eligible = []
    for name in PLAN:
        try:
            copy_case(name)
            eligible.append(name)
        except Exception as exc:
            m.dump(R / 'reference-exclusions' / (name + '.json'), dict(
                error=str(exc), traceback=traceback.format_exc(), excluded_not_a_model_failure=True))
    m.dump(R / 'validated-queue.json', dict(cases=eligible))
    if '--prepare-only' in sys.argv:
        print(json.dumps(dict(eligible=eligible), ensure_ascii=False))
        return
    if '--smoke' in sys.argv:
        case, _, evidence = copy_case('poolcar-after-permission-clear')
        guide = PLAN['poolcar-after-permission-clear'] / 'sampled-guidance/teacher_structured/guide-42/guidance.json'
        assert b.evidence(guide.parent) == evidence
        record = b.rollout(case, 'adapter_validation/guide-42', guide, 42)
        assert record and record['local_accepted'] and record['whole_task_passed'] and record['unsteered_requests'] > 0
        check_actor_thinking(case)
        m.dump(R / 'adapter-episode-verification.json', dict(verified=True, record=record,
               validation_only_not_a_new_ablation_case=True))
        print(json.dumps(dict(adapter_episode_verified=True, record=record), ensure_ascii=False))
        return
    with ThreadPoolExecutor(max_workers=2) as pool:
        futures = [pool.submit(run, name) for name in eligible if not b.target_reached()]
        for future in futures:
            future.result()
    b.emit('verified_thinking_cases_complete')


if __name__ == '__main__':
    main()
