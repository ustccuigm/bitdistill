"""Mine same-state, one-response guidance ablations, preserving every attempt.

Uses completed local-repair artifacts from the independent training case job.
Never mutates that job, its servers, or its source data.
"""
import copy
import fcntl
import importlib.util
import json
import os
import shutil
import sqlite3
import sys
import time
import traceback
import threading
import hashlib
from concurrent.futures import ThreadPoolExecutor, wait, FIRST_COMPLETED
from pathlib import Path

sys.path.insert(0, '/mnt/genming/case-rerun-20261103')
from rerun_v3 import Environment, digest, dump, extract_first_guidance, load, normalize, request
from ablation_generation_transport import request

R = Path('/mnt/genming/ablation-local-thinking-20261104')
SEED = Path('/mnt/genming/training-local-cases-20261104')
TEACHER = 'http://127.0.0.1:38181/v1'
STUDENT = 'http://127.0.0.1:38182/v1'
VARIANTS = ['teacher_freeform', 'student_structured', 'external_structured']
OLD_TASKS = {'b2b_commerce_1:1', 'booking_and_reservations_5:0', 'booking_and_scheduling_11:4'}
TARGET = 10
CASE_WORKERS = 2
MAX_GENERATION_TOKENS = 32768
os.environ['CASE_LLM_READ_TIMEOUT'] = '7200'
STATUS_LOCK = threading.Lock()


def input_identity(case, original_protocol=False):
    protocol = case / 'protocol.json'
    if original_protocol and (case / 'protocol-before-scope.json').exists():
        protocol = case / 'protocol-before-scope.json'
    files = [protocol, case / 'context.json', case / 'tools.json', case / 'before/response.json']
    return hashlib.sha256(json.dumps([digest(p) for p in files]).encode()).hexdigest()


def cached_request(payload, dest, endpoint, headers=None):
    # Preserve completed comparisons, and archive truncated/incomplete requests
    # before increasing their budget. Never overwrite a sampled response.
    saved = dest / 'request.json'
    policy_path = dest / 'request-policy.json'
    if policy_path.exists() and (dest / 'response.json').exists():
        normalize_payload = lambda x: {k: v for k, v in x.items() if k != 'max_tokens'}
        if normalize_payload(load(policy_path)['base_payload']) != normalize_payload(payload):
            raise ValueError('Cached recovery sample belongs to a different underlying request')
        return load(dest / 'response.json')
    if saved.exists():
        old = load(saved)
        comparable = lambda x: {k: v for k, v in x.items() if k not in ['max_tokens', 'stream', 'stream_options']}
        if policy_path.exists():
            old = load(policy_path)['base_payload']
        if comparable(old) != comparable(payload):
            raise ValueError('Saved model request changed beyond its token budget')
        response = dest / 'response.json'
        if response.exists() and load(response)['choices'][0]['finish_reason'] != 'length':
            return load(response)
        if old.get('max_tokens', 0) < payload['max_tokens']:
            archive = dest.with_name(dest.name + '-preserved-budget-' + str(old.get('max_tokens')))
            if archive.exists():
                archive = archive.with_name(archive.name + '-' + str(time.time_ns()))
            dest.rename(archive)
            dump(archive / 'budget-change.json', dict(new_max_tokens=payload['max_tokens'],
                reason='Extend thinking budget; previous raw request and response preserved',
                replacement_directory=str(dest)))
        else:
            payload = old
    if endpoint in [TEACHER, STUDENT] and not (dest / 'response.json').exists():
        import httpx
        token_payload = {k: payload[k] for k in ['model', 'messages', 'tools',
            'chat_template_kwargs', 'add_generation_prompt'] if k in payload}
        result = httpx.post(endpoint.removesuffix('/v1') + '/tokenize',
            json=token_payload, timeout=60, trust_env=False)
        result.raise_for_status()
        counts = result.json()
        available = counts['max_model_len'] - counts['count'] - 64
        if available < 1024:
            raise ValueError('insufficient_context_capacity_excluded')
        payload['max_tokens'] = min(payload['max_tokens'], available)
        dump(dest / 'budget.json', dict(requested=MAX_GENERATION_TOKENS,
            effective=payload['max_tokens'], prompt_tokens=counts['count'],
            model_context=counts['max_model_len'], thinking=True))
    if (dest / 'response.json').exists():
        if load(dest / 'request.json') != payload:
            raise ValueError('Saved model request changed; preserve it and use a new protocol directory')
        return load(dest / 'response.json')
    return request(payload, dest, endpoint, headers)


def status(phase, **extra):
    with STATUS_LOCK:
        value = dict(phase=phase, pid=os.getpid(), time=time.time(), **extra)
        dump(R / 'status.json', value)
        if extra.get('task'):
            dump(R / 'task-status' / (extra['task'].replace(':', '_') + '.json'), value)
        print(phase, extra, flush=True)


def query(db, spec, events=None):
    if spec.get('mode') == 'observed_transition':
        from relational_ablation_candidates import state_hash, observation_hash
        if events is None:
            return []
        matched = (state_hash(db, spec.get('state_projection')) == spec['expected_state_sha256'] and
            observation_hash(events, spec) == spec['expected_observation_sha256'])
        return [{'verified_reference_observation': True}] if matched else []
    if spec.get('mode') == 'relational_transition':
        from relational_ablation_candidates import state_hash
        return [{'exact_reference_state': True}] if state_hash(db, spec.get('state_projection')) == spec['expected_state_sha256'] else []
    with sqlite3.connect('file:' + str(db) + '?mode=ro', uri=True) as c:
        c.row_factory = sqlite3.Row
        return [dict(row) for row in c.execute('SELECT * FROM "' + spec['table'] + '" WHERE ' + spec['predicate'])]


def open_env(case, db, work):
    spec = load(case / 'protocol.json')
    if spec.get('mode') in ['relational_transition', 'observed_transition']:
        from relational_ablation_candidates import open_environment
        return open_environment(case, db, work)
    work.mkdir(parents=True, exist_ok=True)
    return Environment(spec['task'].split(':')[0], db, work)


def reply(messages, tools, endpoint, dest, guidance=None):
    submitted = copy.deepcopy(messages)
    if guidance:
        submitted[0]['content'] += '\n\nLocal steering for this response only:\n' + guidance
    payload = dict(model='case-model', messages=submitted, tools=tools, temperature=0.0, seed=42,
        max_tokens=MAX_GENERATION_TOKENS, stop_token_ids=[49, 106], add_generation_prompt=True, min_tokens=16,
        chat_template_kwargs={'enable_thinking': True})
    result = cached_request(payload, dest, endpoint)
    choice = result['choices'][0]
    if choice['finish_reason'] == 'length':
        raise ValueError('truncated_student_response_not_counted_as_a_semantic_error')
    return normalize(choice['message'])


def execute(env, messages, msg, dest):
    messages.append(msg)
    events = []
    for call in msg.get('tool_calls', []):
        f = call['function']
        e = env.execute(f['name'], f['arguments'])
        if not e.get('executed') or e.get('status_code', 0) >= 500:
            raise ValueError('environment_or_adapter_error_excluded')
        events.append(e)
        messages.append(dict(role='tool', tool_call_id=call['id'], content=json.dumps(e['response'], ensure_ascii=False)))
    dump(dest / 'execution.json', events)
    return events


def verifier(case, db, answer=''):
    ns = {}
    exec((case / 'task_verifier.py').read_text(), ns)
    return ns['verify_task_completion'](str(case / 'initial.db'), str(db), answer)


def reference_gate(case):
    """Re-execute the fixed, freshly generated teacher reference at the saved anchor.

    Store the first transition establishing the predeclared task predicate. This
    establishes a bounded reference effect instead of comparing only final success.
    """
    out = case / 'reference-alignment'
    if (out / 'receipt.json').exists():
        return load(out / 'receipt.json')
    out.mkdir(exist_ok=True)
    spec = load(case / 'protocol.json')
    db = out / 'replayed.db'
    shutil.copy2(case / 'pre_state.db', db)
    assert digest(db) == spec['pre_state_sha256']
    env = open_env(case, db, out)
    base = query(db, spec)
    expected_turn = None
    for f in sorted((case / 'reference').glob('turn-*/response.json')):
        before = query(db, spec)
        msg = normalize(load(f)['choices'][0]['message'])
        messages = []
        execute(env, messages, msg, out / f.parent.name)
        after = query(db, spec)
        if expected_turn is None and len(after) > len(base):
            expected_turn = dict(reference_turn=f.parent.name, before=before, after=after,
                response_path=str(f), before_predicate_count=len(before), after_predicate_count=len(after))
            shutil.copy2(db, out / 'accepted-transition.db')
    check = verifier(case, db)
    if check.get('result') != 'complete' or expected_turn is None:
        raise ValueError('reference_replay_or_local_transition_not_verified')
    receipt = dict(verified=True, restored_sha256=spec['pre_state_sha256'], verifier=check,
        fixed_reference_sha256=digest(case / 'reference/trajectory.json'), task_predicate=spec['predicate'],
        table=spec['table'], alignment=expected_turn,
        semantics='Task-specific local predicate declared before candidate generation; not full database equivalence.')
    dump(out / 'receipt.json', receipt)
    return receipt


def audit_ours(case):
    spec = load(case / 'protocol.json')
    if spec.get('mode') in ['relational_transition', 'observed_transition']:
        ref = reference_gate(case)
        assert ref['verified'] and ref['exact_relational_state']
        assert digest(case / 'reference/trajectory.json') == spec['fixed_reference_sha256']
        assert digest(case / 'pre_state.db') == spec['pre_state_sha256']
        assert not query(case / 'before/final.db', spec, load(case / 'before/execution.json'))
        return spec, load(case / 'outcome.json'), None
    outcome = load(case / 'outcome.json')
    assert outcome['accepted']
    after = case / 'after' / ('attempt-' + str(outcome['attempt']))
    guidance = (case / 'steering' / ('attempt-' + str(outcome['attempt'])) / 'raw_steering_prompt.txt').read_text()
    gate = load(after / 'local_gate.json')
    assert gate['accepted'] and gate['checked_before_continuation']
    assert len(query(case / 'pre_state.db', spec)) < len(query(after / 'local_state.db', spec))
    assert verifier(case, after / 'final.db').get('result') == 'complete'
    requests = sorted(after.glob('turn-*/request.json'))
    assert len(requests) >= 2
    original_system = load(case / 'context.json')[0]
    for i, f in enumerate(requests):
        messages = load(f)['messages']
        if i == 0:
            assert guidance in messages[0]['content']
        else:
            assert messages[0] == original_system
            assert not any(guidance in str(m.get('content', '')) for m in messages)
    ref = reference_gate(case)
    receipt = dict(verified=True, guidance_only_in_first_request=True,
        unguided_continuation_requests=len(requests) - 1, local_gate=str(after / 'local_gate.json'),
        reference_alignment=str(case / 'reference-alignment/receipt.json'), pre_state_sha256=spec['pre_state_sha256'],
        guided_request_sha256=digest(requests[0]), final_verifier=load(after / 'result.json'))
    dump(case / 'ours-audit.json', receipt)
    return spec, outcome, after


def scope_reference(case):
    """Bind a local condition to the actual parent records in the fixed reference."""
    spec = load(case / 'protocol.json')
    if spec.get('mode') in ['relational_transition', 'observed_transition']:
        return reference_gate(case)
    if 'reference_parent_scope' in spec:
        return reference_gate(case)
    ref = reference_gate(case)
    with sqlite3.connect('file:' + str(case / 'pre_state.db') + '?mode=ro', uri=True) as c:
        primary = [r[1] for r in c.execute('PRAGMA table_info("' + spec['table'] + '")') if r[5]]
        foreign = [r[3] for r in c.execute('PRAGMA foreign_key_list("' + spec['table'] + '")')]
    if not primary:
        raise ValueError('local_scope_requires_record_identity')
    prior = {tuple(r[k] for k in primary) for r in ref['alignment']['before']}
    added = [r for r in ref['alignment']['after'] if tuple(r[k] for k in primary) not in prior]
    if len(added) != 1:
        raise ValueError('ambiguous_reference_local_effect_excluded')
    parent = {k: added[0][k] for k in foreign if added[0][k] is not None}
    spec['original_predicate'] = spec['predicate']
    spec['predicate'] = '(' + spec['predicate'] + ')'
    for k, value in parent.items():
        literal = "'" + value.replace("'", "''") + "'" if isinstance(value, str) else str(value)
        spec['predicate'] += ' AND "' + k + '"=' + literal
    spec['reference_parent_scope'] = parent
    dump(case / 'protocol-before-scope.json', load(case / 'protocol.json'))
    dump(case / 'protocol.json', spec)
    # Rebuild the receipt using the scoped condition before any new generation.
    shutil.move(case / 'reference-alignment', case / 'reference-alignment-unscoped')
    reference_gate(case)


def advisor(case, variant, dest, feedback):
    reference = load(case / 'reference-alignment/receipt.json')
    turn = reference['alignment']['reference_turn']
    prompt = ('Analyze the failed next decision at this restored state. Compare it with the aligned, '
        'executed transition of the fixed successful teacher reference. Give one local procedural correction '
        'for the next student response. Preserve valid context. Explain the specific discrepancy, the relevant '
        'state precondition, corrective rule and expected effect. Do not claim that unexecuted actions have '
        'already happened. Do not replace the student response or provide a plan for the whole remaining task. ')
    prompt += ('Return concise free-form procedural guidance.' if variant == 'teacher_freeform' else
        'Return one JSON object with precondition, decision_rule, expected_transition, recovery_check.')
    context = dict(task=load(case / 'analysis_context.json')['task'],
        current_context=load(case / 'context.json'),
        failed_decision=load(case / 'before/response.json')['choices'][0]['message'],
        failed_execution=load(case / 'before/execution.json'), tools=load(case / 'tools.json'),
        aligned_reference_decision=load(case / 'reference' / turn / 'response.json')['choices'][0]['message'],
        aligned_reference_execution=load(case / 'reference-alignment' / turn / 'execution.json'),
        reference_verified=reference['verifier'], retry_feedback=feedback)
    payload = dict(model='case-model', messages=[dict(role='system', content=prompt),
        dict(role='user', content=json.dumps(context, ensure_ascii=False))], temperature=0.0,
        max_tokens=MAX_GENERATION_TOKENS, seed=42, add_generation_prompt=True,
        chat_template_kwargs={'enable_thinking': True})
    if variant != 'teacher_freeform':
        fields = ['precondition', 'decision_rule', 'expected_transition', 'recovery_check']
        payload['response_format'] = dict(type='json_schema', json_schema=dict(name='local_guidance', strict=True,
            schema=dict(type='object', properties={k: {'type': 'string'} for k in fields},
                        required=fields, additionalProperties=False)))
    endpoint = STUDENT if variant == 'student_structured' else TEACHER
    headers = None
    if variant == 'external_structured':
        import tomllib
        config = tomllib.loads(Path('/mnt/genming/.codex/config.toml').read_text())
        auth = load('/mnt/genming/.codex/auth.json')
        endpoint = config['openai_base_url'].rstrip('/')
        headers = {'Authorization': 'Bearer ' + auth['OPENAI_API_KEY']}
        payload['model'] = 'gpt-5.6-sol'
        payload['reasoning_effort'] = config.get('model_reasoning_effort', 'high')
        for key in ['seed', 'chat_template_kwargs', 'stop_token_ids']:
            payload.pop(key, None)
        payload.pop('add_generation_prompt', None)
    raw = cached_request(payload, dest, endpoint, headers)
    choice = raw['choices'][0]
    if choice['finish_reason'] == 'length':
        raise ValueError('truncated_guidance_excluded_not_a_baseline_failure')
    text = choice['message'].get('content') or ''
    if variant == 'teacher_freeform':
        if choice['finish_reason'] == 'length' or not text.strip():
            raise ValueError('invalid_guidance_excluded')
    else:
        text, extraction = extract_first_guidance(text)
        dump(dest / 'extraction.json', extraction)
    dump(dest / 'guidance.json', dict(text=text, variant=variant))
    return text


def branch(case, variant):
    dest = case / 'ablations' / variant
    if (dest / 'outcome.json').exists():
        return load(dest / 'outcome.json')
    spec = load(case / 'protocol.json')
    base = query(case / 'pre_state.db', spec)
    feedback = []
    attempts = []
    for i in range(4):
        retirement = case / 'quality-review.json'
        if retirement.exists() and load(retirement).get('retired_protocol'):
            raise ValueError('case_acceptance_protocol_retired_before_further_sampling')
        work = dest / ('attempt-' + str(i))
        work.mkdir(parents=True, exist_ok=True)
        status('baseline', task=spec['task'], variant=variant, attempt=i)
        guidance = advisor(case, variant, work / 'advisor', feedback)
        db = work / 'final.db'
        shutil.copy2(case / 'pre_state.db', db)
        assert digest(db) == spec['pre_state_sha256']
        env = open_env(case, db, work)
        messages = copy.deepcopy(load(case / 'context.json'))
        tools = load(case / 'tools.json')
        msg = reply(messages, tools, STUDENT, work / 'turn-000', guidance)
        events = execute(env, messages, msg, work / 'turn-000')
        actual = query(db, spec, events)
        passed = len(actual) > len(base)
        gate = dict(accepted=passed, checked_before_continuation=True, pre=base, after=actual,
            table=spec.get('table'), predicate=spec.get('predicate'), mode=spec.get('mode'), events=events,
            reference_alignment=str(case / 'reference-alignment/receipt.json'))
        dump(work / 'local_gate.json', gate)
        shutil.copy2(db, work / 'local_state.db')
        attempts.append(gate)
        if passed:
            # Accepted responses continue without the advisor text, exactly as ours.
            for t in range(1, 32):
                clean = copy.deepcopy(messages)
                msg = reply(clean, tools, STUDENT, work / f'turn-{t:03d}')
                assert guidance not in json.dumps(clean, ensure_ascii=False)
                execute(env, messages, msg, work / f'turn-{t:03d}')
                if not msg.get('tool_calls'):
                    break
            final = verifier(case, db, msg.get('content', ''))
            dump(work / 'trajectory.json', dict(messages=messages))
            dump(work / 'result.json', final)
            result = dict(variant=variant, local_status='pass', final_verification=final,
                accepted_attempt=i, attempts=len(attempts), valid=True)
            dump(dest / 'outcome.json', result)
            return result
        feedback.append(dict(attempt=i, guidance=guidance, local_feedback=gate))
    result = dict(variant=variant, local_status='fail', final_verification=None,
        attempts=4, valid=True, reason='four actual student responses failed the predeclared local task condition')
    dump(dest / 'outcome.json', result)
    return result


def screen():
    selected = []
    provisional = []
    seen = set()
    for p in sorted((R / 'cases').glob('*/ablation-outcome.json')):
        r = load(p)
        if r.get('qualified'):
            review = p.parent / 'quality-review.json'
            if review.exists() and load(review).get('approved'):
                if r['task'] not in seen:
                    selected.append(r)
                    seen.add(r['task'])
            else:
                provisional.append(r)
    report = dict(target=TARGET, qualified=len(selected), selected=selected,
        pending_quality_review=provisional,
        criteria='ours verified local correction plus unguided successful continuation; at least two of three valid advisor controls fail local acceptance or native task verification; concrete error causes require manual review; failed local candidates do not continue',
        updated_at=time.time())
    dump(R / 'progress.json', report)
    return report


def run_case(source):
    meta = load(source / 'outcome.json')
    key = meta['task']
    case = R / 'cases' / source.name
    status('source_assigned', task=key, source=str(source), output_case=str(case))
    if not case.exists():
        shutil.copytree(source, case, ignore=shutil.ignore_patterns('__pycache__', '*.lock'))
    identity_file = case / 'ablation-input-identity.json'
    if not identity_file.exists():
        dump(identity_file, dict(identity=input_identity(source), source=str(source)))
    if (case / 'ablation-outcome.json').exists():
        return
    review = case / 'quality-review.json'
    if review.exists() and load(review).get('retired_protocol'):
        return
    try:
        status('auditing_local_candidate', task=key)
        scope_reference(case)
        audit_ours(case)
        ours = branch(case, 'teacher_structured')
        if ours.get('local_status') != 'pass' or ours.get('final_verification', {}).get('result') != 'complete':
            dump(case / 'ablation-outcome.json', dict(task=key, qualified=False, ours=ours,
                reason='fresh teacher steering did not yield local correction and successful unguided continuation'))
            status('case_rejected', task=key, reason='ours_not_successful')
            return
        outcomes = {}
        # For new tasks test the fast independent controls first. If both pass,
        # at most one of three can fail, so further generation cannot qualify it.
        order = ['teacher_freeform', 'external_structured', 'student_structured']
        for variant in order:
            outcomes[variant] = branch(case, variant)
            passes = sum(v['valid'] and v['local_status'] == 'pass' and
                v.get('final_verification', {}).get('result') == 'complete' for v in outcomes.values())
            if passes >= 2:
                result = dict(task=key, qualified=False, ours=ours, outcomes=outcomes,
                    reason='Two controls succeeded; cannot meet at-least-two-fail criterion',
                    skipped_controls=[v for v in VARIANTS if v not in outcomes])
                dump(case / 'ablation-outcome.json', result)
                status('case_rejected', task=key, reason=result['reason'])
                return
        failures = sum(v['valid'] and (v['local_status'] == 'fail' or
            (v.get('final_verification') is not None and v['final_verification'].get('result') != 'complete'))
            for v in outcomes.values())
        result = dict(task=key, directory=str(case), qualified=failures >= 2,
            valid_failed_baselines=failures, ours=ours, outcomes=outcomes,
            scope='local steering ablation; not aggregate performance or post-training inference')
        dump(case / 'ablation-outcome.json', result)
        status('case_completed', **result)
    except Exception as exc:
        dump(case / 'ablation-error.json', dict(error=str(exc), traceback=traceback.format_exc()))
        status('case_excluded', task=key, error=str(exc))


def main():
    R.mkdir(parents=True, exist_ok=True)
    lock = (R / 'controller.lock').open('w')
    fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
    processed = set()
    processed_inputs = set()
    for p in (R / 'cases').glob('*/ablation-outcome.json'):
        identity = p.parent / 'ablation-input-identity.json'
        try:
            processed_inputs.add(load(identity)['identity'] if identity.exists() else input_identity(p.parent, original_protocol=True))
        except (OSError, KeyError):
            pass
    pool = ThreadPoolExecutor(max_workers=CASE_WORKERS)
    active = {}
    while True:
        for future in [f for f in active if f.done()]:
            source = active.pop(future)
            future.result()
        report = screen()
        if report['qualified'] >= TARGET:
            status('target_reached', qualified=report['qualified'])
            pool.shutdown(wait=True)
            return
        ready = []
        ready_inputs = set()
        sources = list((SEED / 'cases').glob('*/outcome.json'))
        sources += list(Path('/mnt/genming/ablation-local-seeds-20261104').glob('*/cases/*/outcome.json'))
        sources += list(Path('/mnt/genming/ablation-relational-seeds-20261104/cases').glob('*/outcome.json'))
        sources += list(Path('/mnt/genming/ablation-replay-seeds-20261104/cases').glob('*/outcome.json'))
        for p in sources:
            r = load(p)
            if (r.get('accepted') or r.get('candidate_ready')) and r['task'] not in OLD_TASKS and str(p.parent) not in processed:
                identifier = input_identity(p.parent)
                if identifier in processed_inputs:
                    processed.add(str(p.parent))
                    continue
                if identifier in ready_inputs:
                    continue
                ready.append(p.parent)
                ready_inputs.add(identifier)
        if not ready and not active:
            status('waiting_for_verified_local_candidates', qualified=report['qualified'], processed=len(processed))
            time.sleep(30)
            continue
        active_tasks = {load(source / 'outcome.json')['task'] for source in active.values()}
        ready.sort(key=lambda s: not load(s / 'outcome.json').get('fresh_current_policy_failure', False))
        dump(R / 'queue-status.json', dict(time=time.time(), processed_count=len(processed),
            ready=[dict(task=load(s / 'outcome.json')['task'], source=str(s),
                fresh=load(s / 'outcome.json').get('fresh_current_policy_failure', False)) for s in ready],
            active_tasks=sorted(active_tasks)))
        for source in ready:
            if len(active) >= CASE_WORKERS:
                break
            key = load(source / 'outcome.json')['task']
            if key in active_tasks:
                continue
            processed.add(str(source))
            processed_inputs.add(input_identity(source))
            active[pool.submit(run_case, source)] = source
            active_tasks.add(key)
        dump(R / 'active-tasks.json', dict(time=time.time(), workers=CASE_WORKERS,
            tasks=[dict(task=load(s / 'outcome.json')['task'], source=str(s)) for s in active.values()]))
        if active:
            wait(list(active), timeout=5, return_when=FIRST_COMPLETED)


if __name__ == '__main__':
    main()
