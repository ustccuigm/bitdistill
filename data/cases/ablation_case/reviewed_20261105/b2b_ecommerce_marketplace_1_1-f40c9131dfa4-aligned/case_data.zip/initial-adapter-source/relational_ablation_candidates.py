"""Build counterfactual cases with exact logical state checks and a pinned clock.

All changes are runtime copies. The original datasets and shared method remain
untouched. A task is selected before the advisor outcomes are generated.
"""
import copy
import datetime as datetime_module
import fcntl
import hashlib
import json
import os
import shutil
import sqlite3
import sys
import time
import types
import uuid as uuid_module
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor

sys.path.insert(0, '/mnt/genming/case-rerun-20261103')
from rerun_v3 import Environment, digest, dump, load, normalize, request

R = Path('/mnt/genming/ablation-relational-seeds-20261104')
TEACHER = 'http://127.0.0.1:38181/v1'
EXCLUDE = {'b2b_commerce_1:1', 'booking_and_reservations_5:0', 'booking_and_scheduling_11:4'}


def logical_state(db, projection=None):
    state = {}
    with sqlite3.connect('file:' + str(db) + '?mode=ro', uri=True) as c:
        for (table,) in c.execute("SELECT name FROM sqlite_master WHERE type='table' ORDER BY name"):
            quoted = '"' + table.replace('"', '""') + '"'
            columns = [r[1] for r in c.execute('PRAGMA table_info(' + quoted + ')')]
            keep = set(projection[table]) if projection is not None else set(columns)
            positions = [i for i, col in enumerate(columns) if col in keep]
            columns = [col for col in columns if col in keep]
            rows = [[r[i] for i in positions] for r in c.execute('SELECT * FROM ' + quoted)]
            for row in rows:
                for i, value in enumerate(row):
                    if isinstance(value, bytes):
                        row[i] = {'bytes_hex': value.hex()}
            state[table] = dict(columns=columns, rows=sorted(rows, key=lambda row: json.dumps(row, sort_keys=True)))
    return state


def state_hash(db, projection=None):
    return hashlib.sha256(json.dumps(logical_state(db, projection), sort_keys=True).encode()).hexdigest()


def observation_hash(events, spec):
    allowed = set(spec.get('observation_allowed_fields', []))
    known = set(spec.get('observation_known_columns', []))

    def clean(value):
        if isinstance(value, dict):
            return {k: clean(v) for k, v in value.items() if k not in known or k in allowed}
        if isinstance(value, list):
            return [clean(v) for v in value]
        return value

    observations = [dict(status_code=e.get('status_code'), response=clean(e.get('response'))) for e in events]
    return hashlib.sha256(json.dumps(observations, sort_keys=True).encode()).hexdigest()


def freeze_environment(env, spec):
    """Same clock/UUID stream for every branch; no schema or business rule edits."""
    from sqlalchemy import event
    fixed = datetime_module.datetime.fromisoformat(spec['frozen_clock_utc'])

    class FrozenDatetime(datetime_module.datetime):
        @classmethod
        def utcnow(cls):
            return fixed

        @classmethod
        def now(cls, tz=None):
            return fixed if tz is None else fixed.replace(tzinfo=datetime_module.timezone.utc).astimezone(tz)

        @classmethod
        def today(cls):
            return fixed

    class FrozenDate(datetime_module.date):
        @classmethod
        def today(cls):
            return fixed.date()

    counter = spec.get('uuid_counter_offset', 0)

    def uuid4():
        nonlocal counter
        counter += 1
        raw = hashlib.sha256((spec.get('uuid_seed_sha256', spec['pre_state_sha256']) + ':' + str(counter)).encode()).digest()[:16]
        return uuid_module.UUID(bytes=raw, version=4)

    dt_proxy = types.ModuleType('case_fixed_datetime')
    dt_proxy.__dict__.update(vars(datetime_module))
    dt_proxy.datetime, dt_proxy.date = FrozenDatetime, FrozenDate
    uuid_proxy = types.ModuleType('case_fixed_uuid')
    uuid_proxy.__dict__.update(vars(uuid_module))
    uuid_proxy.uuid4 = uuid4
    for key, value in list(vars(env.mod).items()):
        if value is datetime_module.datetime:
            setattr(env.mod, key, FrozenDatetime)
        elif value is datetime_module.date:
            setattr(env.mod, key, FrozenDate)
        elif value is datetime_module:
            setattr(env.mod, key, dt_proxy)
        elif value is uuid_module:
            setattr(env.mod, key, uuid_proxy)
        elif value is uuid_module.uuid4:
            setattr(env.mod, key, uuid4)
    metadata = getattr(getattr(env.mod, 'Base', None), 'metadata', None)
    if metadata is not None:
        for table in metadata.tables.values():
            for column in table.columns:
                for attr in ['default', 'onupdate']:
                    default = getattr(column, attr, None)
                    fn = getattr(default, 'arg', None)
                    unwrapped = getattr(fn, '__wrapped__', fn)
                    if (getattr(unwrapped, '__name__', None) in ['utcnow', 'now'] and
                            getattr(unwrapped, '__self__', None) is datetime_module.datetime):
                        default.arg = lambda context: fixed
                    elif unwrapped is uuid_module.uuid4:
                        default.arg = lambda context: uuid4()
    engine = env.mod.engine

    def connect(dbapi, record):
        dbapi.create_function('current_timestamp', 0, lambda: fixed.strftime('%Y-%m-%d %H:%M:%S'))
        dbapi.create_function('current_date', 0, lambda: fixed.strftime('%Y-%m-%d'))
        dbapi.create_function('current_time', 0, lambda: fixed.strftime('%H:%M:%S'))

    event.listen(engine, 'connect', connect)
    engine.dispose()
    env.uuid_counter = lambda: counter
    return env


def open_environment(case, db, work):
    spec = load(case / 'protocol.json')
    work.mkdir(parents=True, exist_ok=True)
    env = Environment(spec['task'].split(':')[0], db, work)
    return freeze_environment(env, spec)


def execute(env, messages, msg, dest):
    messages.append(normalize(msg))
    events = []
    for call in msg.get('tool_calls') or []:
        f = call['function']
        event = env.execute(f['name'], f['arguments'])
        if not event.get('executed') or event.get('status_code', 0) >= 500:
            raise RuntimeError('environment_error_excluded')
        events.append(event)
        messages.append(dict(role='tool', tool_call_id=call['id'], content=json.dumps(event['response'], ensure_ascii=False)))
    dump(dest / 'execution.json', events)
    return events


def verify(case, db, answer=''):
    ns = {}
    exec((case / 'task_verifier.py').read_text(), ns)
    return ns['verify_task_completion'](str(case / 'initial.db'), str(db), answer)


def generate_reference(case, attempt):
    out = case / f'reference-search-{attempt}'
    out.mkdir(exist_ok=True)
    db = out / 'final.db'
    shutil.copy2(case / 'pre_state.db', db)
    env = open_environment(case, db, out)
    messages = copy.deepcopy(load(case / 'context.json'))
    tools = load(case / 'tools.json')
    first_write = None
    answer = ''
    all_events = []
    for turn in range(32):
        where = out / f'turn-{turn:03d}'
        payload = dict(model='case-model', messages=messages, tools=tools,
            temperature=0.0 if attempt == 0 else 0.2, seed=42 + attempt,
            max_tokens=8192, stop_token_ids=[1, 50, 106], chat_template_kwargs={'enable_thinking': True})
        raw = request(payload, where, TEACHER)
        choice = raw['choices'][0]
        if choice['finish_reason'] == 'length':
            raise RuntimeError('truncated_teacher_reference')
        before = logical_state(db)
        msg = normalize(choice['message'])
        events = execute(env, messages, msg, where)
        all_events.extend(events)
        after = logical_state(db)
        if first_write is None and after != before:
            first_write = dict(reference_turn=f'turn-{turn:03d}', before=before, after=after,
                response_path=str(where / 'response.json'))
            shutil.copy2(db, out / 'first-transition.db')
        if not msg.get('tool_calls'):
            answer = msg.get('content', '')
            break
    result = verify(case, db, answer)
    dump(out / 'result.json', result)
    dump(out / 'trajectory.json', dict(messages=messages, execution=all_events))
    if result.get('result') != 'complete' or first_write is None:
        raise RuntimeError('teacher_reference_not_successful_or_no_stateful_correction')
    # Reference prefix before the first mutation consists of state-preserving reads.
    assert first_write['before'] == logical_state(case / 'pre_state.db')
    return out, first_write


def build(row):
    progress = Path('/mnt/genming/ablation-local-transition-20261104/progress.json')
    if progress.exists() and load(progress).get('qualified', 0) >= 10:
        return
    source = Path(row['directory'])
    key = row['task']
    if key in EXCLUDE:
        return
    outcome = load(source / 'unsteered/student/result.json')
    if outcome.get('has_http_500') or outcome.get('verification', {}).get('result') == 'complete':
        return
    task = load(source / 'analysis_context.json')['task']
    # Avoid the calendar ambiguity found in the rejected September appointment case.
    if any(word in task.lower() for word in ['today', 'tomorrow', 'next month', 'last month', 'last 30', 'past 30', 'next 7']):
        return
    context_hash = digest(source / 'context.json')
    cid = hashlib.sha256((key + context_hash).encode()).hexdigest()[:12]
    case = R / 'cases' / (key.replace(':', '_') + '-' + cid)
    if (case / 'outcome.json').exists() or (case / 'producer-error.json').exists():
        return
    case.mkdir(parents=True, exist_ok=True)
    try:
        tools = load(source / 'tools.json')
        # Choose a mutation (or premature terminal answer) in a real failed rollout.
        source_turns = sorted((source / 'unsteered/student').glob('turn-*/request.json'))
        if not source_turns:
            raise RuntimeError('missing_actual_student_requests')
        writes = []
        for f in source_turns:
            response = f.with_name('response.json')
            if not response.exists():
                continue
            msg = load(response)['choices'][0]['message']
            for call in msg.get('tool_calls') or []:
                name = call['function']['name'].removeprefix('mcp_server_')
                if name.startswith(('create_', 'update_', 'add_', 'patch_', 'delete_', 'set_', 'record_', 'submit_')):
                    writes.append(f)
        chosen = writes[-1] if writes else source_turns[-1]
        payload = load(chosen)
        context = payload['messages']
        assert not any('Procedural guidance.' in str(m.get('content', '')) or 'Local steering for this response' in str(m.get('content', '')) for m in context)
        for name in ['initial.db', 'task_verifier.py', 'analysis_context.json']:
            shutil.copy2(source / name, case / name)
        shutil.copy2(source / 'pre_state.db', case / 'pre_state.db')
        dump(case / 'context.json', context)
        dump(case / 'tools.json', tools)
        spec = dict(task=key, mode='relational_transition', source_directory=str(source),
            source_request=str(chosen), model=load(source / 'prepared.json')['student_checkpoint'],
            frozen_clock_utc=datetime_module.datetime.utcnow().isoformat(), pre_state_sha256=digest(case / 'pre_state.db'),
            randomness='uuid4 stream pinned to restored database hash; no user-provided identifiers changed',
            guidance_scope='first revised response only', candidate_kind='native_relational')
        dump(case / 'protocol.json', spec)
        env = open_environment(case, case / 'pre_state.db', case / 'prefix-replay')
        for f in source_turns:
            if f == chosen:
                break
            msg = load(f.with_name('response.json'))['choices'][0]['message']
            events = execute(env, [], msg, case / 'prefix-replay' / f.parent.name)
            if any(e.get('status_code', 0) >= 400 for e in events):
                raise RuntimeError('prefix_execution_error_cannot_restore_valid_context')
        spec['pre_state_sha256'] = digest(case / 'pre_state.db')
        dump(case / 'protocol.json', spec)
        before = case / 'before'
        before.mkdir(exist_ok=True)
        shutil.copy2(chosen, before / 'request.json')
        shutil.copy2(chosen.with_name('response.json'), before / 'response.json')
        shutil.copy2(case / 'pre_state.db', before / 'final.db')
        bad = open_environment(case, before / 'final.db', before)
        execute(bad, [], load(before / 'response.json')['choices'][0]['message'], before)
        reference = None
        for attempt in range(3):
            try:
                reference, alignment = generate_reference(case, attempt)
                break
            except Exception as exc:
                dump(case / f'reference-search-{attempt}/error.json', dict(error=str(exc)))
        if reference is None:
            raise RuntimeError('no_verified_teacher_reference_within_three_attempts')
        shutil.copytree(reference, case / 'reference')
        expected = logical_state(reference / 'first-transition.db')
        if expected == logical_state(before / 'final.db'):
            raise RuntimeError('original_student_mutation_already_matches_reference')
        dump(case / 'reference-expected-state.json', expected)
        spec['expected_state_sha256'] = state_hash(reference / 'first-transition.db')
        spec['fixed_reference_sha256'] = digest(case / 'reference/trajectory.json')
        dump(case / 'protocol.json', spec)
        # Re-execute the fixed reference and validate deterministic exact states.
        proof = case / 'reference-alignment'
        proof.mkdir(exist_ok=True)
        replay_db = proof / 'replayed.db'
        shutil.copy2(case / 'pre_state.db', replay_db)
        replay = open_environment(case, replay_db, proof)
        for f in sorted((case / 'reference').glob('turn-*/response.json')):
            execute(replay, [], load(f)['choices'][0]['message'], proof / f.parent.name)
            if f.parent.name == alignment['reference_turn']:
                assert state_hash(replay_db) == spec['expected_state_sha256']
                shutil.copy2(replay_db, proof / 'accepted-transition.db')
        assert verify(case, replay_db).get('result') == 'complete'
        dump(proof / 'receipt.json', dict(verified=True, restored_sha256=spec['pre_state_sha256'],
            verifier=verify(case, replay_db), fixed_reference_sha256=spec['fixed_reference_sha256'],
            exact_relational_state=True, pinned_clock_utc=spec['frozen_clock_utc'], alignment=alignment))
        dump(case / 'outcome.json', dict(task=key, candidate_ready=True, candidate_kind='native_relational',
            source_directory=str(source), accepted=False))
        print('VERIFIED_REFERENCE_CANDIDATE', key, case, flush=True)
    except Exception as exc:
        dump(case / 'producer-error.json', dict(error=str(exc)))
        print('CANDIDATE_EXCLUDED', key, str(exc), flush=True)


def main():
    R.mkdir(exist_ok=True)
    lock = (R / 'producer.lock').open('w')
    fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
    report = load('/mnt/genming/case-rerun-20261103/progress.json')
    selected = {}
    for row in report['all_cases']:
        root = Path(row['directory'])
        if not (root / 'unsteered/student/result.json').exists() or row['task'] in EXCLUDE:
            continue
        score = sum(row['states'].get(v) == 'fail' for v in ['teacher_freeform', 'student_structured', 'external_structured'])
        if row['task'] not in selected or score > selected[row['task']][0]:
            selected[row['task']] = (score, row)
    rows = [r for score, r in sorted(selected.values(), key=lambda pair: -pair[0])]
    dump(R / 'candidate-plan.json', rows)
    with ThreadPoolExecutor(max_workers=2) as pool:
        list(pool.map(build, rows))
    dump(R / 'producer-completed.json', dict(total_candidates=len(rows), finished_at=time.time()))


if __name__ == '__main__':
    main()
