"""Balanced stochastic follow-up of existing Gemma cases; no new model servers.

Every method, including ours, uses the same actor temperature and seed set.
Existing deterministic successes remain untouched. All outcomes are retained.
"""
import copy
import fcntl
import hashlib
import json
import os
from pathlib import Path
import shutil
import threading
import time
import traceback
from concurrent.futures import ThreadPoolExecutor

import httpx
import mine_local_ablations_thinking as m
from ablation_generation_transport import stream_local, request as external_request

R=Path('/mnt/genming/ablation-balanced-gemma-followup-20261105')
SOURCE=Path('/mnt/genming/ablation-local-thinking-20261104/cases')
PLAN=['banking_finance_3_2-68f3ec9ebd02-aligned',
      'banking_6_2-88648311d4ae-aligned',
      'booking_and_reservations_4_4-2adb87325b31-aligned',
      'asset_management_2_2-869d64e07a54-aligned-current-policy',
      'asset_management_6_6-8b08bb70174f-aligned',
      'b2b_ecommerce_marketplace_1_6-41a3e078faf0-aligned',
      'banking_6_4-a1a6d29ae0b9-aligned',
      'b2b_saas_7_5-db6f5d968924-aligned']
SEEDS=[71782927+i for i in range(4)]
ACTOR_TEMPERATURE=.6
LOCK=threading.Lock()


class ApprovedTargetReached(RuntimeError):pass


def target_reached():
    p=Path('/mnt/genming/ablation-supervision-20261105/quality-index.json')
    return p.exists() and m.load(p)['approved_showcase_cases']>=10


def emit(phase,**kw):
    record=dict(time=time.time(),phase=phase,**kw)
    with LOCK:
        m.dump(R/'status.json',record)
        if 'case' in kw:m.dump(R/'task-status'/kw['case'],record)
        print(json.dumps(record,ensure_ascii=False),flush=True)


def evidence(path):
    request=m.load(path/'request.json')
    return json.loads(request['messages'][1]['content'])


def request(payload,dest,endpoint,headers=None):
    if target_reached():raise ApprovedTargetReached('Ten manually approved cases reached')
    dest=Path(dest);dest.mkdir(parents=True,exist_ok=True)
    if (dest/'response.json').exists():return m.load(dest/'response.json')
    if endpoint not in [m.TEACHER,m.STUDENT]:return external_request(payload,dest,endpoint,headers)
    payload=copy.deepcopy(payload)
    counts=httpx.post(endpoint.removesuffix('/v1')+'/tokenize',
        json={k:payload[k] for k in ['model','messages','tools','chat_template_kwargs','add_generation_prompt'] if k in payload},
        timeout=60,trust_env=False)
    counts.raise_for_status();budget=counts.json()
    available=budget['max_model_len']-budget['count']-128
    if available<1024:raise ValueError('Context capacity excluded')
    payload['max_tokens']=min(32768,int(payload.get('max_tokens',32768)),available)
    m.dump(dest/'request.json',payload)
    m.dump(dest/'budget.json',dict(thinking=True,requested=32768,effective=payload['max_tokens'],prompt_tokens=budget['count']))
    transport=dest/('transport-'+str(time.time_ns()));transport.mkdir()
    wire=dict(payload,stream=True,stream_options={'include_usage':True})
    m.dump(transport/'request.json',wire)
    emit('model_request',case=dest.parts[dest.parts.index('cases')+1] if 'cases' in dest.parts else 'unknown',artifact=str(dest))
    raw=stream_local(wire,transport,endpoint,headers,wall_seconds=900)
    m.dump(dest/'response.json',raw)
    return raw


def actor(messages,tools,dest,seed,guidance=''):
    submitted=copy.deepcopy(messages)
    if guidance:submitted[0]['content']+='\n\nLocal steering for this response only:\n'+guidance
    payload=dict(model='case-model',messages=submitted,tools=tools,
        temperature=ACTOR_TEMPERATURE,top_p=.95,top_k=20,repetition_penalty=1.2,seed=seed,
        max_tokens=32768,stop_token_ids=[49,106],add_generation_prompt=True,min_tokens=16,
        chat_template_kwargs={'enable_thinking':True})
    raw=request(payload,dest,m.STUDENT)
    choice=raw['choices'][0];message=choice['message']
    if choice['finish_reason']=='length':raise ValueError('Truncated actor output excluded')
    if not message.get('tool_calls') and not (message.get('content') or '').strip():
        raise ValueError('Empty final output excluded; not a task failure')
    return m.normalize(message)


def copy_case(name):
    parent=SOURCE/name;case=R/'cases'/name
    original=m.load(parent/'ablation-outcome.json')
    assert original['ours']['local_status']=='pass' and original['ours']['final_verification']['result']=='complete'
    if not case.exists():shutil.copytree(parent,case,ignore=shutil.ignore_patterns('ablations','__pycache__','*.lock'))
    spec=m.load(case/'protocol.json')
    assert m.digest(case/'pre_state.db')==spec['pre_state_sha256']
    assert m.digest(case/'pre_state.db')==m.digest(parent/'pre_state.db')
    attempt=original['ours']['accepted_attempt']
    guide=parent/'ablations/teacher_structured'/f'attempt-{attempt}'/'advisor'
    assert guide.exists()
    common=evidence(guide)
    m.dump(case/'followup-source.json',dict(parent=str(parent),teacher_guidance=str(guide),
        source_identity=m.input_identity(parent),guidance_evidence_sha256=hashlib.sha256(json.dumps(common,sort_keys=True).encode()).hexdigest()))
    return case,guide,common


def revalidate_reference(case):
    out=case/'fresh-reference-replay';out.mkdir(exist_ok=True)
    if (out/'receipt.json').exists():return m.load(out/'receipt.json')
    db=out/'final.db';shutil.copy2(case/'pre_state.db',db)
    env=m.open_env(case,db,out);messages=copy.deepcopy(m.load(case/'context.json'))
    spec=m.load(case/'protocol.json');base=m.query(db,spec);saw=False
    for path in sorted((case/'reference').glob('turn-*/response.json')):
        msg=m.normalize(m.load(path)['choices'][0]['message'])
        events=m.execute(env,messages,msg,out/path.parent.name)
        after=m.query(db,spec,events)
        accepted=len(after)>len(base)
        saw|=accepted
        m.dump(out/path.parent.name/'local-effect-check.json',dict(accepted=accepted,base=base,after=after))
    verified=m.verifier(case,db,msg.get('content',''))
    m.dump(out/'evaluation.json',dict(local_effect_seen=saw,full_verification=verified))
    assert saw and verified.get('result')=='complete'
    receipt=dict(verified=True,pre_state_sha256=m.digest(case/'pre_state.db'),
        actual_fixed_teacher_actions_reexecuted=True,local_effect_seen=saw,full_verification=verified)
    m.dump(out/'receipt.json',receipt);return receipt


def rollout(case,role,guide_path,seed):
    work=case/'new-trials'/role/f'seed-{seed}'
    if (work/'record.json').exists():return m.load(work/'record.json')
    if (work/'excluded-error.json').exists():return None
    work.mkdir(parents=True,exist_ok=True)
    try:
        spec=m.load(case/'protocol.json');db=work/'final.db'
        shutil.copy2(case/'pre_state.db',db);assert m.digest(db)==spec['pre_state_sha256']
        env=m.open_env(case,db,work);messages=copy.deepcopy(m.load(case/'context.json'));tools=m.load(case/'tools.json')
        guide=m.load(guide_path)['text'];base=m.query(db,spec);first=None;all_events=[];finished=False
        for turn in range(32):
            msg=actor(messages,tools,work/f'turn-{turn:03d}',seed+turn,guide if turn==0 else '')
            events=m.execute(env,messages,msg,work/f'turn-{turn:03d}');all_events.extend(events)
            if turn==0:
                after=m.query(db,spec,events)
                first=dict(accepted=len(after)>len(base),checked_before_continuation=True,
                    pre=base,after=after,events=events,reference=str(case/'fresh-reference-replay/receipt.json'))
                m.dump(work/'local_gate.json',first);shutil.copy2(db,work/'local_state.db')
            if not msg.get('tool_calls'):
                finished=True;break
        if not finished:raise ValueError('Turn-limit rollout excluded')
        final=m.verifier(case,db,msg.get('content',''))
        requests=sorted(work.glob('turn-*/request.json'))
        original=m.load(case/'context.json')[0]
        assert guide in m.load(requests[0])['messages'][0]['content']
        assert all(m.load(p)['messages'][0]==original for p in requests[1:])
        assert all(m.load(p)['chat_template_kwargs']['enable_thinking'] for p in requests)
        actual_first_rejection=any(e.get('executed') and 400<=e.get('status_code',0)<500 for e in first['events'])
        record=dict(sample=str(work),guidance=str(guide_path),actor_seed=seed,temperature=ACTOR_TEMPERATURE,
            local_accepted=first['accepted'],full_verification=final,
            whole_task_passed=final.get('result')=='complete',
            actual_first_tool_rejected=actual_first_rejection,
            unsteered_requests=len(requests)-1,diagnostic_continuation_when_local_rejected=not first['accepted'])
        m.dump(work/'trajectory.json',dict(messages=messages,execution=all_events))
        m.dump(work/'record.json',record);return record
    except ApprovedTargetReached:raise
    except Exception as exc:
        m.dump(work/'excluded-error.json',dict(error=str(exc),traceback=traceback.format_exc(),excluded_not_a_semantic_failure=True));return None


def guide_for(case,parent,role,common):
    if role=='teacher_structured':return parent/'guidance.json'
    original=SOURCE/case.name/'ablations'/role/'attempt-0/advisor'
    if (original/'guidance.json').exists() and evidence(original)==common:return original/'guidance.json'
    out=case/'new-guidance'/role
    text=m.advisor(case,role,out,common.get('retry_feedback',[]))
    assert text and evidence(out)==common
    return out/'guidance.json'


def branch(case,role,gpath):
    history=[]
    for seed in SEEDS:
        emit('sample',case=case.name,variant=role,seed=seed)
        record=rollout(case,role,gpath,seed)
        if record is None:continue
        history.append(record)
        good=(record['local_accepted'] and record['whole_task_passed'] and record['unsteered_requests']>0) if role=='teacher_structured' else (
            not record['whole_task_passed'] or record['actual_first_tool_rejected'])
        if good:return dict(found=True,selected=record,history=history)
    return dict(found=False,history=history)


def audit(case,record,role):
    source=Path(record['sample']);out=case/'independent-replay'/role
    if (out/'receipt.json').exists():return m.load(out/'receipt.json')
    out.mkdir(parents=True,exist_ok=True);db=out/'final.db';shutil.copy2(case/'pre_state.db',db)
    env=m.open_env(case,db,out);messages=copy.deepcopy(m.load(case/'context.json'));spec=m.load(case/'protocol.json');base=m.query(db,spec)
    first=None
    for path in sorted(source.glob('turn-*/response.json')):
        msg=m.normalize(m.load(path)['choices'][0]['message'])
        got=m.execute(env,messages,msg,out/path.parent.name)
        assert got==m.load(path.parent/'execution.json')
        if first is None:first=len(m.query(db,spec,got))>len(base)
    final=m.verifier(case,db,msg.get('content',''))
    assert (final.get('result')=='complete')==record['whole_task_passed']
    assert first==record['local_accepted']
    receipt=dict(verified=True,actual_actions_reexecuted=True,local_acceptance_reproduced=first,
        full_verification_reproduced=final,guidance_only_first_request=True)
    m.dump(out/'receipt.json',receipt);return receipt


def run(name):
    if target_reached():return
    case=R/'cases'/name
    if (case/'comparison.json').exists():return
    try:
        case,tguide,common=copy_case(name);revalidate_reference(case)
        ours=branch(case,'teacher_structured',tguide/'guidance.json');controls={};audits={}
        if ours['found']:
            for index,role in enumerate(['teacher_freeform','student_structured','external_structured']):
                try:
                    gpath=guide_for(case,tguide,role,common)
                    controls[role]=branch(case,role,gpath)
                except ApprovedTargetReached:raise
                except Exception as exc:
                    m.dump(case/'new-guidance'/role/'excluded-error.json',dict(error=str(exc),traceback=traceback.format_exc()));controls[role]=dict(found=False,history=[],excluded=True)
                hits=sum(v['found'] for v in controls.values())
                if hits>=2 or hits+(2-index)<2:break
            if sum(v['found'] for v in controls.values())>=2:
                for role,record in {'teacher_structured':ours['selected'],**{k:v['selected'] for k,v in controls.items() if v['found']}}.items():
                    audits[role]=audit(case,record,role)
        qualified=ours['found'] and sum(v['found'] for v in controls.values())>=2
        m.dump(case/'comparison.json',dict(task=m.load(case/'protocol.json')['task'],qualified=qualified,
            ours=ours,controls=controls,replay_audits=audits,manual_quality_review_required=qualified,
            actor_sampling_balanced=True,temperature=.6,original_deterministic_trials_preserved=True,
            evaluation_unit='selected recovery episodes; local and whole-task outcomes retained'))
    except ApprovedTargetReached:emit('approved_target_reached',case=name);return
    except Exception as exc:m.dump(case/'needs-review.json',dict(error=str(exc),traceback=traceback.format_exc(),excluded_not_a_model_failure=True))
    with LOCK:
        rows=[m.load(p) for p in (R/'cases').glob('*/comparison.json')]
        m.dump(R/'progress.json',dict(completed=len(rows),replay_verified_candidates=[v['task'] for v in rows if v['qualified']],manual_review_required=True))


def main():
    R.mkdir(parents=True,exist_ok=True)
    lock=(R/'controller.lock').open('w');fcntl.flock(lock,fcntl.LOCK_EX | fcntl.LOCK_NB)
    m.R=R;m.cached_request=request
    m.dump(R/'protocol.json',dict(backbone='Gemma 4 12B',existing_services=[m.TEACHER,m.STUDENT],
        actor_temperature=.6,actor_seeds=SEEDS,original_actor_temperature=0.0,
        ours_rerun_with_same_sampling_as_controls=True,thinking=True,requested_max_tokens=32768,
        original_task_prompt_and_native_verifier_unchanged=True,existing_guidance_reused_when_evidence_matches=True,
        all_valid_successes_and_failures_preserved=True,selected_case_evidence_not_aggregate_performance=True))
    with ThreadPoolExecutor(max_workers=2) as pool:
        pending=[]
        for name in PLAN:
            index=Path('/mnt/genming/ablation-supervision-20261105/quality-index.json')
            if index.exists() and m.load(index)['approved_showcase_cases']>=10:break
            pending.append(pool.submit(run,name))
        for future in pending:future.result()
    emit('balanced_existing_case_followup_complete')


if __name__=='__main__':main()
