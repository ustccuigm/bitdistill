"""Native Gemma thinking budget followed by its own action continuation.

Both phases use the same student checkpoint. Task messages are unchanged;
only actual student-generated thinking is used as an assistant prefill. Every
wire request/response is retained. No action or tool argument is hand-written.
"""
import copy
import hashlib
import json
from pathlib import Path
import time

import httpx
import balanced_existing_gemma_cases as b
from ablation_generation_transport import InvalidGeneration, repeated_reasoning

m = b.m
MIN_THINKING_TOKENS = 128
TOTAL_COMPLETION_BUDGET = 32768
NORMALIZER_VERSION = 2


def normalize_native_thought(text, prompt_has_open_thinking):
    """Remove native channel labels while preserving all generated words.

    Gemma can restart its thought channel after already emitting thought text.
    This is a serialization boundary, not an empty or invalid generation.
    """
    body = text.split('<channel|>', 1)[0]
    pieces = body.split('<|channel>')
    if not prompt_has_open_thinking and pieces[0].strip():
        raise InvalidGeneration('Text outside a native thinking channel excluded')
    normalized = [pieces[0].removeprefix('thought\n')]
    for piece in pieces[1:]:
        if not piece.startswith('thought\n'):
            raise InvalidGeneration('Non-thinking channel inside thinking phase excluded')
        normalized.append(piece[len('thought\n'):])
    return ''.join(normalized).strip(), dict(
        normalizer_version=NORMALIZER_VERSION, native_open_markers_removed=len(pieces) - 1,
        native_thinking_text_before_restart_chars=len(pieces[0]) if len(pieces) > 1 else 0,
        generated_natural_language_preserved=True, human_reasoning_added=False)


def _tokenize(payload):
    response = httpx.post(m.STUDENT.removesuffix('/v1') + '/tokenize',
                          json=payload, timeout=60, trust_env=False)
    response.raise_for_status()
    return response.json()


def _completion(payload, dest):
    dest.mkdir(parents=True, exist_ok=True)
    request_path = dest / 'request.json'
    if request_path.exists():
        assert m.load(request_path) == payload, 'Cached native request changed'
        if (dest / 'response.json').exists():
            return m.load(dest / 'response.json')
        raise InvalidGeneration('Incomplete thinking sample retained; use a new sample directory')
    m.dump(request_path, payload)
    b.emit('student_thinking', case=dest.parts[dest.parts.index('cases') + 1], artifact=str(dest))
    wire = dict(payload, stream=True, stream_options={'include_usage': True})
    m.dump(dest / 'wire-request.json', wire)
    text, usage, finish, stop, identity = '', None, None, None, {}
    start = time.monotonic()
    with (dest / 'stream.jsonl').open('w') as log:
        with httpx.stream('POST', m.STUDENT + '/completions', json=wire,
                          timeout=httpx.Timeout(connect=30, read=120, write=60, pool=30),
                          trust_env=False) as response:
            if response.status_code >= 400:
                response.read()
                m.dump(dest / 'http-error.json', dict(status=response.status_code, body=response.text))
            response.raise_for_status()
            for line in response.iter_lines():
                if not line.startswith('data:'):
                    continue
                body = line[5:].strip()
                if body == '[DONE]':
                    break
                chunk = json.loads(body)
                log.write(json.dumps(chunk, ensure_ascii=False) + '\n')
                log.flush()
                identity.update({k: chunk[k] for k in ['id', 'model', 'created'] if k in chunk})
                if chunk.get('usage'):
                    usage = chunk['usage']
                for choice in chunk.get('choices', []):
                    if choice.get('index', 0) != 0:
                        continue
                    text += choice.get('text') or ''
                    finish = choice.get('finish_reason') or finish
                    if choice.get('stop_reason') is not None:
                        stop = choice['stop_reason']
                if repeated_reasoning(text) or time.monotonic() - start > 900:
                    m.dump(dest / 'partial-response.json', dict(text=text, usage=usage))
                    raise InvalidGeneration('Invalid or over-budget thinking excluded, not a task failure')
    result = dict(identity, object='text_completion',
                  choices=[dict(index=0, text=text, finish_reason=finish, stop_reason=stop)], usage=usage)
    m.dump(dest / 'response.json', result)
    if finish != 'stop' or not usage:
        raise InvalidGeneration('Thinking did not finish natively; excluded')
    return result


def actor(messages, tools, dest, seed, guidance=''):
    dest = Path(dest)
    submitted = copy.deepcopy(messages)
    if guidance:
        submitted[0]['content'] += '\n\nLocal steering for this response only:\n' + guidance
    intent = dict(model='case-model', messages=submitted, tools=tools,
                  temperature=0.0, seed=42, max_tokens=TOTAL_COMPLETION_BUDGET,
                  stop_token_ids=[49, 106], add_generation_prompt=True, min_tokens=16,
                  chat_template_kwargs={'enable_thinking': True})
    m.dump(dest / 'intent-request.json', intent)
    tokenized = _tokenize(dict({k: intent[k] for k in
                          ['model', 'messages', 'tools', 'add_generation_prompt', 'chat_template_kwargs']},
                          return_token_strs=True))
    m.dump(dest / 'thinking/tokenized-intent.json', tokenized)
    boundary = _tokenize(dict(model='case-model', prompt='<channel|><|tool_call>',
                              add_special_tokens=False, return_token_strs=True))
    ids = dict(zip(boundary['token_strs'], boundary['tokens']))
    end_id = ids['<channel|>']
    available = tokenized['max_model_len'] - tokenized['count'] - 128
    if available < 1024:
        raise InvalidGeneration('Insufficient thinking context; excluded')
    thinking_payload = dict(model='case-model', prompt=tokenized['tokens'], temperature=0.0,
        seed=42, max_tokens=min(TOTAL_COMPLETION_BUDGET, available), min_tokens=MIN_THINKING_TOKENS,
        stop_token_ids=sorted(set([49, 106, end_id, ids['<|tool_call>']])),
        skip_special_tokens=False, include_stop_str_in_output=True)
    raw = _completion(thinking_payload, dest / 'thinking/native-generation')
    choice = raw['choices'][0]
    if choice['stop_reason'] != end_id or '<channel|>' not in choice['text']:
        raise InvalidGeneration('Thinking boundary incomplete; not scored as a semantic failure')
    prompt_has_open_thinking = tokenized['token_strs'][-3:] == ['<|channel>', 'thought', '\n']
    if not prompt_has_open_thinking and '<|channel>' not in choice['text']:
        raise InvalidGeneration('Generated text was not in a native reasoning channel; excluded')
    reasoning, normalization = normalize_native_thought(choice['text'], prompt_has_open_thinking)
    if len(reasoning) < 80:
        raise InvalidGeneration('No substantive generated thinking; excluded')
    generated = raw['usage']['completion_tokens']
    assert generated >= MIN_THINKING_TOKENS
    remaining = TOTAL_COMPLETION_BUDGET - generated
    if remaining < 128:
        raise InvalidGeneration('No action budget left after thinking; excluded')
    continuation = copy.deepcopy(intent)
    continuation['messages'].append(dict(role='assistant', content='', reasoning=reasoning))
    continuation.update(add_generation_prompt=False, continue_final_message=True,
                        max_tokens=remaining)
    if (dest / 'action/request.json').exists():
        previous = m.load(dest / 'action/request.json')
        assert {k: v for k, v in previous.items() if k != 'max_tokens'} == {
            k: v for k, v in continuation.items() if k != 'max_tokens'}, 'Cached action continuation changed'
    # b.request records the exact submitted continuation and streams its native
    # response. It applies the server context limit before generation.
    response = b.request(continuation, dest / 'action', m.STUDENT)
    native_request = m.load(dest / 'action/request.json')
    m.dump(dest / 'request.json', native_request)
    m.dump(dest / 'response.json', response)  # native response, never relabelled as reasoning
    msg = response['choices'][0]['message']
    if response['choices'][0]['finish_reason'] == 'length':
        raise InvalidGeneration('Truncated action excluded')
    if not msg.get('tool_calls') and not (msg.get('content') or '').strip():
        raise InvalidGeneration('Empty action excluded')
    assert generated + response['usage']['completion_tokens'] <= TOTAL_COMPLETION_BUDGET
    proof_path = dest / 'thinking-verification.json'
    if proof_path.exists() and not (dest / 'thinking-verification-before-normalizer-v2.json').exists():
        m.dump(dest / 'thinking-verification-before-normalizer-v2.json', m.load(proof_path))
    m.dump(proof_path, dict(
        verified=True, requested_minimum_thinking_tokens=MIN_THINKING_TOKENS,
        actual_thinking_phase_generated_tokens=generated, actual_reasoning_characters=len(reasoning),
        reasoning_sha256=hashlib.sha256(reasoning.encode()).hexdigest(),
        reasoning_generated_by_same_student=True, human_authored_reasoning=False,
        native_action_response_not_modified=True, logical_task_messages_unchanged=True,
        same_thinking_budget_required_for_all_actor_variants=True,
        reasoning_prefill_is_exact_generated_channel_body=(normalization['native_open_markers_removed'] == 0 or
            (normalization['native_open_markers_removed'] == 1 and normalization['native_thinking_text_before_restart_chars'] == 0)),
        native_channel_normalization=normalization,
        all_phases_combined_completion_budget=TOTAL_COMPLETION_BUDGET,
        actual_total_generated_tokens=generated + response['usage']['completion_tokens']))
    return m.normalize(msg)


def rendered_identity(sample):
    path = Path(sample) / 'turn-001/thinking/tokenized-intent.json'
    if not path.exists():
        return None
    return hashlib.sha256(json.dumps(m.load(path)['tokens']).encode()).hexdigest()
