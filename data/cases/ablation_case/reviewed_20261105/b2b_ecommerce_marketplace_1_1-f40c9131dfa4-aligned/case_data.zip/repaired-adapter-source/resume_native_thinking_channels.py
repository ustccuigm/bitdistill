"""Repair only channel-normalization interruptions after verified local success.

Earlier model generations are reused exactly. No teacher or student sample is
redrawn to obtain a preferred verdict. Previous exclusions and partial states
remain available beside the repaired continuation.
"""
import fcntl
from pathlib import Path
import shutil
import traceback

import run_verified_thinking_cases as v

g, b, m, thinking = v.g, v.b, v.m, v.thinking
R = Path('/mnt/genming/ablation-thinking-channel-resume-20261105')
NAME = 'b2b_ecommerce_marketplace_1_1-f40c9131dfa4-aligned'


def main():
    R.mkdir(exist_ok=True)
    lock = (R / 'controller.lock').open('w')
    fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
    b.R = R
    m.R = R
    b.actor = thinking.actor
    b.ACTOR_TEMPERATURE = 0.0
    g.rendered_identity = thinking.rendered_identity
    m.cached_request = g.request
    m.query = v.semantic_query
    case = v.R / 'cases' / NAME
    prior = m.load(case / 'comparison.json')
    assert not prior['qualified'] and not prior['ours']['found']
    assert prior.get('student_thinking_protocol'), 'Original worker must have completed this case'
    preserved = case / 'comparison-before-channel-normalization-v2.json'
    if not preserved.exists():
        shutil.copy2(case / 'comparison.json', preserved)
    m.dump(R / 'protocol.json', dict(source_case=str(case),
        repair='Normalize repeated native thought-channel labels without discarding generated language',
        minimum_thinking_tokens=128, actor_temperature=0.0, actor_seed=42,
        native_generations_reused_from_preserved_streams=True,
        repair_only_locally_accepted_interrupted_method_samples=True,
        successful_samples_not_resampled=True, original_exclusions_and_states_preserved=True,
        all_control_sources_use_the_same_repaired_actor_adapter=True,
        no_case_is_approved_automatically=True))
    resumed, selected = [], None
    for guide_seed in [42, 44, 45]:
        sample = case / 'new-trials/teacher_structured' / f'guide-{guide_seed}' / 'seed-42'
        excluded = sample / 'excluded-error.json'
        if not excluded.exists() or m.load(excluded)['error'] != 'Malformed thinking channels excluded':
            continue
        assert m.load(sample / 'local_gate.json')['accepted']
        preserved_error = sample / 'excluded-error-preserved-normalizer-v1.json'
        if preserved_error.exists():
            raise ValueError('A prior repair already exists; refusing to overwrite it')
        excluded.rename(preserved_error)
        state_archive = sample / 'normalizer-v1-preserved-states'
        state_archive.mkdir(exist_ok=True)
        for filename in ['final.db', 'local_state.db', 'local_gate.json']:
            shutil.copy2(sample / filename, state_archive / filename)
        guide = case / 'sampled-guidance/teacher_structured' / f'guide-{guide_seed}' / 'guidance.json'
        b.emit('resume_cached_thinking_continuation', case=NAME, guidance_seed=guide_seed)
        record = b.rollout(case, f'teacher_structured/guide-{guide_seed}', guide, 42)
        if record:
            record.update(guidance_seed=guide_seed, actor_temperature=0.0, guide_temperature=0.6,
                          native_thinking_channel_repair_version=2,
                          source_revision_root=str(R))
            resumed.append(record)
            if record['local_accepted'] and record['whole_task_passed'] and record['unsteered_requests'] > 0:
                selected = record
                break
    m.dump(R / 'resumed-method-outcomes.json', resumed)
    if not selected:
        b.emit('channel_repair_complete_without_qualified_method', case=NAME)
        return
    ours = dict(found=True, selected=selected, history=resumed)
    common = b.evidence(Path(selected['guidance']).parent)
    controls, audits = {}, {}
    for index, role in enumerate(['teacher_freeform', 'student_structured', 'external_structured']):
        controls[role] = g.branch(case, role, common, ours)
        count = sum(v['found'] for v in controls.values())
        if count >= 2 or count + (2 - index) < 2:
            break
    qualified = sum(v['found'] for v in controls.values()) >= 2
    if qualified:
        for role, record in {'teacher_structured': selected,
                             **{k: v['selected'] for k, v in controls.items() if v['found']}}.items():
            audits[role] = b.audit(case, record, role)
    result = dict(task=m.load(case / 'protocol.json')['task'], qualified=qualified,
        ours=ours, controls=controls, replay_audits=audits,
        manual_quality_review_required=qualified, actor_temperature=0.0, actor_seed=42,
        guidance_temperature=0.6, same_evidence_for_every_guidance_source=True,
        candidate_local_mismatches_require_semantic_review=True,
        post_guidance_identical_contexts_excluded_from_contrasts=True,
        no_aggregate_performance_claim=True,
        student_thinking_protocol=dict(minimum_tokens=128, total_completion_budget=32768,
            two_native_generations_same_checkpoint=True, normalizer_version=2,
            terminal_task_verifier_unchanged=True),
        normalizer_repair_source=str(R), prior_comparison_preserved=str(preserved))
    v.check_actor_thinking(case)
    m.dump(case / 'comparison.json', result)
    m.dump(R / 'repair-result.json', dict(comparison=str(case / 'comparison.json'), qualified=qualified))
    b.emit('channel_repair_comparison_complete', case=NAME, qualified=qualified)


if __name__ == '__main__':
    try:
        main()
    except Exception as exc:
        m.dump(R / 'needs-review.json', dict(error=str(exc), traceback=traceback.format_exc(),
                                           excluded_not_a_model_failure=True))
        raise
