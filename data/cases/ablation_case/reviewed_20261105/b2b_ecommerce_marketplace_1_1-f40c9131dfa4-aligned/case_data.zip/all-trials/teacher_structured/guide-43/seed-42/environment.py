import os
from datetime import datetime, date
from typing import List, Optional, Dict

from fastapi import FastAPI, Query, Path, Body
from pydantic import BaseModel, Field, ConfigDict
from sqlalchemy import (
    create_engine,
    Column,
    Integer,
    String,
    DateTime,
    Date,
    Text,
    ForeignKey,
    CheckConstraint,
    UniqueConstraint,
    Index,
    Float,
)
from sqlalchemy.orm import declarative_base, relationship, sessionmaker

database_url = os.getenv("DATABASE_PATH", "sqlite:///outputs/databases/crafthub_b2b_wholesale_marketplace.db")

engine = create_engine("sqlite:////mnt/genming/ablation-verified-thinking-20261105/cases/b2b_ecommerce_marketplace_1_1-f40c9131dfa4-aligned/new-trials/teacher_structured/guide-43/seed-42/final.db", connect_args={"check_same_thread": False})
SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)
Base = declarative_base()

app = FastAPI(title="CraftHub B2B Wholesale Marketplace API", version="1.0.0")


class User(Base):
    __tablename__ = "users"
    id = Column(Integer, primary_key=True)
    username = Column(String, unique=True, nullable=False)
    email = Column(String, unique=True, nullable=False)
    full_name = Column(String)
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow)


class Company(Base):
    __tablename__ = "companies"
    id = Column(Integer, primary_key=True)
    name = Column(String, nullable=False)
    company_type = Column(String, nullable=False)
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow)


class UserCompany(Base):
    __tablename__ = "user_companies"
    id = Column(Integer, primary_key=True)
    user_id = Column(Integer, ForeignKey("users.id"), nullable=False)
    company_id = Column(Integer, ForeignKey("companies.id"), nullable=False)
    role = Column(String)
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow)


class Category(Base):
    __tablename__ = "categories"
    id = Column(Integer, primary_key=True)
    name = Column(String, nullable=False)
    parent_id = Column(Integer, ForeignKey("categories.id"))
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow)


class Product(Base):
    __tablename__ = "products"
    id = Column(Integer, primary_key=True)
    supplier_id = Column(Integer, ForeignKey("companies.id"), nullable=False)
    sku = Column(String, nullable=False)
    title = Column(String, nullable=False)
    category_id = Column(Integer, ForeignKey("categories.id"), nullable=False)
    case_pack_quantity = Column(Integer, nullable=False)
    minimum_order_case_packs = Column(Integer, nullable=False)
    lead_time_business_days = Column(Integer, nullable=False)
    availability_status = Column(String, nullable=False)
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow)


class ProductPriceTier(Base):
    __tablename__ = "product_price_tiers"
    id = Column(Integer, primary_key=True)
    product_id = Column(Integer, ForeignKey("products.id"), nullable=False)
    min_case_packs = Column(Integer, nullable=False)
    max_case_packs = Column(Integer)
    unit_price = Column(Float, nullable=False)
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow)


class StoreLocation(Base):
    __tablename__ = "store_locations"
    id = Column(Integer, primary_key=True)
    retailer_id = Column(Integer, ForeignKey("companies.id"), nullable=False)
    name = Column(String, nullable=False)
    address_line1 = Column(String, nullable=False)
    address_line2 = Column(String)
    city = Column(String)
    state = Column(String)
    postal_code = Column(String)
    country = Column(String)
    shipping_contact_name = Column(String)
    shipping_contact_phone = Column(String)
    is_default_destination = Column(Integer, nullable=False, default=0)
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow)


class WholesaleCart(Base):
    __tablename__ = "wholesale_carts"
    id = Column(Integer, primary_key=True)
    retailer_id = Column(Integer, ForeignKey("companies.id"), nullable=False)
    supplier_id = Column(Integer, ForeignKey("companies.id"), nullable=False)
    store_location_id = Column(Integer, ForeignKey("store_locations.id"), nullable=False)
    status = Column(String, nullable=False, default="open")
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow)


class WholesaleCartItem(Base):
    __tablename__ = "wholesale_cart_items"
    id = Column(Integer, primary_key=True)
    cart_id = Column(Integer, ForeignKey("wholesale_carts.id"), nullable=False)
    product_id = Column(Integer, ForeignKey("products.id"), nullable=False)
    quantity_case_packs = Column(Integer, nullable=False)
    unit_price_snapshot = Column(Float)
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow)


class PurchaseOrder(Base):
    __tablename__ = "purchase_orders"
    id = Column(Integer, primary_key=True)
    po_number = Column(String, nullable=False)
    retailer_id = Column(Integer, ForeignKey("companies.id"), nullable=False)
    supplier_id = Column(Integer, ForeignKey("companies.id"), nullable=False)
    buyer_user_id = Column(Integer, ForeignKey("users.id"))
    store_location_id = Column(Integer, ForeignKey("store_locations.id"), nullable=False)
    status = Column(String, nullable=False)
    requested_delivery_date = Column(Date)
    shipping_preference = Column(Text)
    buyer_note = Column(Text)
    supplier_internal_note = Column(Text)
    estimated_ship_date = Column(Date)
    expected_delivery_date = Column(Date)
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow)


class PurchaseOrderItem(Base):
    __tablename__ = "purchase_order_items"
    id = Column(Integer, primary_key=True)
    purchase_order_id = Column(Integer, ForeignKey("purchase_orders.id"), nullable=False)
    product_id = Column(Integer, ForeignKey("products.id"), nullable=False)
    sku = Column(String, nullable=False)
    title = Column(String, nullable=False)
    case_pack_quantity = Column(Integer, nullable=False)
    quantity_case_packs = Column(Integer, nullable=False)
    unit_price = Column(Float, nullable=False)
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow)


class PurchaseOrderItemAllocation(Base):
    __tablename__ = "purchase_order_item_allocations"
    id = Column(Integer, primary_key=True)
    po_item_id = Column(Integer, ForeignKey("purchase_order_items.id"), nullable=False)
    store_location_id = Column(Integer, ForeignKey("store_locations.id"), nullable=False)
    quantity_case_packs = Column(Integer, nullable=False)
    requested_delivery_date = Column(Date)
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow)


class OrderRevision(Base):
    __tablename__ = "order_revisions"
    id = Column(Integer, primary_key=True)
    purchase_order_id = Column(Integer, ForeignKey("purchase_orders.id"), nullable=False)
    revision_number = Column(Integer, nullable=False)
    status = Column(String, nullable=False)
    buyer_comment = Column(Text)
    supplier_comment = Column(Text)
    created_by_user_id = Column(Integer, ForeignKey("users.id"))
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow)


class OrderRevisionItem(Base):
    __tablename__ = "order_revision_items"
    id = Column(Integer, primary_key=True)
    order_revision_id = Column(Integer, ForeignKey("order_revisions.id"), nullable=False)
    po_item_id = Column(Integer, ForeignKey("purchase_order_items.id"), nullable=False)
    proposed_quantity_case_packs = Column(Integer, nullable=False)
    change_type = Column(String, nullable=False)
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow)


class Shipment(Base):
    __tablename__ = "shipments"
    id = Column(Integer, primary_key=True)
    purchase_order_id = Column(Integer, ForeignKey("purchase_orders.id"), nullable=False)
    carrier = Column(String, nullable=False)
    tracking_number = Column(String, nullable=False)
    ship_date = Column(Date, nullable=False)
    expected_delivery_date = Column(Date)
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow)


class ShipmentItem(Base):
    __tablename__ = "shipment_items"
    id = Column(Integer, primary_key=True)
    shipment_id = Column(Integer, ForeignKey("shipments.id"), nullable=False)
    po_item_id = Column(Integer, ForeignKey("purchase_order_items.id"), nullable=False)
    quantity_case_packs = Column(Integer, nullable=False)
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow)


class Invoice(Base):
    __tablename__ = "invoices"
    id = Column(Integer, primary_key=True)
    invoice_number = Column(String, nullable=False)
    purchase_order_id = Column(Integer, ForeignKey("purchase_orders.id"), nullable=False)
    supplier_id = Column(Integer, ForeignKey("companies.id"), nullable=False)
    retailer_id = Column(Integer, ForeignKey("companies.id"), nullable=False)
    issue_date = Column(Date, nullable=False)
    due_date = Column(Date, nullable=False)
    subtotal_amount = Column(Float, nullable=False)
    tax_amount = Column(Float, nullable=False, default=0)
    shipping_amount = Column(Float, nullable=False, default=0)
    total_amount = Column(Float, nullable=False)
    payment_terms = Column(Text)
    status = Column(String, nullable=False)
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow)


class InvoicePayment(Base):
    __tablename__ = "invoice_payments"
    id = Column(Integer, primary_key=True)
    invoice_id = Column(Integer, ForeignKey("invoices.id"), nullable=False)
    payment_date = Column(Date, nullable=False)
    amount = Column(Float, nullable=False)
    payment_method = Column(Text)
    reference = Column(Text)
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow)


Base.metadata.create_all(engine)


class CategoryModel(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: int = Field(..., description="Category id", example=3)
    name: str = Field(..., description="Category name", example="Drinkware")
    parent_id: Optional[int] = Field(None, description="Parent category id or null", example=None)
    created_at: Optional[datetime] = Field(None, description="Creation timestamp", example="2025-01-02T10:00:00Z")
    updated_at: Optional[datetime] = Field(None, description="Last update timestamp", example="2025-01-05T15:30:00Z")


class ListCategoriesResponse(BaseModel):
    categories: List[CategoryModel] = Field(..., description="List of categories", example=[])


class CompanyModel(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: int = Field(..., description="Company id", example=10)
    name: str = Field(..., description="Company name", example="Everglow Candles")
    company_type: str = Field(..., description="Company type: supplier or retailer", example="supplier")
    created_at: Optional[datetime] = Field(None, description="Creation timestamp", example="2024-11-01T09:00:00Z")
    updated_at: Optional[datetime] = Field(None, description="Last update timestamp", example="2024-12-15T11:30:00Z")


class ListCompaniesResponse(BaseModel):
    companies: List[CompanyModel] = Field(..., description="List of companies", example=[])


class MyCompanyModel(BaseModel):
    company_id: int = Field(..., description="Linked company id", example=5)
    name: str = Field(..., description="Company name", example="CraftHub Retail LLC")
    company_type: str = Field(..., description="Company type", example="retailer")
    user_role: Optional[str] = Field(None, description="Role of current user in company", example="buyer_admin")


class MyCompaniesResponse(BaseModel):
    companies: List[MyCompanyModel] = Field(..., description="Companies linked to user", example=[])


class ProductModel(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: int = Field(..., description="Product id", example=101)
    supplier_id: int = Field(..., description="Supplier id", example=20)
    sku: str = Field(..., description="Product SKU", example="HANDMUG-012")
    title: str = Field(..., description="Product title", example="Handmade Stoneware Coffee Mug")
    category_id: int = Field(..., description="Category id", example=3)
    case_pack_quantity: int = Field(..., description="Units per case pack", example=12)
    minimum_order_case_packs: int = Field(..., description="Minimum order case packs", example=3)
    lead_time_business_days: int = Field(..., description="Lead time in business days", example=10)
    availability_status: str = Field(..., description="Availability status", example="in_stock")
    created_at: Optional[datetime] = Field(None, description="Creation timestamp", example="2025-01-02T10:15:00Z")
    updated_at: Optional[datetime] = Field(None, description="Last update timestamp", example="2025-01-02T10:15:00Z")


class ProductResponse(BaseModel):
    product: ProductModel = Field(..., description="Product", example={})


class CreateProductRequest(BaseModel):
    supplier_id: int = Field(..., description="Supplier company id owned by current user", example=20)
    sku: str = Field(..., description="Unique SKU within this supplier", example="HANDMUG-012")
    title: str = Field(..., description="Product title", example="Handmade Stoneware Coffee Mug")
    category_id: int = Field(..., description="Category id for this product", example=3)
    case_pack_quantity: int = Field(..., description="Number of units per case pack", example=12)
    minimum_order_case_packs: int = Field(..., description="Minimum case packs per order", example=3)
    lead_time_business_days: int = Field(..., description="Lead time in business days", example=10)
    availability_status: str = Field(..., description="Availability: in_stock, backorder, discontinued, unavailable", example="in_stock")


class UpdateProductRequest(BaseModel):
    title: Optional[str] = Field(None, description="New product title", example="Linen Napkin Set of 4")
    category_id: Optional[int] = Field(None, description="New category id", example=6)
    case_pack_quantity: Optional[int] = Field(None, description="Updated case pack quantity", example=4)
    minimum_order_case_packs: Optional[int] = Field(None, description="Updated minimum order case packs", example=3)
    lead_time_business_days: Optional[int] = Field(None, description="Updated lead time in business days", example=21)
    availability_status: Optional[str] = Field(None, description="Updated availability status", example="backorder")


class GetProductBySkuResponse(BaseModel):
    product: Optional[ProductModel] = Field(None, description="Product if found", example={})


class PriceTierModel(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: int = Field(..., description="Price tier id", example=7001)
    product_id: int = Field(..., description="Product id", example=101)
    min_case_packs: int = Field(..., description="Minimum case packs for this tier", example=1)
    max_case_packs: Optional[int] = Field(None, description="Maximum case packs for this tier or null", example=5)
    unit_price: float = Field(..., description="Unit price in this tier", example=5.0)
    created_at: Optional[datetime] = Field(None, description="Creation timestamp", example="2025-01-02T10:20:00Z")
    updated_at: Optional[datetime] = Field(None, description="Last updated timestamp", example="2025-01-02T10:20:00Z")


class ListPriceTiersResponse(BaseModel):
    price_tiers: List[PriceTierModel] = Field(..., description="List of price tiers", example=[])


class CreatePriceTierRequest(BaseModel):
    min_case_packs: int = Field(..., description="Minimum case packs for this pricing tier", example=1)
    max_case_packs: Optional[int] = Field(None, description="Maximum case packs for this tier; null for open-ended", example=5)
    unit_price: float = Field(..., description="Unit price at this tier", example=5.0)


class PriceTierResponse(BaseModel):
    price_tier: PriceTierModel = Field(..., description="Created price tier", example={})


class DeletePriceTiersResponse(BaseModel):
    deleted_count: int = Field(..., description="Number of deleted price tier records", example=3)


class SearchPriceTierModel(BaseModel):
    id: int = Field(..., description="Price tier id", example=5001)
    min_case_packs: int = Field(..., description="Min case packs for this tier", example=1)
    max_case_packs: Optional[int] = Field(None, description="Max case packs for this tier or null", example=10)
    unit_price: float = Field(..., description="Unit price in this tier", example=5.0)


class SearchProductModel(BaseModel):
    product_id: int = Field(..., description="Product id", example=205)
    supplier_id: int = Field(..., description="Supplier id", example=20)
    supplier_name: str = Field(..., description="Supplier company name", example="Everglow Candles")
    sku: str = Field(..., description="Product SKU", example="CANDLE-LAV-8OZ")
    title: str = Field(..., description="Product title", example="Lavender Soy Candle 8oz")
    category_id: int = Field(..., description="Category id", example=7)
    category_name: str = Field(..., description="Category name", example="Home Fragrance")
    case_pack_quantity: int = Field(..., description="Units per case pack", example=6)
    minimum_order_case_packs: int = Field(..., description="Minimum order case packs", example=2)
    lead_time_business_days: int = Field(..., description="Lead time in business days", example=10)
    availability_status: str = Field(..., description="Availability status", example="in_stock")
    price_tiers: List[SearchPriceTierModel] = Field(..., description="Price tiers", example=[])


class SearchProductsResponse(BaseModel):
    products: List[SearchProductModel] = Field(..., description="Search results", example=[])


class StoreLocationModel(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: int = Field(..., description="Store location id", example=30)
    retailer_id: int = Field(..., description="Retailer id", example=5)
    name: str = Field(..., description="Store name", example="CraftHub Downtown Flagship")
    address_line1: str = Field(..., description="Primary address line", example="125 Market St")
    address_line2: Optional[str] = Field(None, description="Secondary address line", example=None)
    city: Optional[str] = Field(None, description="City", example="Portland")
    state: Optional[str] = Field(None, description="State", example="OR")
    postal_code: Optional[str] = Field(None, description="Postal code", example="97205")
    country: Optional[str] = Field(None, description="Country", example="USA")
    shipping_contact_name: Optional[str] = Field(None, description="Shipping contact name", example="Jamie Lee")
    shipping_contact_phone: Optional[str] = Field(None, description="Shipping contact phone", example="+1-503-555-0192")
    is_default_destination: bool = Field(..., description="If this is default destination", example=True)
    created_at: Optional[datetime] = Field(None, description="Creation timestamp", example="2025-01-03T09:15:00Z")
    updated_at: Optional[datetime] = Field(None, description="Last update timestamp", example="2025-01-03T09:15:00Z")


class StoreLocationResponse(BaseModel):
    store_location: StoreLocationModel = Field(..., description="Store location", example={})


class CreateStoreLocationRequest(BaseModel):
    retailer_id: int = Field(..., description="Retailer company id for this store location", example=5)
    name: str = Field(..., description="Store location name", example="CraftHub Downtown Flagship")
    address_line1: str = Field(..., description="Primary address line", example="125 Market St")
    address_line2: Optional[str] = Field(None, description="Secondary address line", example="Suite 200")
    city: Optional[str] = Field(None, description="City name", example="Portland")
    state: Optional[str] = Field(None, description="State or province", example="OR")
    postal_code: Optional[str] = Field(None, description="Postal or ZIP code", example="97205")
    country: Optional[str] = Field(None, description="Country name or code", example="USA")
    shipping_contact_name: Optional[str] = Field(None, description="Default shipping contact name", example="Jamie Lee")
    shipping_contact_phone: Optional[str] = Field(None, description="Default shipping contact phone", example="+1-503-555-0192")
    is_default_destination: Optional[bool] = Field(False, description="Whether this is default destination for new POs", example=True)


class ListStoreLocationsResponse(BaseModel):
    store_locations: List[StoreLocationModel] = Field(..., description="Store locations", example=[])


class SetDefaultStoreLocationModel(BaseModel):
    id: int = Field(..., description="Store location id", example=30)
    retailer_id: int = Field(..., description="Retailer id", example=5)
    is_default_destination: bool = Field(..., description="Whether this store is default destination", example=True)
    updated_at: Optional[datetime] = Field(None, description="Timestamp when default flag was updated", example="2025-01-03T09:20:00Z")


class SetDefaultStoreLocationResponse(BaseModel):
    store_location: SetDefaultStoreLocationModel = Field(..., description="Updated store location", example={})


class WholesaleCartModel(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: int = Field(..., description="Wholesale cart id", example=400)
    retailer_id: int = Field(..., description="Retailer id", example=5)
    supplier_id: int = Field(..., description="Supplier id", example=20)
    store_location_id: int = Field(..., description="Store location id", example=30)
    status: str = Field(..., description="Cart status: open, converted, abandoned", example="open")
    created_at: Optional[datetime] = Field(None, description="Creation timestamp", example="2025-01-04T11:00:00Z")
    updated_at: Optional[datetime] = Field(None, description="Last update timestamp", example="2025-01-04T11:05:00Z")


class WholesaleCartResponse(BaseModel):
    cart: WholesaleCartModel = Field(..., description="Wholesale cart", example={})


class GetWholesaleCartResponse(BaseModel):
    cart: WholesaleCartModel = Field(..., description="Wholesale cart", example={})
    items: List["WholesaleCartItemModel"] = Field(..., description="Cart items", example=[])


class CreateWholesaleCartRequest(BaseModel):
    retailer_id: int = Field(..., description="Retailer company id", example=5)
    supplier_id: int = Field(..., description="Supplier company id", example=20)
    store_location_id: int = Field(..., description="Destination store_location id", example=30)


class WholesaleCartItemModel(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: int = Field(..., description="Cart item id", example=9001)
    cart_id: int = Field(..., description="Cart id", example=400)
    product_id: int = Field(..., description="Product id", example=205)
    quantity_case_packs: int = Field(..., description="Quantity in case packs", example=4)
    unit_price_snapshot: Optional[float] = Field(None, description="Unit price snapshot used at time of adding", example=4.5)
    created_at: Optional[datetime] = Field(None, description="Item creation timestamp", example="2025-01-04T11:02:00Z")
    updated_at: Optional[datetime] = Field(None, description="Item last update timestamp", example="2025-01-04T11:02:00Z")


GetWholesaleCartResponse.model_rebuild()


class WholesaleCartItemResponse(BaseModel):
    cart_item: WholesaleCartItemModel = Field(..., description="Wholesale cart item", example={})


class CreateWholesaleCartItemRequest(BaseModel):
    cart_id: int = Field(..., description="Wholesale cart id", example=400)
    product_id: int = Field(..., description="Product id being added", example=205)
    quantity_case_packs: int = Field(..., description="Quantity in case packs", example=4)
    unit_price_snapshot: Optional[float] = Field(None, description="Unit price snapshot for this line", example=4.5)


class UpdateWholesaleCartItemRequest(BaseModel):
    quantity_case_packs: Optional[int] = Field(None, description="New quantity in case packs", example=6)
    unit_price_snapshot: Optional[float] = Field(None, description="Updated unit price snapshot", example=4.4)


class PurchaseOrderModel(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: int = Field(..., description="Purchase order id", example=500)
    po_number: str = Field(..., description="PO number", example="PO-12001")
    retailer_id: int = Field(..., description="Retailer id", example=5)
    supplier_id: int = Field(..., description="Supplier id", example=20)
    buyer_user_id: Optional[int] = Field(None, description="Buyer user id (user_id=1)", example=1)
    store_location_id: int = Field(..., description="Primary store location id", example=30)
    status: str = Field(..., description="Order status", example="pending")
    requested_delivery_date: Optional[date] = Field(None, description="Requested delivery date", example="2026-02-15")
    shipping_preference: Optional[str] = Field(None, description="Shipping preference", example="ground")
    buyer_note: Optional[str] = Field(None, description="Buyer note", example="Buyer note")
    supplier_internal_note: Optional[str] = Field(None, description="Supplier internal note if set", example=None)
    estimated_ship_date: Optional[date] = Field(None, description="Estimated ship date if set", example=None)
    expected_delivery_date: Optional[date] = Field(None, description="Expected delivery date if set", example=None)
    created_at: Optional[datetime] = Field(None, description="Creation timestamp", example="2025-01-04T11:10:00Z")
    updated_at: Optional[datetime] = Field(None, description="Last update timestamp", example="2025-01-04T11:10:00Z")


class PurchaseOrderItemModel(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: int = Field(..., description="Purchase order item id", example=8001)
    purchase_order_id: int = Field(..., description="Purchase order id", example=500)
    product_id: int = Field(..., description="Product id", example=205)
    sku: str = Field(..., description="SKU snapshot", example="CANDLE-LAV-8OZ")
    title: str = Field(..., description="Product title snapshot", example="Lavender Soy Candle 8oz")
    case_pack_quantity: int = Field(..., description="Units per case pack snapshot", example=6)
    quantity_case_packs: int = Field(..., description="Ordered quantity in case packs", example=4)
    unit_price: float = Field(..., description="Unit price at time of order", example=4.5)
    created_at: Optional[datetime] = Field(None, description="Item creation timestamp", example="2025-01-04T11:10:00Z")
    updated_at: Optional[datetime] = Field(None, description="Item last update timestamp", example="2025-01-04T11:10:00Z")


class PurchaseOrderItemWithAllocationsModel(PurchaseOrderItemModel):
    allocations: List["PurchaseOrderItemAllocationModel"] = Field(..., description="Allocations for this item", example=[])


class PurchaseOrderItemAllocationModel(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: int = Field(..., description="Allocation id", example=90001)
    po_item_id: int = Field(..., description="PO item id", example=8101)
    store_location_id: int = Field(..., description="Store location id", example=30)
    quantity_case_packs: int = Field(..., description="Allocated case packs to this store", example=5)
    requested_delivery_date: Optional[date] = Field(None, description="Requested delivery date for this store", example="2026-03-01")
    created_at: Optional[datetime] = Field(None, description="Creation timestamp", example="2025-01-06T10:05:00Z")
    updated_at: Optional[datetime] = Field(None, description="Last update timestamp", example="2025-01-06T10:05:00Z")


PurchaseOrderItemWithAllocationsModel.model_rebuild()


class PurchaseOrderWithItemsResponse(BaseModel):
    purchase_order: PurchaseOrderModel = Field(..., description="Purchase order", example={})
    items: List[PurchaseOrderItemWithAllocationsModel] = Field(..., description="Items with allocations", example=[])


class PurchaseOrderSimpleResponse(BaseModel):
    purchase_order: PurchaseOrderModel = Field(..., description="Purchase order", example={})


class CreatePurchaseOrderFromCartRequest(BaseModel):
    cart_id: int = Field(..., description="Wholesale cart id to convert", example=400)
    po_number: str = Field(..., description="Client-provided PO number string", example="PO-12001")
    requested_delivery_date: Optional[str] = Field(None, description="Requested delivery date in YYYY-MM-DD", example="2026-02-15")
    shipping_preference: Optional[str] = Field(None, description="Shipping preference text", example="ground")
    buyer_note: Optional[str] = Field(None, description="Optional buyer note to supplier", example="Please label cartons.")


class CreatePurchaseOrderFromCartResponse(BaseModel):
    purchase_order: PurchaseOrderModel = Field(..., description="Created purchase order", example={})
    items: List[PurchaseOrderItemModel] = Field(..., description="Created purchase order items", example=[])


class GetPurchaseOrderByNumberResponse(BaseModel):
    purchase_order: Optional[PurchaseOrderModel] = Field(None, description="Purchase order if found", example={})


class UpdatePurchaseOrderRequest(BaseModel):
    status: Optional[str] = Field(None, description="New status", example="confirmed")
    estimated_ship_date: Optional[str] = Field(None, description="Estimated ship date YYYY-MM-DD", example="2026-01-10")
    expected_delivery_date: Optional[str] = Field(None, description="Expected delivery date YYYY-MM-DD", example="2026-01-15")
    supplier_internal_note: Optional[str] = Field(None, description="Internal note maintained by supplier", example="Internal note.")


class UpdatePurchaseOrderResponse(BaseModel):
    purchase_order: PurchaseOrderModel = Field(..., description="Updated purchase order", example={})


class ListPurchaseOrderItemsResponse(BaseModel):
    items: List[PurchaseOrderItemModel] = Field(..., description="PO items", example=[])


class ReorderFromPastPoRequest(BaseModel):
    source_po_id: int = Field(..., description="Existing purchase order id to copy from", example=500)
    new_po_number: str = Field(..., description="PO number for the new purchase order", example="PO-13001")
    requested_delivery_date: Optional[str] = Field(None, description="Requested delivery date for new PO", example="2026-03-01")


class ReorderFromPastPoResponse(BaseModel):
    purchase_order: PurchaseOrderModel = Field(..., description="New purchase order", example={})
    items: List[PurchaseOrderItemModel] = Field(..., description="New PO items", example=[])


class BulkAllocationItemRequest(BaseModel):
    po_item_id: int = Field(..., description="PO item id", example=8201)
    store_location_id: int = Field(..., description="Store location id", example=30)
    quantity_case_packs: int = Field(..., description="Allocated case packs", example=5)
    requested_delivery_date: Optional[str] = Field(None, description="Requested delivery date", example="2026-03-01")


class BulkCreateAllocationsRequest(BaseModel):
    allocations: List[BulkAllocationItemRequest] = Field(..., description="List of allocation objects to create", example=[])


class BulkCreateAllocationsResponse(BaseModel):
    allocations: List[PurchaseOrderItemAllocationModel] = Field(..., description="Created allocations", example=[])


class OrderRevisionModel(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: int = Field(..., description="Order revision id", example=10001)
    purchase_order_id: int = Field(..., description="Purchase order id", example=600)
    revision_number: int = Field(..., description="Sequential revision number for this PO", example=1)
    status: str = Field(..., description="Revision status", example="proposed")
    buyer_comment: Optional[str] = Field(None, description="Buyer comment for this revision", example="Comment")
    supplier_comment: Optional[str] = Field(None, description="Supplier comment if any", example=None)
    created_by_user_id: Optional[int] = Field(None, description="User id who created this revision", example=1)
    created_at: Optional[datetime] = Field(None, description="Creation timestamp", example="2025-01-07T09:00:00Z")
    updated_at: Optional[datetime] = Field(None, description="Last update timestamp", example="2025-01-07T09:00:00Z")


class OrderRevisionResponse(BaseModel):
    order_revision: OrderRevisionModel = Field(..., description="Order revision", example={})


class CreateOrderRevisionRequest(BaseModel):
    purchase_order_id: int = Field(..., description="PO id to revise", example=600)
    buyer_comment: Optional[str] = Field(None, description="Optional buyer comment explaining revision", example="Adjusting quantities.")


class OrderRevisionItemModel(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: int = Field(..., description="Order revision item id", example=11001)
    order_revision_id: int = Field(..., description="Order revision id", example=10001)
    po_item_id: int = Field(..., description="PO item id", example=8102)
    proposed_quantity_case_packs: int = Field(..., description="Proposed quantity in case packs", example=24)
    change_type: str = Field(..., description="Change type", example="quantity_update")
    created_at: Optional[datetime] = Field(None, description="Creation timestamp", example="2025-01-07T09:05:00Z")
    updated_at: Optional[datetime] = Field(None, description="Last update timestamp", example="2025-01-07T09:05:00Z")


class OrderRevisionItemResponse(BaseModel):
    order_revision_item: OrderRevisionItemModel = Field(..., description="Order revision item", example={})


class CreateOrderRevisionItemRequest(BaseModel):
    order_revision_id: int = Field(..., description="Order revision id", example=10001)
    po_item_id: int = Field(..., description="PO item id being revised", example=8102)
    proposed_quantity_case_packs: int = Field(..., description="Proposed quantity in case packs", example=24)
    change_type: str = Field(..., description="Type of change", example="quantity_update")


class ShipmentModel(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: int = Field(..., description="Shipment id", example=2001)
    purchase_order_id: int = Field(..., description="PO id", example=550)
    carrier: str = Field(..., description="Carrier name", example="UPS")
    tracking_number: str = Field(..., description="Tracking number", example="1Z999AA10123456784")
    ship_date: date = Field(..., description="Ship date", example="2026-01-11")
    expected_delivery_date: Optional[date] = Field(None, description="Expected delivery date", example="2026-01-15")
    created_at: Optional[datetime] = Field(None, description="Creation timestamp", example="2026-01-11T15:00:00Z")
    updated_at: Optional[datetime] = Field(None, description="Last update timestamp", example="2026-01-11T15:00:00Z")


class ShipmentResponse(BaseModel):
    shipment: ShipmentModel = Field(..., description="Shipment", example={})


class CreateShipmentRequest(BaseModel):
    purchase_order_id: int = Field(..., description="PO id this shipment belongs to", example=550)
    carrier: str = Field(..., description="Shipping carrier name", example="UPS")
    tracking_number: str = Field(..., description="Tracking number string", example="1Z999AA10123456784")
    ship_date: str = Field(..., description="Shipment ship date YYYY-MM-DD", example="2026-01-11")
    expected_delivery_date: Optional[str] = Field(None, description="Expected delivery date YYYY-MM-DD", example="2026-01-15")


class ShipmentItemModel(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: int = Field(..., description="Shipment item id", example=3001)
    shipment_id: int = Field(..., description="Shipment id", example=2001)
    po_item_id: int = Field(..., description="PO item id", example=8101)
    quantity_case_packs: int = Field(..., description="Shipped case packs", example=8)
    created_at: Optional[datetime] = Field(None, description="Creation timestamp", example="2026-01-11T15:05:00Z")
    updated_at: Optional[datetime] = Field(None, description="Last update timestamp", example="2026-01-11T15:05:00Z")


class ShipmentItemsResponse(BaseModel):
    shipment_items: List[ShipmentItemModel] = Field(..., description="Shipment items", example=[])


class ShipmentItemCreateRequest(BaseModel):
    po_item_id: int = Field(..., description="PO item id", example=8101)
    quantity_case_packs: int = Field(..., description="Shipped case packs", example=8)


class BulkCreateShipmentItemsRequest(BaseModel):
    shipment_id: int = Field(..., description="Shipment id to associate items with", example=2001)
    items: List[ShipmentItemCreateRequest] = Field(..., description="List of shipment item definitions", example=[])


class InvoiceModel(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: int = Field(..., description="Invoice id", example=90001)
    invoice_number: str = Field(..., description="Invoice number", example="INV-2025-1101")
    purchase_order_id: int = Field(..., description="Associated PO id", example=550)
    supplier_id: int = Field(..., description="Supplier id", example=20)
    retailer_id: int = Field(..., description="Retailer id", example=5)
    issue_date: date = Field(..., description="Invoice issue date", example="2025-11-15")
    due_date: date = Field(..., description="Invoice due date", example="2025-12-15")
    subtotal_amount: float = Field(..., description="Invoice subtotal amount", example=2500.0)
    tax_amount: float = Field(..., description="Tax amount", example=200.0)
    shipping_amount: float = Field(..., description="Shipping amount", example=150.0)
    total_amount: float = Field(..., description="Total invoice amount", example=2850.0)
    payment_terms: Optional[str] = Field(None, description="Payment terms text", example="Net 30")
    status: str = Field(..., description="Invoice status", example="paid")
    created_at: Optional[datetime] = Field(None, description="Creation timestamp", example="2025-11-15T10:00:00Z")
    updated_at: Optional[datetime] = Field(None, description="Last update timestamp", example="2025-12-10T09:00:00Z")


class ListInvoicesResponse(BaseModel):
    invoices: List[InvoiceModel] = Field(..., description="Invoices", example=[])


class InvoicePaymentModel(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: int = Field(..., description="Payment id", example=91001)
    invoice_id: int = Field(..., description="Invoice id", example=90001)
    payment_date: date = Field(..., description="Payment date", example="2025-12-05")
    amount: float = Field(..., description="Payment amount", example=2850.0)
    payment_method: Optional[str] = Field(None, description="Payment method description", example="ACH")
    reference: Optional[str] = Field(None, description="Payment reference", example="ACH-REF-12345")
    created_at: Optional[datetime] = Field(None, description="Creation timestamp", example="2025-12-05T11:00:00Z")
    updated_at: Optional[datetime] = Field(None, description="Last update timestamp", example="2025-12-05T11:00:00Z")


class ListInvoicePaymentsResponse(BaseModel):
    payments: List[InvoicePaymentModel] = Field(..., description="Payments for invoice", example=[])


class AccountingPurchaseOrderExportModel(BaseModel):
    po_id: int = Field(..., description="Purchase order id", example=550)
    po_number: str = Field(..., description="Purchase order number", example="PO-10457")
    store_location_id: int = Field(..., description="Primary store location id", example=30)
    store_location_name: Optional[str] = Field(None, description="Store location name", example="CraftHub Downtown Flagship")
    status: str = Field(..., description="PO status", example="shipped")
    requested_delivery_date: Optional[date] = Field(None, description="Requested delivery date", example="2025-11-20")


class AccountingInvoiceExportModel(BaseModel):
    invoice_id: int = Field(..., description="Invoice id", example=90001)
    invoice_number: str = Field(..., description="Invoice number", example="INV-2025-1101")
    purchase_order_id: int = Field(..., description="Associated PO id", example=550)
    issue_date: date = Field(..., description="Issue date", example="2025-11-15")
    due_date: date = Field(..., description="Due date", example="2025-12-15")
    total_amount: float = Field(..., description="Total invoice amount", example=2850.0)
    payment_terms: Optional[str] = Field(None, description="Payment terms", example="Net 30")
    status: str = Field(..., description="Invoice status", example="paid")
    total_paid_amount: float = Field(..., description="Sum of payments applied to this invoice", example=2850.0)


class AccountingAggregatesModel(BaseModel):
    total_invoice_amount: float = Field(..., description="Sum of total_amount for all invoices in period", example=15250.0)
    total_paid_amount: float = Field(..., description="Sum of all payments in period", example=14000.0)
    invoice_count: int = Field(..., description="Number of invoices in period", example=6)


class AccountingExportResponse(BaseModel):
    supplier_id: int = Field(..., description="Supplier id used for export", example=20)
    retailer_id: Optional[int] = Field(None, description="Retailer id if filtered", example=5)
    period_start: date = Field(..., description="Start date of reporting period", example="2025-10-01")
    period_end: date = Field(..., description="End date of reporting period", example="2025-12-31")
    purchase_orders: List[AccountingPurchaseOrderExportModel] = Field(..., description="Purchase orders", example=[])
    invoices: List[AccountingInvoiceExportModel] = Field(..., description="Invoices", example=[])
    aggregates: AccountingAggregatesModel = Field(..., description="Aggregated totals", example={})


@app.get(
    "/api/categories",
    response_model=ListCategoriesResponse,
    summary="List categories with optional filters",
    description="Retrieve categories filtered by name or parent_id",
    tags=["categories"],
    operation_id="list_categories",
)
async def list_categories(
    name: Optional[str] = Query(None, description="Filter by exact category name", example="Drinkware"),
    parent_id: Optional[int] = Query(None, description="Filter by parent category id", example=1),
) -> ListCategoriesResponse:
    session = SessionLocal()
    query = session.query(Category)
    if name is not None:
        query = query.filter(Category.name == name)
    if parent_id is not None:
        query = query.filter(Category.parent_id == parent_id)
    categories = query.all()
    session.close()
    return ListCategoriesResponse(categories=[CategoryModel.model_validate(c) for c in categories])


@app.get(
    "/api/companies",
    response_model=ListCompaniesResponse,
    summary="List companies with optional filters",
    description="Retrieve companies filtered by name or company_type",
    tags=["companies"],
    operation_id="list_companies",
)
async def list_companies(
    name: Optional[str] = Query(None, description="Filter by company name (exact match)", example="Everglow Candles"),
    company_type: Optional[str] = Query(None, description="Filter by company_type 'supplier' or 'retailer'", example="supplier"),
) -> ListCompaniesResponse:
    session = SessionLocal()
    query = session.query(Company)
    if name is not None:
        query = query.filter(Company.name == name)
    if company_type is not None:
        query = query.filter(Company.company_type == company_type)
    companies = query.all()
    session.close()
    return ListCompaniesResponse(companies=[CompanyModel.model_validate(c) for c in companies])


@app.get(
    "/api/companies/me",
    response_model=MyCompaniesResponse,
    summary="Get companies linked to current user",
    description="Return companies associated with user_id=1 via user_companies",
    tags=["companies", "users"],
    operation_id="get_my_companies",
)
async def get_my_companies() -> MyCompaniesResponse:
    session = SessionLocal()
    user_id = 1
    links = session.query(UserCompany, Company).join(Company, UserCompany.company_id == Company.id).filter(UserCompany.user_id == user_id).all()
    companies: List[MyCompanyModel] = []
    for link, company in links:
        companies.append(
            MyCompanyModel(
                company_id=company.id,
                name=company.name,
                company_type=company.company_type,
                user_role=link.role,
            )
        )
    session.close()
    return MyCompaniesResponse(companies=companies)


@app.post(
    "/api/products",
    response_model=ProductResponse,
    summary="Create a new product for current supplier",
    description="Create a product row for a supplier company linked to user_id=1",
    tags=["products"],
    operation_id="create_product",
)
async def create_product(payload: CreateProductRequest = Body(..., description="Product creation payload")) -> ProductResponse:
    session = SessionLocal()
    now = datetime.utcnow()
    product = Product(
        supplier_id=payload.supplier_id,
        sku=payload.sku,
        title=payload.title,
        category_id=payload.category_id,
        case_pack_quantity=payload.case_pack_quantity,
        minimum_order_case_packs=payload.minimum_order_case_packs,
        lead_time_business_days=payload.lead_time_business_days,
        availability_status=payload.availability_status,
        created_at=now,
        updated_at=now,
    )
    session.add(product)
    session.commit()
    session.refresh(product)
    session.close()
    return ProductResponse(product=ProductModel.model_validate(product))


@app.patch(
    "/api/products/{product_id}",
    response_model=ProductResponse,
    summary="Update mutable fields of a product",
    description="Partially update fields for an existing product",
    tags=["products"],
    operation_id="update_product",
)
async def update_product(
    product_id: int = Path(..., description="Id of product to update", example=102),
    payload: UpdateProductRequest = Body(..., description="Product update payload"),
) -> ProductResponse:
    session = SessionLocal()
    product = session.query(Product).filter(Product.id == product_id).first()
    if product is not None:
        if payload.title is not None:
            product.title = payload.title
        if payload.category_id is not None:
            product.category_id = payload.category_id
        if payload.case_pack_quantity is not None:
            product.case_pack_quantity = payload.case_pack_quantity
        if payload.minimum_order_case_packs is not None:
            product.minimum_order_case_packs = payload.minimum_order_case_packs
        if payload.lead_time_business_days is not None:
            product.lead_time_business_days = payload.lead_time_business_days
        if payload.availability_status is not None:
            product.availability_status = payload.availability_status
        product.updated_at = datetime.utcnow()
        session.commit()
        session.refresh(product)
    session.close()
    return ProductResponse(product=ProductModel.model_validate(product) if product is not None else ProductModel.model_validate(Product(id=0, supplier_id=0, sku="", title="", category_id=0, case_pack_quantity=1, minimum_order_case_packs=1, lead_time_business_days=0, availability_status="unavailable", created_at=datetime.utcnow(), updated_at=datetime.utcnow())))


@app.get(
    "/api/products/by-sku",
    response_model=GetProductBySkuResponse,
    summary="Get a supplier product by SKU",
    description="Resolve a single product row for a given supplier_id and SKU",
    tags=["products"],
    operation_id="get_product_by_sku",
)
async def get_product_by_sku(
    supplier_id: int = Query(..., description="Supplier company id", example=20),
    sku: str = Query(..., description="Product SKU", example="LINEN-NAPKIN-SET4"),
) -> GetProductBySkuResponse:
    session = SessionLocal()
    product = session.query(Product).filter(Product.supplier_id == supplier_id, Product.sku == sku).first()
    session.close()
    if product is None:
        return GetProductBySkuResponse(product=None)
    return GetProductBySkuResponse(product=ProductModel.model_validate(product))


@app.get(
    "/api/products/search",
    response_model=SearchProductsResponse,
    summary="Search supplier products with filters",
    description="Search products across suppliers by category, price tier range, and lead time",
    tags=["products", "search"],
    operation_id="search_products",
)
async def search_products(
    category_name: Optional[str] = Query(None, description="Exact category name to filter products", example="Home Fragrance"),
    supplier_id: Optional[int] = Query(None, description="Optional supplier id to limit results", example=20),
    min_unit_price: Optional[float] = Query(None, description="Minimum unit price across any tier", example=3.0),
    max_unit_price: Optional[float] = Query(None, description="Maximum unit price across any tier", example=8.0),
    max_lead_time_business_days: Optional[int] = Query(None, description="Maximum allowed lead time in business days", example=14),
    limit: Optional[int] = Query(50, description="Max number of products to return", example=50),
    offset: Optional[int] = Query(0, description="Offset for pagination", example=0),
) -> SearchProductsResponse:
    session = SessionLocal()
    query = session.query(Product, Company, Category).join(Company, Product.supplier_id == Company.id).join(Category, Product.category_id == Category.id)
    if category_name is not None:
        query = query.filter(Category.name == category_name)
    if supplier_id is not None:
        query = query.filter(Product.supplier_id == supplier_id)
    if max_lead_time_business_days is not None:
        query = query.filter(Product.lead_time_business_days <= max_lead_time_business_days)
    products_raw = query.offset(offset if offset is not None else 0).limit(limit if limit is not None else 50).all()
    results: List[SearchProductModel] = []
    for product, supplier, category in products_raw:
        tier_query = session.query(ProductPriceTier).filter(ProductPriceTier.product_id == product.id)
        if min_unit_price is not None:
            tier_query = tier_query.filter(ProductPriceTier.unit_price >= min_unit_price)
        if max_unit_price is not None:
            tier_query = tier_query.filter(ProductPriceTier.unit_price <= max_unit_price)
        tiers = tier_query.all()
        if min_unit_price is not None or max_unit_price is not None:
            if len(tiers) == 0:
                continue
        tiers_models: List[SearchPriceTierModel] = []
        for t in tiers:
            tiers_models.append(
                SearchPriceTierModel(
                    id=t.id,
                    min_case_packs=t.min_case_packs,
                    max_case_packs=t.max_case_packs,
                    unit_price=t.unit_price,
                )
            )
        results.append(
            SearchProductModel(
                product_id=product.id,
                supplier_id=supplier.id,
                supplier_name=supplier.name,
                sku=product.sku,
                title=product.title,
                category_id=category.id,
                category_name=category.name,
                case_pack_quantity=product.case_pack_quantity,
                minimum_order_case_packs=product.minimum_order_case_packs,
                lead_time_business_days=product.lead_time_business_days,
                availability_status=product.availability_status,
                price_tiers=tiers_models,
            )
        )
    session.close()
    return SearchProductsResponse(products=results)


@app.get(
    "/api/products/{product_id}/price-tiers",
    response_model=ListPriceTiersResponse,
    summary="List price tiers for a product",
    description="Retrieve all product_price_tiers rows for a product",
    tags=["products", "pricing"],
    operation_id="list_product_price_tiers",
)
async def list_product_price_tiers(
    product_id: int = Path(..., description="Product id", example=101),
) -> ListPriceTiersResponse:
    session = SessionLocal()
    tiers = session.query(ProductPriceTier).filter(ProductPriceTier.product_id == product_id).all()
    session.close()
    return ListPriceTiersResponse(price_tiers=[PriceTierModel.model_validate(t) for t in tiers])


@app.post(
    "/api/products/{product_id}/price-tiers",
    response_model=PriceTierResponse,
    summary="Create a new price tier for a product",
    description="Add a product_price_tiers row for a product",
    tags=["products", "pricing"],
    operation_id="create_product_price_tier",
)
async def create_product_price_tier(
    product_id: int = Path(..., description="Product id to associate the price tier with", example=101),
    payload: CreatePriceTierRequest = Body(..., description="Price tier creation payload"),
) -> PriceTierResponse:
    session = SessionLocal()
    now = datetime.utcnow()
    tier = ProductPriceTier(
        product_id=product_id,
        min_case_packs=payload.min_case_packs,
        max_case_packs=payload.max_case_packs,
        unit_price=payload.unit_price,
        created_at=now,
        updated_at=now,
    )
    session.add(tier)
    session.commit()
    session.refresh(tier)
    session.close()
    return PriceTierResponse(price_tier=PriceTierModel.model_validate(tier))


@app.delete(
    "/api/products/{product_id}/price-tiers",
    response_model=DeletePriceTiersResponse,
    summary="Delete all price tiers for a product",
    description="Remove all product_price_tiers for a product",
    tags=["products", "pricing"],
    operation_id="delete_all_product_price_tiers",
)
async def delete_all_product_price_tiers(
    product_id: int = Path(..., description="Product id whose price tiers will be removed", example=102),
) -> DeletePriceTiersResponse:
    session = SessionLocal()
    tiers = session.query(ProductPriceTier).filter(ProductPriceTier.product_id == product_id).all()
    count = len(tiers)
    for t in tiers:
        session.delete(t)
    session.commit()
    session.close()
    return DeletePriceTiersResponse(deleted_count=count)


@app.post(
    "/api/store-locations",
    response_model=StoreLocationResponse,
    summary="Create a new store location for retailer",
    description="Create a store_locations row for a retailer company linked to user_id=1",
    tags=["store_locations"],
    operation_id="create_store_location",
)
async def create_store_location(
    payload: CreateStoreLocationRequest = Body(..., description="Store location creation payload"),
) -> StoreLocationResponse:
    session = SessionLocal()
    now = datetime.utcnow()
    is_default_flag = 1 if payload.is_default_destination else 0
    if is_default_flag == 1:
        existing = session.query(StoreLocation).filter(StoreLocation.retailer_id == payload.retailer_id, StoreLocation.is_default_destination == 1).all()
        for loc in existing:
            loc.is_default_destination = 0
            loc.updated_at = now
    store_location = StoreLocation(
        retailer_id=payload.retailer_id,
        name=payload.name,
        address_line1=payload.address_line1,
        address_line2=payload.address_line2,
        city=payload.city,
        state=payload.state,
        postal_code=payload.postal_code,
        country=payload.country,
        shipping_contact_name=payload.shipping_contact_name,
        shipping_contact_phone=payload.shipping_contact_phone,
        is_default_destination=is_default_flag,
        created_at=now,
        updated_at=now,
    )
    session.add(store_location)
    session.commit()
    session.refresh(store_location)
    session.close()
    model = StoreLocationModel.model_validate(store_location)
    model.is_default_destination = bool(store_location.is_default_destination)
    return StoreLocationResponse(store_location=model)


@app.get(
    "/api/store-locations",
    response_model=ListStoreLocationsResponse,
    summary="List store locations for a retailer",
    description="Retrieve store_locations for a retailer associated with user_id=1",
    tags=["store_locations"],
    operation_id="list_store_locations",
)
async def list_store_locations(
    retailer_id: int = Query(..., description="Retailer company id", example=5),
    only_default: Optional[bool] = Query(False, description="If true, return only default destination store", example=False),
) -> ListStoreLocationsResponse:
    session = SessionLocal()
    query = session.query(StoreLocation).filter(StoreLocation.retailer_id == retailer_id)
    if only_default:
        query = query.filter(StoreLocation.is_default_destination == 1)
    store_locations = query.all()
    models: List[StoreLocationModel] = []
    for loc in store_locations:
        m = StoreLocationModel.model_validate(loc)
        m.is_default_destination = bool(loc.is_default_destination)
        models.append(m)
    session.close()
    return ListStoreLocationsResponse(store_locations=models)


@app.post(
    "/api/store-locations/{store_location_id}/set-default",
    response_model=SetDefaultStoreLocationResponse,
    summary="Set a store location as default destination",
    description="Mark is_default_destination=1 for this store and clear flag on others for same retailer",
    tags=["store_locations"],
    operation_id="set_store_location_default",
)
async def set_store_location_default(
    store_location_id: int = Path(..., description="Store location id to set as default", example=30),
) -> SetDefaultStoreLocationResponse:
    session = SessionLocal()
    store_location = session.query(StoreLocation).filter(StoreLocation.id == store_location_id).first()
    if store_location is not None:
        retailer_id = store_location.retailer_id
        others = session.query(StoreLocation).filter(StoreLocation.retailer_id == retailer_id, StoreLocation.id != store_location_id).all()
        now = datetime.utcnow()
        for loc in others:
            loc.is_default_destination = 0
            loc.updated_at = now
        store_location.is_default_destination = 1
        store_location.updated_at = now
        session.commit()
        session.refresh(store_location)
        model = SetDefaultStoreLocationModel(
            id=store_location.id,
            retailer_id=store_location.retailer_id,
            is_default_destination=bool(store_location.is_default_destination),
            updated_at=store_location.updated_at,
        )
        session.close()
        return SetDefaultStoreLocationResponse(store_location=model)
    session.close()
    return SetDefaultStoreLocationResponse(
        store_location=SetDefaultStoreLocationModel(id=0, retailer_id=0, is_default_destination=False, updated_at=datetime.utcnow())
    )


@app.post(
    "/api/wholesale-carts",
    response_model=WholesaleCartResponse,
    summary="Create or reuse open wholesale cart",
    description="Get or create an open wholesale_carts row",
    tags=["carts"],
    operation_id="get_or_create_wholesale_cart",
)
async def get_or_create_wholesale_cart(
    payload: CreateWholesaleCartRequest = Body(..., description="Wholesale cart creation payload"),
) -> WholesaleCartResponse:
    session = SessionLocal()
    cart = (
        session.query(WholesaleCart)
        .filter(
            WholesaleCart.retailer_id == payload.retailer_id,
            WholesaleCart.supplier_id == payload.supplier_id,
            WholesaleCart.store_location_id == payload.store_location_id,
            WholesaleCart.status == "open",
        )
        .first()
    )
    now = datetime.utcnow()
    if cart is None:
        cart = WholesaleCart(
            retailer_id=payload.retailer_id,
            supplier_id=payload.supplier_id,
            store_location_id=payload.store_location_id,
            status="open",
            created_at=now,
            updated_at=now,
        )
        session.add(cart)
        session.commit()
        session.refresh(cart)
    session.close()
    return WholesaleCartResponse(cart=WholesaleCartModel.model_validate(cart))


@app.get(
    "/api/wholesale-carts/{cart_id}",
    response_model=GetWholesaleCartResponse,
    summary="Get a wholesale cart with items",
    description="Retrieve a wholesale_carts row and its wholesale_cart_items",
    tags=["carts"],
    operation_id="get_wholesale_cart",
)
async def get_wholesale_cart(
    cart_id: int = Path(..., description="Wholesale cart id", example=400),
) -> GetWholesaleCartResponse:
    session = SessionLocal()
    cart = session.query(WholesaleCart).filter(WholesaleCart.id == cart_id).first()
    items = session.query(WholesaleCartItem).filter(WholesaleCartItem.cart_id == cart_id).all()
    session.close()
    cart_model = WholesaleCartModel.model_validate(cart) if cart is not None else WholesaleCartModel.model_validate(
        WholesaleCart(id=0, retailer_id=0, supplier_id=0, store_location_id=0, status="open", created_at=datetime.utcnow(), updated_at=datetime.utcnow())
    )
    items_models = [WholesaleCartItemModel.model_validate(i) for i in items]
    return GetWholesaleCartResponse(cart=cart_model, items=items_models)


@app.post(
    "/api/wholesale-cart-items",
    response_model=WholesaleCartItemResponse,
    summary="Add an item to a wholesale cart",
    description="Create a wholesale_cart_items row for a cart",
    tags=["carts"],
    operation_id="add_cart_item",
)
async def add_cart_item(
    payload: CreateWholesaleCartItemRequest = Body(..., description="Cart item creation payload"),
) -> WholesaleCartItemResponse:
    session = SessionLocal()
    now = datetime.utcnow()
    item = WholesaleCartItem(
        cart_id=payload.cart_id,
        product_id=payload.product_id,
        quantity_case_packs=payload.quantity_case_packs,
        unit_price_snapshot=payload.unit_price_snapshot,
        created_at=now,
        updated_at=now,
    )
    session.add(item)
    session.commit()
    session.refresh(item)
    session.close()
    return WholesaleCartItemResponse(cart_item=WholesaleCartItemModel.model_validate(item))


@app.patch(
    "/api/wholesale-cart-items/{cart_item_id}",
    response_model=WholesaleCartItemResponse,
    summary="Update quantity of a cart item",
    description="Update quantity_case_packs or unit_price_snapshot for a cart item",
    tags=["carts"],
    operation_id="update_cart_item",
)
async def update_cart_item(
    cart_item_id: int = Path(..., description="Cart item id", example=9001),
    payload: UpdateWholesaleCartItemRequest = Body(..., description="Cart item update payload"),
) -> WholesaleCartItemResponse:
    session = SessionLocal()
    item = session.query(WholesaleCartItem).filter(WholesaleCartItem.id == cart_item_id).first()
    if item is not None:
        if payload.quantity_case_packs is not None:
            item.quantity_case_packs = payload.quantity_case_packs
        if payload.unit_price_snapshot is not None:
            item.unit_price_snapshot = payload.unit_price_snapshot
        item.updated_at = datetime.utcnow()
        session.commit()
        session.refresh(item)
    session.close()
    return WholesaleCartItemResponse(
        cart_item=WholesaleCartItemModel.model_validate(item)
        if item is not None
        else WholesaleCartItemModel.model_validate(
            WholesaleCartItem(
                id=0,
                cart_id=0,
                product_id=0,
                quantity_case_packs=1,
                unit_price_snapshot=None,
                created_at=datetime.utcnow(),
                updated_at=datetime.utcnow(),
            )
        )
    )


@app.post(
    "/api/purchase-orders",
    response_model=CreatePurchaseOrderFromCartResponse,
    summary="Create purchase order from cart",
    description="Create purchase_orders and purchase_order_items from a wholesale cart",
    tags=["purchase_orders"],
    operation_id="create_purchase_order_from_cart",
)
async def create_purchase_order_from_cart(
    payload: CreatePurchaseOrderFromCartRequest = Body(..., description="Create PO from cart payload"),
) -> CreatePurchaseOrderFromCartResponse:
    session = SessionLocal()
    cart = session.query(WholesaleCart).filter(WholesaleCart.id == payload.cart_id).first()
    cart_items = session.query(WholesaleCartItem).filter(WholesaleCartItem.cart_id == payload.cart_id).all()
    if cart is None:
        session.close()
        now = datetime.utcnow()
        po_placeholder = PurchaseOrder(
            id=0,
            po_number=payload.po_number,
            retailer_id=0,
            supplier_id=0,
            buyer_user_id=1,
            store_location_id=0,
            status="pending",
            requested_delivery_date=None,
            shipping_preference=payload.shipping_preference,
            buyer_note=payload.buyer_note,
            supplier_internal_note=None,
            estimated_ship_date=None,
            expected_delivery_date=None,
            created_at=now,
            updated_at=now,
        )
        return CreatePurchaseOrderFromCartResponse(
            purchase_order=PurchaseOrderModel.model_validate(po_placeholder),
            items=[],
        )
    now = datetime.utcnow()
    requested_date_value = None
    if payload.requested_delivery_date is not None and payload.requested_delivery_date != "":
        requested_date_value = date.fromisoformat(payload.requested_delivery_date)
    purchase_order = PurchaseOrder(
        po_number=payload.po_number,
        retailer_id=cart.retailer_id,
        supplier_id=cart.supplier_id,
        buyer_user_id=1,
        store_location_id=cart.store_location_id,
        status="pending",
        requested_delivery_date=requested_date_value,
        shipping_preference=payload.shipping_preference,
        buyer_note=payload.buyer_note,
        supplier_internal_note=None,
        estimated_ship_date=None,
        expected_delivery_date=None,
        created_at=now,
        updated_at=now,
    )
    session.add(purchase_order)
    cart.status = "converted"
    cart.updated_at = now
    session.commit()
    session.refresh(purchase_order)
    items_models: List[PurchaseOrderItemModel] = []
    for ci in cart_items:
        product = session.query(Product).filter(Product.id == ci.product_id).first()
        if product is None:
            continue
        po_item = PurchaseOrderItem(
            purchase_order_id=purchase_order.id,
            product_id=product.id,
            sku=product.sku,
            title=product.title,
            case_pack_quantity=product.case_pack_quantity,
            quantity_case_packs=ci.quantity_case_packs,
            unit_price=ci.unit_price_snapshot if ci.unit_price_snapshot is not None else 0.0,
            created_at=now,
            updated_at=now,
        )
        session.add(po_item)
        session.commit()
        session.refresh(po_item)
        items_models.append(PurchaseOrderItemModel.model_validate(po_item))
    session.close()
    return CreatePurchaseOrderFromCartResponse(
        purchase_order=PurchaseOrderModel.model_validate(purchase_order),
        items=items_models,
    )


@app.get(
    "/api/purchase-orders/{po_id}",
    response_model=PurchaseOrderWithItemsResponse,
    summary="Get purchase order with items and allocations",
    description="Retrieve a purchase_orders row with its items and allocations",
    tags=["purchase_orders"],
    operation_id="get_purchase_order",
)
async def get_purchase_order(
    po_id: int = Path(..., description="Purchase order id", example=500),
) -> PurchaseOrderWithItemsResponse:
    session = SessionLocal()
    purchase_order = session.query(PurchaseOrder).filter(PurchaseOrder.id == po_id).first()
    items = session.query(PurchaseOrderItem).filter(PurchaseOrderItem.purchase_order_id == po_id).all()
    items_with_allocs: List[PurchaseOrderItemWithAllocationsModel] = []
    for item in items:
        allocs = session.query(PurchaseOrderItemAllocation).filter(PurchaseOrderItemAllocation.po_item_id == item.id).all()
        alloc_models = [PurchaseOrderItemAllocationModel.model_validate(a) for a in allocs]
        item_model = PurchaseOrderItemWithAllocationsModel(
            id=item.id,
            purchase_order_id=item.purchase_order_id,
            product_id=item.product_id,
            sku=item.sku,
            title=item.title,
            case_pack_quantity=item.case_pack_quantity,
            quantity_case_packs=item.quantity_case_packs,
            unit_price=item.unit_price,
            created_at=item.created_at,
            updated_at=item.updated_at,
            allocations=alloc_models,
        )
        items_with_allocs.append(item_model)
    session.close()
    if purchase_order is None:
        now = datetime.utcnow()
        po_placeholder = PurchaseOrder(
            id=0,
            po_number="",
            retailer_id=0,
            supplier_id=0,
            buyer_user_id=1,
            store_location_id=0,
            status="pending",
            requested_delivery_date=None,
            shipping_preference=None,
            buyer_note=None,
            supplier_internal_note=None,
            estimated_ship_date=None,
            expected_delivery_date=None,
            created_at=now,
            updated_at=now,
        )
        return PurchaseOrderWithItemsResponse(
            purchase_order=PurchaseOrderModel.model_validate(po_placeholder),
            items=[],
        )
    return PurchaseOrderWithItemsResponse(
        purchase_order=PurchaseOrderModel.model_validate(purchase_order),
        items=items_with_allocs,
    )


@app.get(
    "/api/purchase-orders/by-number/{po_number}",
    response_model=GetPurchaseOrderByNumberResponse,
    summary="Get purchase order by PO number",
    description="Resolve a purchase_orders row from po_number",
    tags=["purchase_orders"],
    operation_id="get_purchase_order_by_number",
)
async def get_purchase_order_by_number(
    po_number: str = Path(..., description="PO number string", example="PO-10457"),
) -> GetPurchaseOrderByNumberResponse:
    session = SessionLocal()
    purchase_order = session.query(PurchaseOrder).filter(PurchaseOrder.po_number == po_number).first()
    session.close()
    if purchase_order is None:
        return GetPurchaseOrderByNumberResponse(purchase_order=None)
    return GetPurchaseOrderByNumberResponse(purchase_order=PurchaseOrderModel.model_validate(purchase_order))


@app.patch(
    "/api/purchase-orders/{po_id}",
    response_model=UpdatePurchaseOrderResponse,
    summary="Update high-level purchase order fields",
    description="Update status, estimated_ship_date, expected_delivery_date, or supplier_internal_note",
    tags=["purchase_orders"],
    operation_id="update_purchase_order",
)
async def update_purchase_order(
    po_id: int = Path(..., description="PO id to update", example=550),
    payload: UpdatePurchaseOrderRequest = Body(..., description="Purchase order update payload"),
) -> UpdatePurchaseOrderResponse:
    session = SessionLocal()
    purchase_order = session.query(PurchaseOrder).filter(PurchaseOrder.id == po_id).first()
    if purchase_order is not None:
        if payload.status is not None:
            purchase_order.status = payload.status
        if payload.estimated_ship_date is not None and payload.estimated_ship_date != "":
            purchase_order.estimated_ship_date = date.fromisoformat(payload.estimated_ship_date)
        if payload.expected_delivery_date is not None and payload.expected_delivery_date != "":
            purchase_order.expected_delivery_date = date.fromisoformat(payload.expected_delivery_date)
        if payload.supplier_internal_note is not None:
            purchase_order.supplier_internal_note = payload.supplier_internal_note
        purchase_order.updated_at = datetime.utcnow()
        session.commit()
        session.refresh(purchase_order)
    session.close()
    if purchase_order is None:
        now = datetime.utcnow()
        po_placeholder = PurchaseOrder(
            id=0,
            po_number="",
            retailer_id=0,
            supplier_id=0,
            buyer_user_id=1,
            store_location_id=0,
            status="pending",
            requested_delivery_date=None,
            shipping_preference=None,
            buyer_note=None,
            supplier_internal_note=None,
            estimated_ship_date=None,
            expected_delivery_date=None,
            created_at=now,
            updated_at=now,
        )
        return UpdatePurchaseOrderResponse(purchase_order=PurchaseOrderModel.model_validate(po_placeholder))
    return UpdatePurchaseOrderResponse(purchase_order=PurchaseOrderModel.model_validate(purchase_order))


@app.get(
    "/api/purchase-orders/{po_id}/items",
    response_model=ListPurchaseOrderItemsResponse,
    summary="List items for a purchase order",
    description="Retrieve purchase_order_items for a purchase order",
    tags=["purchase_orders"],
    operation_id="list_purchase_order_items",
)
async def list_purchase_order_items(
    po_id: int = Path(..., description="Purchase order id", example=500),
) -> ListPurchaseOrderItemsResponse:
    session = SessionLocal()
    items = session.query(PurchaseOrderItem).filter(PurchaseOrderItem.purchase_order_id == po_id).all()
    session.close()
    return ListPurchaseOrderItemsResponse(items=[PurchaseOrderItemModel.model_validate(i) for i in items])


@app.post(
    "/api/purchase-orders/reorder",
    response_model=ReorderFromPastPoResponse,
    summary="Create new PO by copying items from a past PO",
    description="Create a new purchase_order copying items from an existing PO",
    tags=["purchase_orders"],
    operation_id="reorder_from_past_po",
)
async def reorder_from_past_po(
    payload: ReorderFromPastPoRequest = Body(..., description="Reorder from past PO payload"),
) -> ReorderFromPastPoResponse:
    session = SessionLocal()
    source_po = session.query(PurchaseOrder).filter(PurchaseOrder.id == payload.source_po_id).first()
    items_models: List[PurchaseOrderItemModel] = []
    if source_po is None:
        now = datetime.utcnow()
        po_placeholder = PurchaseOrder(
            id=0,
            po_number=payload.new_po_number,
            retailer_id=0,
            supplier_id=0,
            buyer_user_id=1,
            store_location_id=0,
            status="pending",
            requested_delivery_date=None,
            shipping_preference=None,
            buyer_note=None,
            supplier_internal_note=None,
            estimated_ship_date=None,
            expected_delivery_date=None,
            created_at=now,
            updated_at=now,
        )
        session.close()
        return ReorderFromPastPoResponse(purchase_order=PurchaseOrderModel.model_validate(po_placeholder), items=items_models)
    now = datetime.utcnow()
    requested_date_value = None
    if payload.requested_delivery_date is not None and payload.requested_delivery_date != "":
        requested_date_value = date.fromisoformat(payload.requested_delivery_date)
    new_po = PurchaseOrder(
        po_number=payload.new_po_number,
        retailer_id=source_po.retailer_id,
        supplier_id=source_po.supplier_id,
        buyer_user_id=source_po.buyer_user_id,
        store_location_id=source_po.store_location_id,
        status="pending",
        requested_delivery_date=requested_date_value,
        shipping_preference=source_po.shipping_preference,
        buyer_note=source_po.buyer_note,
        supplier_internal_note=None,
        estimated_ship_date=None,
        expected_delivery_date=None,
        created_at=now,
        updated_at=now,
    )
    session.add(new_po)
    session.commit()
    session.refresh(new_po)
    source_items = session.query(PurchaseOrderItem).filter(PurchaseOrderItem.purchase_order_id == source_po.id).all()
    for src in source_items:
        new_item = PurchaseOrderItem(
            purchase_order_id=new_po.id,
            product_id=src.product_id,
            sku=src.sku,
            title=src.title,
            case_pack_quantity=src.case_pack_quantity,
            quantity_case_packs=src.quantity_case_packs,
            unit_price=src.unit_price,
            created_at=now,
            updated_at=now,
        )
        session.add(new_item)
        session.commit()
        session.refresh(new_item)
        items_models.append(PurchaseOrderItemModel.model_validate(new_item))
    session.close()
    return ReorderFromPastPoResponse(purchase_order=PurchaseOrderModel.model_validate(new_po), items=items_models)


@app.post(
    "/api/purchase-order-item-allocations/bulk",
    response_model=BulkCreateAllocationsResponse,
    summary="Bulk create allocations for PO items",
    description="Create purchase_order_item_allocations rows for multiple PO items",
    tags=["purchase_orders", "allocations"],
    operation_id="bulk_create_po_item_allocations",
)
async def bulk_create_po_item_allocations(
    payload: BulkCreateAllocationsRequest = Body(..., description="Bulk allocation creation payload"),
) -> BulkCreateAllocationsResponse:
    session = SessionLocal()
    now = datetime.utcnow()
    created_allocs: List[PurchaseOrderItemAllocationModel] = []
    for alloc_req in payload.allocations:
        requested_date_value = None
        if alloc_req.requested_delivery_date is not None and alloc_req.requested_delivery_date != "":
            requested_date_value = date.fromisoformat(alloc_req.requested_delivery_date)
        alloc = PurchaseOrderItemAllocation(
            po_item_id=alloc_req.po_item_id,
            store_location_id=alloc_req.store_location_id,
            quantity_case_packs=alloc_req.quantity_case_packs,
            requested_delivery_date=requested_date_value,
            created_at=now,
            updated_at=now,
        )
        session.add(alloc)
        session.commit()
        session.refresh(alloc)
        created_allocs.append(PurchaseOrderItemAllocationModel.model_validate(alloc))
    session.close()
    return BulkCreateAllocationsResponse(allocations=created_allocs)


@app.post(
    "/api/order-revisions",
    response_model=OrderRevisionResponse,
    summary="Create a new order revision for a PO",
    description="Create an order_revisions row in proposed status for a purchase order",
    tags=["order_revisions"],
    operation_id="create_order_revision",
)
async def create_order_revision(
    payload: CreateOrderRevisionRequest = Body(..., description="Order revision creation payload"),
) -> OrderRevisionResponse:
    session = SessionLocal()
    existing_revisions = session.query(OrderRevision).filter(OrderRevision.purchase_order_id == payload.purchase_order_id).all()
    revision_number = 1
    if len(existing_revisions) > 0:
        max_num = max(r.revision_number for r in existing_revisions)
        revision_number = max_num + 1
    now = datetime.utcnow()
    revision = OrderRevision(
        purchase_order_id=payload.purchase_order_id,
        revision_number=revision_number,
        status="proposed",
        buyer_comment=payload.buyer_comment,
        supplier_comment=None,
        created_by_user_id=1,
        created_at=now,
        updated_at=now,
    )
    session.add(revision)
    session.commit()
    session.refresh(revision)
    session.close()
    return OrderRevisionResponse(order_revision=OrderRevisionModel.model_validate(revision))


@app.post(
    "/api/order-revision-items",
    response_model=OrderRevisionItemResponse,
    summary="Create a revision item for a revision",
    description="Create an order_revision_items row describing a change for a PO line item",
    tags=["order_revisions"],
    operation_id="create_order_revision_item",
)
async def create_order_revision_item(
    payload: CreateOrderRevisionItemRequest = Body(..., description="Order revision item creation payload"),
) -> OrderRevisionItemResponse:
    session = SessionLocal()
    now = datetime.utcnow()
    item = OrderRevisionItem(
        order_revision_id=payload.order_revision_id,
        po_item_id=payload.po_item_id,
        proposed_quantity_case_packs=payload.proposed_quantity_case_packs,
        change_type=payload.change_type,
        created_at=now,
        updated_at=now,
    )
    session.add(item)
    session.commit()
    session.refresh(item)
    session.close()
    return OrderRevisionItemResponse(order_revision_item=OrderRevisionItemModel.model_validate(item))


@app.post(
    "/api/shipments",
    response_model=ShipmentResponse,
    summary="Create a shipment for a purchase order",
    description="Create a shipments row for a PO with carrier and tracking_number",
    tags=["shipments"],
    operation_id="create_shipment",
)
async def create_shipment(
    payload: CreateShipmentRequest = Body(..., description="Shipment creation payload"),
) -> ShipmentResponse:
    session = SessionLocal()
    now = datetime.utcnow()
    ship_date_value = date.fromisoformat(payload.ship_date)
    expected_delivery_date_value = None
    if payload.expected_delivery_date is not None and payload.expected_delivery_date != "":
        expected_delivery_date_value = date.fromisoformat(payload.expected_delivery_date)
    shipment = Shipment(
        purchase_order_id=payload.purchase_order_id,
        carrier=payload.carrier,
        tracking_number=payload.tracking_number,
        ship_date=ship_date_value,
        expected_delivery_date=expected_delivery_date_value,
        created_at=now,
        updated_at=now,
    )
    session.add(shipment)
    session.commit()
    session.refresh(shipment)
    session.close()
    return ShipmentResponse(shipment=ShipmentModel.model_validate(shipment))


@app.post(
    "/api/shipment-items/bulk",
    response_model=ShipmentItemsResponse,
    summary="Bulk create shipment items for a shipment",
    description="Create shipment_items rows linking a shipment to PO items and quantities",
    tags=["shipments"],
    operation_id="bulk_create_shipment_items",
)
async def bulk_create_shipment_items(
    payload: BulkCreateShipmentItemsRequest = Body(..., description="Bulk shipment items creation payload"),
) -> ShipmentItemsResponse:
    session = SessionLocal()
    now = datetime.utcnow()
    created_items: List[ShipmentItemModel] = []
    for item_req in payload.items:
        item = ShipmentItem(
            shipment_id=payload.shipment_id,
            po_item_id=item_req.po_item_id,
            quantity_case_packs=item_req.quantity_case_packs,
            created_at=now,
            updated_at=now,
        )
        session.add(item)
        session.commit()
        session.refresh(item)
        created_items.append(ShipmentItemModel.model_validate(item))
    session.close()
    return ShipmentItemsResponse(shipment_items=created_items)


@app.get(
    "/api/invoices",
    response_model=ListInvoicesResponse,
    summary="List invoices with filters",
    description="Retrieve invoices filtered by supplier_id, date range, or status",
    tags=["invoices"],
    operation_id="list_invoices",
)
async def list_invoices(
    supplier_id: Optional[int] = Query(None, description="Filter by supplier company id", example=20),
    retailer_id: Optional[int] = Query(None, description="Filter by retailer company id", example=5),
    start_issue_date: Optional[str] = Query(None, description="Filter issue_date >= this date YYYY-MM-DD", example="2025-10-01"),
    end_issue_date: Optional[str] = Query(None, description="Filter issue_date <= this date YYYY-MM-DD", example="2025-12-31"),
    status: Optional[str] = Query(None, description="Filter by invoice status", example="paid"),
) -> ListInvoicesResponse:
    session = SessionLocal()
    query = session.query(Invoice)
    if supplier_id is not None:
        query = query.filter(Invoice.supplier_id == supplier_id)
    if retailer_id is not None:
        query = query.filter(Invoice.retailer_id == retailer_id)
    if start_issue_date is not None and start_issue_date != "":
        query = query.filter(Invoice.issue_date >= date.fromisoformat(start_issue_date))
    if end_issue_date is not None and end_issue_date != "":
        query = query.filter(Invoice.issue_date <= date.fromisoformat(end_issue_date))
    if status is not None:
        query = query.filter(Invoice.status == status)
    invoices = query.all()
    session.close()
    return ListInvoicesResponse(invoices=[InvoiceModel.model_validate(inv) for inv in invoices])


@app.get(
    "/api/invoices/{invoice_id}/payments",
    response_model=ListInvoicePaymentsResponse,
    summary="List payments for an invoice",
    description="Retrieve invoice_payments rows for a given invoice",
    tags=["invoices", "payments"],
    operation_id="list_invoice_payments",
)
async def list_invoice_payments(
    invoice_id: int = Path(..., description="Invoice id", example=90001),
) -> ListInvoicePaymentsResponse:
    session = SessionLocal()
    payments = session.query(InvoicePayment).filter(InvoicePayment.invoice_id == invoice_id).all()
    session.close()
    return ListInvoicePaymentsResponse(payments=[InvoicePaymentModel.model_validate(p) for p in payments])


@app.get(
    "/api/accounting/po-invoice-export",
    response_model=AccountingExportResponse,
    summary="Export POs and invoices for accounting",
    description="Return purchase orders and related invoices with aggregated totals",
    tags=["accounting", "purchase_orders", "invoices"],
    operation_id="export_pos_and_invoices",
)
async def export_pos_and_invoices(
    supplier_id: int = Query(..., description="Supplier company id to export data for", example=20),
    retailer_id: Optional[int] = Query(None, description="Optional retailer company id filter", example=5),
    start_date: str = Query(..., description="Start of issue_date range YYYY-MM-DD", example="2025-10-01"),
    end_date: str = Query(..., description="End of issue_date range YYYY-MM-DD", example="2025-12-31"),
) -> AccountingExportResponse:
    session = SessionLocal()
    start_dt = date.fromisoformat(start_date)
    end_dt = date.fromisoformat(end_date)
    po_query = session.query(PurchaseOrder).filter(PurchaseOrder.supplier_id == supplier_id)
    if retailer_id is not None:
        po_query = po_query.filter(PurchaseOrder.retailer_id == retailer_id)
    purchase_orders = po_query.all()
    store_ids = list({po.store_location_id for po in purchase_orders})
    stores = session.query(StoreLocation).filter(StoreLocation.id.in_(store_ids)).all() if len(store_ids) > 0 else []
    store_map: Dict[int, StoreLocation] = {s.id: s for s in stores}
    po_models: List[AccountingPurchaseOrderExportModel] = []
    for po in purchase_orders:
        store = store_map.get(po.store_location_id)
        po_models.append(
            AccountingPurchaseOrderExportModel(
                po_id=po.id,
                po_number=po.po_number,
                store_location_id=po.store_location_id,
                store_location_name=store.name if store is not None else None,
                status=po.status,
                requested_delivery_date=po.requested_delivery_date,
            )
        )
    inv_query = session.query(Invoice).filter(Invoice.supplier_id == supplier_id, Invoice.issue_date >= start_dt, Invoice.issue_date <= end_dt)
    if retailer_id is not None:
        inv_query = inv_query.filter(Invoice.retailer_id == retailer_id)
    invoices = inv_query.all()
    invoice_ids = [inv.id for inv in invoices]
    payments = session.query(InvoicePayment).filter(InvoicePayment.invoice_id.in_(invoice_ids)).all() if len(invoice_ids) > 0 else []
    paid_map: Dict[int, float] = {}
    for p in payments:
        paid_map[p.invoice_id] = paid_map.get(p.invoice_id, 0.0) + p.amount
    inv_models: List[AccountingInvoiceExportModel] = []
    total_invoice_amount = 0.0
    total_paid_amount = 0.0
    for inv in invoices:
        paid_amount = paid_map.get(inv.id, 0.0)
        total_invoice_amount += inv.total_amount
        total_paid_amount += paid_amount
        inv_models.append(
            AccountingInvoiceExportModel(
                invoice_id=inv.id,
                invoice_number=inv.invoice_number,
                purchase_order_id=inv.purchase_order_id,
                issue_date=inv.issue_date,
                due_date=inv.due_date,
                total_amount=inv.total_amount,
                payment_terms=inv.payment_terms,
                status=inv.status,
                total_paid_amount=paid_amount,
            )
        )
    aggregates = AccountingAggregatesModel(
        total_invoice_amount=total_invoice_amount,
        total_paid_amount=total_paid_amount,
        invoice_count=len(invoices),
    )
    session.close()
    return AccountingExportResponse(
        supplier_id=supplier_id,
        retailer_id=retailer_id,
        period_start=start_dt,
        period_end=end_dt,
        purchase_orders=po_models,
        invoices=inv_models,
        aggregates=aggregates,
    )


if __name__ == "__main__":
    import uvicorn
    host = os.getenv("HOST", "127.0.0.1")
    port = int(os.getenv("PORT", "8000"))
    uvicorn.run(app, host=host, port=port)