def verify_task_completion(initial_db_path: str, final_db_path: str, final_answer: str | None = None) -> dict:
    import sqlite3
    
    def safe_query(db_path: str, query: str, params: tuple = ()) -> list:
        try:
            conn = sqlite3.connect(f"file:{db_path}?mode=ro", uri=True)
            cursor = conn.cursor()
            cursor.execute(query, params)
            results = cursor.fetchall()
            conn.close()
            return results
        except Exception:
            return []
    
    # Get initial product state
    initial_product = safe_query(
        initial_db_path,
        "SELECT id, availability_status, lead_time_business_days FROM products WHERE sku = ?",
        ('LINEN-NAPKIN-SET4',)
    )
    
    if not initial_product:
        return {"result": "others"}
    
    product_id, initial_status, initial_lead_time = initial_product[0]
    
    # Verify initial state matches expectations
    if initial_status != 'in_stock' or initial_lead_time != 7:
        return {"result": "others"}
    
    # Get final product state
    final_product = safe_query(
        final_db_path,
        "SELECT id, availability_status, lead_time_business_days FROM products WHERE sku = ?",
        ('LINEN-NAPKIN-SET4',)
    )
    
    if not final_product:
        return {"result": "others"}
    
    final_product_id, final_status, final_lead_time = final_product[0]
    
    # Verify product_id is consistent
    if product_id != final_product_id:
        return {"result": "others"}
    
    # Check if availability_status changed to 'backorder'
    if final_status != 'backorder':
        return {"result": "others"}
    
    # Check if lead_time changed to 21
    if final_lead_time != 21:
        return {"result": "others"}
    
    # Get final price tiers for this product
    final_tiers = safe_query(
        final_db_path,
        "SELECT min_case_packs, max_case_packs, unit_price FROM product_price_tiers WHERE product_id = ? ORDER BY min_case_packs",
        (product_id,)
    )
    
    if not final_tiers:
        return {"result": "others"}
    
    # Need to find the tiers that match 1-10 and 11-50
    tier_1_10_found = False
    tier_11_50_found = False
    
    for min_cp, max_cp, unit_price in final_tiers:
        # Check for 1-10 tier with $7.00
        if min_cp == 1 and max_cp == 10:
            if abs(unit_price - 7.0) < 0.001:
                tier_1_10_found = True
        
        # Check for 11-50 tier with $6.50
        if min_cp == 11 and max_cp == 50:
            if abs(unit_price - 6.5) < 0.001:
                tier_11_50_found = True
    
    # All conditions must be met
    if tier_1_10_found and tier_11_50_found:
        return {"result": "complete"}
    
    return {"result": "others"}