"""Targeted BF16 reference repair for actual read-without-act failures.

The original learner task/history stays unchanged. Extra reference assistance
is explicitly recorded; it is never reported as unguided BF16 performance.
"""
import copy
import fcntl
from pathlib import Path
import shutil
import time
import traceback

import admit_semantic_bfcl_cases as semantic

x,d=semantic.x,semantic.d
R=Path('/mnt/genming/ablation-pending-reference-repair-20261105')
SOURCE=semantic.R
PLAN=['multi_turn_base_74','multi_turn_base_99']


def prepare(task):
    case=R/'cases'/task.task_id
    if (case/'reference-alignment.json').exists():return case
    parent=SOURCE/'cases'/task.task_id
    for name in ['task.json','scope.json','anchor-context.json','prefix-execution.json',
                 'failed-decision.json','failed-execution.json','semantic-admission.json']:
        path=case/name;path.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(parent/name,path)
    previous=d.load(parent/'teacher-reference-verifier-repair/score.json')
    assert previous['valid'] and not previous['passed']
    current=d.load(parent/'semantic-admission.json')['pre_state']
    discrepancy=previous['official_state']['details']['differences']
    text=('Reference-construction assistance, not an unguided evaluation. The original user requested '
        'an actual environment operation. The previous tool only returned information; the requested '
        'operation has not happened. The previous completion claims are false according to the native '
        'state verifier. In your NEXT response, call one advertised state-changing tool through '
        'the normal call_tool wrapper to perform the outstanding original request. Do not give '
        'a final answer, recommendation, plan, or another informational lookup in this next response. '
        'Choose the actual advertised tool and arguments yourself. After its result, verify the '
        'effect and finish normally. Measured state discrepancy (current versus requested):\n'+
        __import__('json').dumps(discrepancy,ensure_ascii=False,default=str))
    guide=dict(text=text,origin='human-authored reference-construction protocol plus actual native verifier feedback',
        actual_discrepancy=discrepancy,not_a_teacher_model_output=True,
        not_unguided_BF16_performance=True,learner_and_control_prompts_unchanged=True)
    d.save(case/'reference-assistance.json',guide)
    scope=d.load(case/'scope.json');source=case/'teacher-reference-atomic-repair'
    score=d.rollout(task,'teacher',source,d.load(case/'anchor-context.json'),
        d.load(case/'prefix-execution.json'),seed=42,guidance=text,goal_turn=scope['goal_turn'])
    if not score['valid'] or not score['passed']:
        raise ValueError('The single targeted BF16 reference repair did not perform the unchanged native goal; retained without qualification')
    env,allowed,messages,events=x.restore(task,case)
    initial=d.snapshot(env);target=None;trace=[]
    for turn,path in enumerate(sorted(source.glob('turn-*/response.json'))):
        raw=d.load(path);got=d.execute(env,allowed,messages,d.parse_message(raw['choices'][0]['message']),turn)
        for event in got:event['user_turn']=scope['goal_turn']
        if turn==0:
            assert got and not any(e['semantic_tool_error'] for e in got)
            target=dict(state=d.snapshot(env),responses=d.canonical([e['response'] for e in got]))
            assert target['state']!=initial, 'Atomic repair must actually perform a state-changing operation'
        events.extend(got);trace.append(dict(source_response=str(path),execution=got))
    verdict=x.native_score(task,env,events,scope['goal_turn']);assert verdict['passed']
    d.save(case/'reference-alignment.json',dict(verified=True,exact_state_replay=True,
        reference=str(source),source_successful_reference=str(source),local_target=target,
        restored_state=initial,restored_state_sha256=d.sha(initial),
        restored_context_sha256=d.sha(d.load(case/'anchor-context.json')),
        official_score=verdict,suffix_replay=trace,reference_verifier_assistance=True,
        reference_assistance=str(case/'reference-assistance.json'),
        not_unguided_teacher_performance=True,learner_original_context_preserved=True))
    return case


def main():
    R.mkdir(parents=True,exist_ok=True)
    lock=(R/'controller.lock').open('w');fcntl.flock(lock,fcntl.LOCK_EX | fcntl.LOCK_NB)
    x.R=R;x.prepare=prepare;x.audit.R=R/'native-audits';d.status=x.emit
    old_reply=d.reply
    def traced(messages,role,dest,*a,**kw):
        x.emit('model_request',source=role,artifact=str(dest));start=time.monotonic()
        result=old_reply(messages,role,dest,*a,**kw)
        d.save(dest/'timing.json',dict(request_wall_seconds=time.monotonic()-start));return result
    d.reply=traced
    d.save(R/'protocol.json',dict(plan=PLAN,reference_extra_attempts=1,
        reference_assistance='explicit remaining-state verifier feedback and one state-changing next response',
        reference_outputs_are_actual_BF16_generations=True,
        source_of_assistance_disclosed=True,not_unguided_BF16_performance=True,
        learner_task_history_and_guidance_protocol_unchanged=True,thinking=True))
    tasks={t.task_id:t for t in d.load_bfcl_dataset('multi_turn_base',None)}
    for identifier in PLAN:
        try:x.run(tasks[identifier])
        except Exception as exc:
            d.save(R/'cases'/identifier/'needs-review.json',dict(error=str(exc),traceback=traceback.format_exc(),excluded_not_a_model_failure=True))
        rows=[d.load(p) for p in (R/'cases').glob('*/comparison.json')]
        d.save(R/'progress.json',dict(completed=len(rows),replay_verified_candidates=[v['task'] for v in rows if v['qualified']],manual_review_required=True))
    x.emit('targeted_reference_repair_complete')


if __name__=='__main__':main()
