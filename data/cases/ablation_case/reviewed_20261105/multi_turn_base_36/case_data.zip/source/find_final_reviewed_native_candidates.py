"""Recover precise checkpoints from older discovery records lacking pointers.

The saved native student trajectories identify every task, goal turn, and failed
decision. No original discovery result, task, or model output is overwritten.
"""
from pathlib import Path

import find_final_native_causal_case as f

a, x, d = f.a, f.x, f.d
R = Path('/mnt/genming/ablation-final-reviewed-candidates-20261105')
PLAN = {
    'multi_turn_base_44': dict(goal_turn=0, anchor_tool='echo', wanted=['cd'],
        reason='The requested existing annual_report.txt is in documents. The actual student tried writing in the root, then created a duplicate root file instead of updating the existing document.'),
    'multi_turn_base_36': dict(goal_turn=1, anchor_tool='mv', wanted=['cd'],
        reason='The archive copy already exists in the requested archive directory. The actual student used a rename before entering it, then created a different archives directory and finished at the wrong destination.'),
    'multi_turn_base_134': dict(goal_turn=1, anchor_tool=None, wanted=['cancel_order'],
        reason='The actual student observed that order 12446 was Pending but asked again for cancellation permission instead of executing the user-authorized conditional withdrawal.'),
}


def checkpoint(task):
    case = R / 'cases' / task.task_id
    if (case / 'semantic-admission.json').exists():
        return case
    parent = x.BASE / task.task_id
    review = PLAN[task.task_id]
    goal = review['goal_turn']
    source = parent / ('student' if goal == 0 else 'student-user-%02d' % goal)
    score = d.load(source / 'score.json')
    assert score['valid'] and not score['passed'] and x.substantive_state_failure(score)
    assert score['goal_turn'] == goal
    events = d.load(source / 'execution.json')
    if review['anchor_tool']:
        anchor = next(e['turn'] for e in events if e.get('user_turn', 0) == goal and
                      e['tool'] == review['anchor_tool'])
    else:
        response = sorted(source.glob('turn-*/response.json'))[-1]
        anchor = int(response.parent.name.split('-')[-1])
        assert not d.parse_message(d.load(response)['choices'][0]['message']).get('tool_calls')
    prefix = [e for e in events if e.get('user_turn', 0) < goal or
              (e.get('user_turn', 0) == goal and e['turn'] < anchor)]
    context = d.load(source / f'turn-{anchor:03d}/pre-context.json')
    d.save(case / 'task.json', d.load(parent / 'task.json'))
    d.save(case / 'scope.json', dict(goal_turn=goal, source_student=str(source),
        original_request=task.question[goal], previously_passed_user_turns=list(range(goal))))
    d.save(case / 'anchor-context.json', context)
    d.save(case / 'prefix-execution.json', prefix)
    d.save(case / 'failed-decision.json', d.load(source / f'turn-{anchor:03d}/response.json'))
    d.save(case / 'failed-execution.json', dict(kind='reviewed actual semantic failure',
        source_response=str(source / f'turn-{anchor:03d}/response.json'),
        execution=d.load(source / f'turn-{anchor:03d}/execution.json'),
        substantive_error=review['reason'], original_official_score=score))
    env, _, _, _ = x.restore(task, case)
    d.save(case / 'semantic-admission.json', dict(approved_candidate=True, qualified=False,
        reason=review['reason'], source=str(source), anchor_turn=anchor,
        actual_prefix_replayed=True, pre_state=d.snapshot(env),
        original_task_text_initial_configuration_and_checkers_unchanged=True))
    return case


if __name__ == '__main__':
    f.R = R
    f.PLAN = PLAN
    a.prepare_checkpoint = checkpoint
    f.main()
