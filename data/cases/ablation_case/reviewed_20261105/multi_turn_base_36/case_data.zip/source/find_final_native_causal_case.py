"""Two specific causal follow-ups for the remaining showcase slot.

Fuel: use the real state AFTER the student's insufficient partial refill.
Brake: reuse an already verified teacher witness and sample guidance wording,
with the same native guidance sampler for both local advisor sources.
"""
import fcntl
from pathlib import Path
import shutil
from concurrent.futures import ThreadPoolExecutor

import continue_native_thinking_cases as n

a, x, d = n.a, n.x, n.d
R = Path('/mnt/genming/ablation-final-causal-candidates-20261105')
PLAN = {
    'multi_turn_base_59': dict(anchor_tool=None, wanted=['fillFuelTank'],
        reason='After the actual insufficient refill, fuel is still below capacity; the student ends as though the full-tank request were complete. Recover at that real final-decision checkpoint, not before the earlier partial refill.'),
    'multi_turn_base_84': dict(anchor_tool=None, wanted=['pressBrakePedal', 'startEngine'],
        reason='The correct parked state must be preserved while pressing the separate foot brake and starting the engine; use the existing replay-verified witness from this exact checkpoint.'),
}


def prepare(task):
    if task.task_id != 'multi_turn_base_84':
        return a.prepare(task)
    case = R / 'cases' / task.task_id
    if (case / 'reference-revalidation.json').exists():
        return case
    parent = Path('/mnt/genming/ablation-reviewed-bfcl-backfill-20261105/cases') / task.task_id
    case.mkdir(parents=True, exist_ok=True)
    for name in ['task.json', 'scope.json', 'anchor-context.json', 'prefix-execution.json',
                 'failed-decision.json', 'failed-execution.json', 'reference-alignment.json']:
        shutil.copy2(parent / name, case / name)
    reference = d.load(case / 'reference-alignment.json')
    shutil.copytree(Path(reference['reference']), case / 'aligned-teacher-reference', dirs_exist_ok=True)
    reference['reference'] = str(case / 'aligned-teacher-reference')
    d.save(case / 'reference-alignment.json', reference)
    env, allowed, messages, events = x.restore(task, case)
    assert d.sha(d.snapshot(env)) == reference['restored_state_sha256']
    assert d.sha(messages) == reference['restored_context_sha256']
    for turn, p in enumerate(sorted((case / 'aligned-teacher-reference').glob('turn-*/response.json'))):
        raw = d.load(p)
        got = d.execute(env, allowed, messages, d.parse_message(raw['choices'][0]['message']), turn)
        for e in got:
            e['user_turn'] = d.load(case / 'scope.json')['goal_turn']
        assert got == d.load(p.parent / 'execution.json')
        events.extend(got)
    verdict = x.native_score(task, env, events, d.load(case / 'scope.json')['goal_turn'])
    assert verdict['passed']
    d.save(case / 'reference-revalidation.json', dict(verified=True, actual_teacher_actions_reexecuted=True,
           unchanged_native_verdict=verdict, source=str(parent), teacher_outputs_not_edited=True))
    d.save(case / 'semantic-admission.json', dict(approved_candidate=True, qualified=False,
           reason=PLAN[task.task_id]['reason'], source=str(parent),
           original_task_text_initial_configuration_and_checkers_unchanged=True))
    return case


def main():
    R.mkdir(exist_ok=True)
    lock = (R / 'controller.lock').open('w')
    fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
    n.R = R
    a.R = R
    a.REVIEWS = PLAN
    x.R = R
    d.R = R
    x.prepare = prepare
    x.audit.R = R / 'native-audits'
    d.status = x.emit
    n.install_reply_audit()
    checked = d.reply

    def sampled_guidance(messages, role, dest, seed, *args, **kwargs):
        if 'guidance' in dest.parts:
            index = int(dest.name.removeprefix('attempt-'))
            kwargs['temperature'] = 0.6
            seed = 42 + index
        return checked(messages, role, dest, seed, *args, **kwargs)

    d.reply = sampled_guidance
    d.save(R / 'protocol.json', dict(plan=PLAN, source_models=d.WEIGHTS,
        source='existing failures with reviewed causal intervention points',
        original_task_system_prompt_initial_configuration_and_checkers_unchanged=True,
        thinking=True, actual_native_actor_thinking_verified=True,
        actor_temperature=0.6, actor_seeds=x.SEEDS, requested_max_tokens=32768,
        local_advisor_sampling=dict(temperature=0.6, seed='42 + guidance refinement index'),
        external_advisor_settings='Native API settings retained in its request artifact',
        same_frozen_reference_and_feedback_for_all_advisor_sources=True,
        all_trials_retained=True, selected_case_only_not_aggregate_performance=True,
        manual_semantic_review_required=True, stop_at_manually_approved_cases=10))
    tasks = {t.task_id: t for t in d.load_bfcl_dataset('multi_turn_base', None)}
    with ThreadPoolExecutor(max_workers=2) as pool:
        futures = [pool.submit(n.run, tasks[key]) for key in PLAN if not n.target_reached()]
        for future in futures:
            future.result()
    x.emit('final_causal_candidates_complete')


if __name__ == '__main__':
    main()
