"""Controlled causal-intervention examples, distinct from episode accuracy.

All guidance and student outputs are real model generations. Designed fixtures
are explicitly marked. A control is wrong only after a concrete tool error,
forbidden state change, invalid payload write, or premature termination.
Valid additional observations are never counted as failed corrections.
"""
import copy
import fcntl
import json
from pathlib import Path
import time
import traceback
import constructed_ablation_cases as c

R = Path('/mnt/genming/ablation-constructed-local-20261104')
ROLES = c.ROLES
DISPLAY = dict(C01='读取前进入正确目录', C02='建立备份时保留原件',
    C03='写入差异文本而非传输包装', C04='替换前保留旧版本', C05='清理前进入目标目录',
    C06='复制前建立正确类型的归档目录', C07='已完成状态不重复写入', C08='写入数值前创建输出文件',
    C09='启动前将制动力从半踩提升到全踩', C10='只解除指定车门的锁', M04='备份已完成时更新规则并完成替换')


def emit(phase, **extra):
    value = dict(time=time.time(), phase=phase, **extra)
    c.d.save(R/'status.json', value)
    print(json.dumps(value,ensure_ascii=False),flush=True)


def generated_guidance(spec, variant, attempt, feedback):
    case = c.prepare(spec)
    reference = c.reference(spec,case)
    out = R/'cases'/spec['id']/'guidance'/variant/f'attempt-{attempt}'
    if (out/'guidance.json').exists():
        return c.d.load(out/'guidance.json')['text'],out/'guidance.json'
    source = Path(reference['teacher_source'])
    full_reference = []
    if spec.get('aligned_reference_only'):
        # Use only the real teacher suffix actually reexecuted at this exact
        # checkpoint. Earlier teacher operations belong to a different state.
        for row in reference['suffix_replay']:
            p = Path(row['source'])
            full_reference.append(dict(actual_response=c.d.load(p)['choices'][0]['message'],
                execution=row['execution']))
    else:
        for p in sorted(source.glob('turn-*/response.json')):
            full_reference.append(dict(actual_response=c.d.load(p)['choices'][0]['message'],
                execution=c.d.load(p.parent/'execution.json')))
    decision_origin = ('actual saved student mistaken decision' if spec.get('observed_failure_response')
        else 'injected mistaken decision')
    prompt = (f'Analyze the {decision_origin} at this restored recovery checkpoint. '
        'Compare it with the fixed successful counterfactual for the same task. '
        'Give one concise, local procedural correction for the next student response. '
        'Identify the actual discrepancy, applicable state precondition, corrective rule, '
        'expected effect and recovery check. Preserve valid context and valid alternative '
        'actions. Do not execute the action or claim that an unexecuted effect has occurred. ')
    prompt += ('Return free-form procedural guidance.' if variant=='teacher_freeform' else
        'Return one JSON object with precondition, decision_rule, expected_transition, recovery_check.')
    evidence = dict(task=spec['task'],current_context=c.d.load(case/'context.json'),
        actual_restored_state=c.d.load(case/'pre-state.json'),
        injected_counterexample=c.d.load(case/'counterexample.json'),
        fixed_successful_reference=full_reference,reference_verified=reference['goal'],
        actual_local_verifier_feedback=feedback)
    if spec.get('causal_transition_summary'):
        initial = c.d.load(case/'pre-state.json')
        failed = c.d.load(case/'counterexample.json')['execution']
        first = reference['first_execution']
        assert first and first[0]['before'] == initial
        evidence['verified_local_comparison'] = dict(
            current_before=initial,
            failed_next_response=failed,
            successful_next_response=first,
            actual_failed_state_delta=c.changed_fields(initial, failed[-1]['after']),
            successful_state_delta=c.changed_fields(initial, first[-1]['after']),
            current_state_is_before_not_reference_after=True)
        prefix = c.d.load(case/'diagnostic-prefix.json')
        if spec.get('replay_real_prefix') and prefix:
            last = prefix[-1]
            evidence['already_accepted_prefix_effect'] = dict(tool=last['tool'],
                arguments=last['arguments'], response=last['response'],
                observed_state_delta=c.changed_fields(last['before'], last['after']),
                resulting_state_is_current_before=last['after'] == initial)
        prompt += (' The verified_local_comparison explicitly separates the current BEFORE state '
            'from the successful AFTER state. State preconditions must describe current_before. '
            'Prior accepted effects are already present: preserve their constraints while updating '
            'obsolete instructions. Diagnose the failed next response against the successful next '
            'response; do not restart an already completed earlier phase.')
    if spec.get('accepted_memory_source'):
        evidence['prior_locally_accepted_steer_memory'] = c.d.load(Path(spec['accepted_memory_source']))
        evidence['verified_real_prefix_sources'] = spec['replay_real_prefix']
        prompt += ' Combine the new steer with the prior accepted memory, keeping only conditions and rules that still apply at this current state.'
    if spec.get('aligned_reference_only'):
        prompt += (' The fixed reference is the suffix independently replayed from this exact current checkpoint. '
            'Its first transition is the local causal comparison. Earlier accepted memory describes an earlier '
            'phase: retain its constraints, but do not repeat actions whose effects are already present. '
            'Keep this recovery scoped to the next response, then allow unguided continuation.')
    if spec.get('single_next_transition'):
        prompt += (' Describe only the immediate next operation verified in the aligned comparison. '
            'Do not combine it with a later operation in decision_rule. The expected_transition '
            'must be the observed effect of that one immediate operation, not the final task goal. '
            'A downstream operation may be mentioned only conditionally in recovery_check, '
            'after the immediate effect has been verified and guidance has been withdrawn.')
    messages=[dict(role='system',content=prompt),dict(role='user',content=json.dumps(evidence,ensure_ascii=False))]
    if variant=='external_structured':
        import tomllib
        config=tomllib.loads(Path('/mnt/genming/.codex/config.toml').read_text())
        auth=c.d.load(Path('/mnt/genming/.codex/auth.json'))
        raw=c.external_request(dict(model='gpt-5.6-sol',messages=messages,max_tokens=32768,
            reasoning_effort=config.get('model_reasoning_effort','high'),response_format=c.SCHEMA),
            out,config['openai_base_url'].rstrip('/'),{'Authorization':'Bearer '+auth['OPENAI_API_KEY']})
    else:
        raw=c.d.reply(messages,'student' if variant=='student_structured' else 'teacher',
            out,42,temperature=0,schema=None if variant=='teacher_freeform' else c.SCHEMA)
    choice=raw['choices'][0]
    text=choice['message'].get('content') or ''
    if not text.strip() or choice['finish_reason']=='length':
        raise ValueError('Incomplete guidance excluded; not a student failure')
    if variant!='teacher_freeform':
        parsed=json.loads(text)
        assert set(parsed)==set(c.FIELDS) and all(isinstance(parsed[k],str) and parsed[k].strip() for k in c.FIELDS)
    c.d.save(out/'guidance.json',dict(text=text,variant=variant,real_model_generation=True,
        representation='unconstrained tool-action text' if '<tool_call>' in text else
            ('unstructured instruction' if variant=='teacher_freeform' else 'four-field structured instruction')))
    return text,out/'guidance.json'


def forbidden_change(spec, initial, after, events):
    checks=c.evaluate(spec,after,initial,[], '')['checks']
    if not checks.get('protected_files_preserved',True):
        return 'A file explicitly required to be preserved was removed or changed'
    if spec['goal'].get('readonly') and not checks.get('no_files_changed',True):
        return 'A read-only task modified the filesystem'
    for directory,allowed in spec['goal'].get('exact_children',{}).items():
        if directory in after['files']:
            return 'Created a file where the task requires an archive directory'
        children={p.rsplit('/',1)[-1] for p in list(after['files'])+after['directories'] if p.rsplit('/',1)[0]==directory}
        if children-set(allowed):
            return 'Copied an explicitly excluded hidden file, file type, or subdirectory'
    for e in events:
        if e['tool']=='echo':
            path=e['before'].get('cwd','')+'/'+e['arguments'].get('file_name','')
            wanted=spec['goal'].get('files',{}).get(path)
            if wanted is not None and not c.equal_text(after['files'].get(path,''),wanted):
                return 'Wrote a task-incompatible payload to the requested output file'
            if path in spec['goal'].get('numeric_files',{}) and not checks.get('numeric_payload:'+path,False):
                return 'Stored a nonnumeric or incorrect numeric payload instead of the requested scalar'
        if e['tool']=='lockDoors' and e['arguments'].get('unlock'):
            expected=spec['goal'].get('vehicle',{}).get('doorStatus',{})
            if any(v=='locked' and after.get('vehicle',{}).get('doorStatus',{}).get(k)!='locked' for k,v in expected.items()):
                return 'Unlocked an actuator the user explicitly required to remain locked'
    return None


def classify(spec, sample, score):
    case=c.prepare(spec);initial=c.d.load(case/'pre-state.json')
    assert not c.local_gate(spec,initial,initial,[]), 'Checkpoint must not already satisfy its local recovery condition'
    for turn,p in enumerate(sorted(sample.glob('turn-*/execution.json'))):
        events=c.d.load(p)
        for e in events:
            if e['semantic_tool_error']:
                error=str(e['response']).lower()
                if any(x in error for x in ['unknown or unavailable advertised tool','unexpected keyword argument']):
                    return dict(result='inconclusive',turn=turn,reason='Schema/adapter mismatch excluded from mechanism examples')
                return dict(result='wrong',turn=turn,reason='Executed tool rejected an unmet prerequisite or invalid operation',evidence=e)
        after=events[-1]['after'] if events else (c.d.load(sample/'restore.json')['exact_state'] if turn==0 else None)
        if events:
            bad=forbidden_change(spec,initial,after,events)
            if bad:
                return dict(result='wrong',turn=turn,reason=bad,evidence=events)
            if c.local_gate(spec,after,initial,events):
                return dict(result='correct',turn=turn,reason='Reached the predeclared, reference-verified local condition',state=after)
        raw=c.d.load(p.parent/'response.json')
        msg=c.d.parse_message(raw['choices'][0]['message'])
        if not msg.get('tool_calls') and score['valid'] and not score['passed']:
            return dict(result='wrong',turn=turn,reason='Stopped without performing the required recovery operation',
                final_answer=score['final_answer'],failed_task_conditions=score['goal']['failed_conditions'])
    return dict(result='inconclusive',reason='Only valid observations or nondecisive actions; not counted as failure')


def branch(spec,variant):
    root=R/'cases'/spec['id']/variant
    if (root/'outcome.json').exists():return c.d.load(root/'outcome.json')
    feedback=[];history=[]
    for attempt in range(4):
        emit('local_guidance',case=spec['id'],variant=variant,attempt=attempt)
        try:
            text,gpath=generated_guidance(spec,variant,attempt,feedback)
            sample=root/f'attempt-{attempt}'
            # Same actor seed for every source and every refinement. Refinement
            # changes actual guidance rather than searching random seeds.
            score=c.rollout(spec,'student',sample,seed=c.d.SEED,guidance=text)
            if not score['valid']:raise ValueError('Incomplete actor run excluded')
            local=classify(spec,sample,score)
            record=dict(sample=str(sample),guidance=str(gpath),actor_seed=c.d.SEED,
                local=local,whole_task_passed=score['passed'],score=score)
            history.append(record)
            desired=(score['local_accepted'] and local['result']=='correct' and
                score['unsteered_requests']>0) if variant=='teacher_structured' else local['result']=='wrong'
            if desired:
                outcome=dict(selected=record,history=history,found=True)
                c.d.save(root/'outcome.json',outcome);return outcome
            if variant!='teacher_structured':
                break  # Correct controls are never rerun to hunt a failure.
            feedback.append(dict(actual_first_execution=c.d.load(sample/'turn-000/execution.json'),
                local_result=local,first_response_check=c.d.load(sample/'local-check.json'),
                task_verifier=score['goal'],instruction='Revise the local rule at the same restored state using these executed results.'))
        except Exception as exc:
            c.d.save(root/f'excluded-attempt-{attempt}.json',dict(error=str(exc),traceback=traceback.format_exc(),
                excluded_not_a_semantic_failure=True))
            break
    outcome=dict(found=False,history=history)
    c.d.save(root/'outcome.json',outcome);return outcome


def run(spec):
    dest=R/'cases'/spec['id']
    if (dest/'comparison.json').exists():return
    c.prepare(spec);c.reference(spec,c.prepare(spec))
    ours=branch(spec,'teacher_structured')
    controls={}
    if ours['found']:
        for index,role in enumerate(ROLES[1:]):
            controls[role]=branch(spec,role)
            hits=sum(row['found'] for row in controls.values())
            if hits+(2-index)<2:break
    failed=[k for k,v in controls.items() if v['found']]
    qualified=ours['found'] and len(failed)>=2
    audits={}
    if qualified:
        records={'teacher_structured':ours['selected'],**{k:v['selected'] for k,v in controls.items() if v['found']}}
        for role,record in records.items():
            # Native state/action replay also reproduces the recorded episode
            # verdict, even when a control later recovers by itself.
            audits[role]=c.audit_selected(spec,record)
    c.d.save(dest/'comparison.json',dict(case=spec['id'],title=DISPLAY.get(spec['id'],spec['title']),qualified=qualified,
        broader_task_context=spec['task'],
        source='self-constructed controlled causal checkpoint',evaluation_unit='local recovery intervention',
        whole_episode_accuracy_claim=False,ours=ours,controls=controls,failed_controls=failed,
        replay_audits=audits,presentation_review_pending=qualified,
        fixture_provenance=str(c.prepare(spec)/'provenance.json')))


def report():
    values=[c.d.load(p) for p in (R/'cases').glob('*/comparison.json')]
    old=Path('/mnt/genming/ablation-single-trial-selection-20261104/progress.json')
    existing=c.d.load(old)['qualified'] if old.exists() else 0
    result=dict(time=time.time(),existing_whole_task_cases=existing,
        constructed_local_cases=sum(v['qualified'] for v in values),
        curated_case_total=existing+sum(v['qualified'] for v in values),
        completed=len(values),target=10,evaluation_unit='local interventions; episode verdicts retained separately',
        qualified_cases=[v['case'] for v in values if v['qualified']])
    c.d.save(R/'progress.json',result);return result


def main():
    R.mkdir(parents=True,exist_ok=True)
    lock=(R/'controller.lock').open('w');fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
    specs=c.designs()
    memory=c.R/'memory-checkpoint-design.json'
    if memory.exists():specs.insert(0,c.d.load(memory))
    c.d.save(R/'protocol.json',dict(source='deliberately constructed causal cases',
        evaluation_unit='one local recovery intervention; complete continuation preserved',
        guidance_sources=ROLES,actor_seed=c.d.SEED,actor_seed_search=False,
        source_input='same full fixed successful reference and actual restored context/state for all four sources',
        method_refinement='at most four verifier-guided prompt revisions at the same state and same actor seed',
        control_policy='one valid trial; only real operation errors, forbidden mutations or premature termination count',
        whole_episode_success_does_not_erase_a_rejected_local_action=True,
        hand_written_elements=['task','initial fixture','injected counterexample'],model_outputs_are_actual=True))
    by_id={s['id']:s for s in specs}
    for identifier in ['M04','C09','C04','C05','C08','C07','C06','C10','C02','C01','C03']:
        if identifier not in by_id:continue
        spec=by_id[identifier]
        if report()['curated_case_total']>=10:emit('target_reached',target=10);return
        try:run(spec)
        except Exception as exc:
            c.d.save(R/'cases'/spec['id']/'needs-review.json',dict(error=str(exc),traceback=traceback.format_exc()))
            emit('needs_design_review',case=spec['id'],error=str(exc))
        report()
    emit('designed_checkpoint_pass_complete',progress=report())


if __name__=='__main__':main()
