"""Bounded selected-trial recovery for an existing measured checkpoint.

All sources receive the same saved comparison and actual verifier feedback.
No model output, tool call, guide, or task is handwritten or silently repaired.
"""
import fcntl
import json
from pathlib import Path
import traceback

import reuse_near_qualified_cases as reuse

e, c = reuse.experiment, reuse.c
R = Path('/mnt/genming/ablation-existing-checkpoint-selection-20261105')
SEEDS = [c.d.SEED + i for i in [101, 102, 103]]


def samples(spec, role, guide_path):
    text = c.d.load(guide_path)['text']
    records = []
    for seed in SEEDS:
        dest = R/'cases'/spec['id']/role/f'seed-{seed}'
        if (dest/'excluded-error.json').exists():
            continue
        e.emit('selected_trial', case=spec['id'], variant=role, seed=seed)
        try:
            score = c.rollout(spec, 'student', dest, seed=seed, guidance=text)
            if not score['valid']:
                raise ValueError('Incomplete rollout excluded')
            local = e.classify(spec, dest, score)
            record = dict(sample=str(dest), guidance=str(guide_path), actor_seed=seed,
                local=local, whole_task_passed=score['passed'], score=score)
            records.append(record)
            c.d.save(dest.parent/'all-valid-trials.json', records)
            desired = (score['local_accepted'] and local['result']=='correct' and
                score['passed'] and score['unsteered_requests']>0) if role=='teacher_structured' else local['result']=='wrong'
            if desired:
                return dict(found=True, selected=record, history=records)
        except Exception as exc:
            c.d.save(dest/'excluded-error.json', dict(error=str(exc),
                traceback=traceback.format_exc(), excluded_not_a_semantic_failure=True))
    return dict(found=False, history=records)


def main():
    reuse.install()
    e.R = R
    R.mkdir(parents=True, exist_ok=True)
    lock=(R/'controller.lock').open('w')
    fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
    spec=next(s for s in reuse.specs() if s['id']=='R02')
    root=reuse.ROOT
    guide_path=root/'cases/R02/guidance/teacher_structured/attempt-1/guidance.json'
    original_request=c.d.load(guide_path.parent/'request.json')
    evidence=json.loads(original_request['messages'][1]['content'])
    feedback=evidence['actual_local_verifier_feedback']
    c.d.save(R/'protocol.json',dict(source='real downstream student error from an existing constructed parent fixture',
        unchanged_task=True, unchanged_replayed_checkpoint=True, thinking=True,
        actor_seeds=SEEDS, maximum_trials_per_branch=len(SEEDS),
        reused_actual_teacher_guidance=str(guide_path),
        same_saved_evidence_and_verifier_feedback_for_all_sources=True,
        guide_contents_never_manually_rewritten=True,
        evaluation_unit='selected local recovery intervention',
        whole_episode_accuracy_claim=False, all_prior_successes_and_failures_preserved=True,
        no_aggregate_or_paired_seed_performance_claim=True))
    ours=samples(spec,'teacher_structured',guide_path)
    c.d.save(R/'cases/R02/teacher_structured/outcome.json',ours)
    controls={}; audits={}
    if ours['found']:
        for index,role in enumerate(c.ROLES[1:]):
            e.emit('guidance',case='R02',variant=role)
            _,path=e.generated_guidance(spec,role,0,feedback)
            request=c.d.load(path.parent/'request.json')
            assert json.loads(request['messages'][1]['content'])==evidence, 'Source evidence must be identical'
            controls[role]=samples(spec,role,path)
            c.d.save(R/'cases/R02'/role/'outcome.json',controls[role])
            hits=sum(v['found'] for v in controls.values())
            if hits>=2 or hits+(2-index)<2:
                break
        failed={k:v['selected'] for k,v in controls.items() if v['found']}
        if len(failed)>=2:
            for role,record in {'teacher_structured':ours['selected'],**failed}.items():
                audits[role]=c.audit_selected(spec,record)
    qualified=ours['found'] and sum(v['found'] for v in controls.values())>=2
    c.d.save(R/'comparison.json',dict(case='R02',qualified=qualified,ours=ours,controls=controls,
        replay_audits=audits,requires_manual_quality_review=qualified,
        evidence_identical_for_all_guidance_sources=True,
        evaluation_unit='selected local intervention, not whole-episode accuracy',
        parent_fixture_constructed=True, initial_failed_action_measured=True))
    e.emit('selected_checkpoint_trials_complete',qualified=qualified)


if __name__=='__main__':
    try:
        main()
    except Exception as exc:
        c.d.save(R/'needs-review.json',dict(error=str(exc),traceback=traceback.format_exc(),
            excluded_not_a_model_failure=True))
        raise
