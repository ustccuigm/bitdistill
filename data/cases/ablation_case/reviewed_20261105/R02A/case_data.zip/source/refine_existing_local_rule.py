"""Finish the two remaining local-guide refinements of a reviewed checkpoint.

Schema descriptions define paper fields, not case-specific answers. All sources
receive identical evidence and the same actual verifier feedback.
"""
import copy
import fcntl
import json
from pathlib import Path
import traceback

import select_existing_checkpoint_trials as selection

reuse, e, c = selection.reuse, selection.e, selection.c
R = Path('/mnt/genming/ablation-local-rule-refinement-20261105')


def main():
    reuse.install()
    e.R = R
    c.R = R/'fixtures'
    R.mkdir(parents=True,exist_ok=True)
    lock=(R/'controller.lock').open('w')
    fcntl.flock(lock,fcntl.LOCK_EX | fcntl.LOCK_NB)
    selection.R=R
    c.SCHEMA=copy.deepcopy(c.SCHEMA)
    descriptions=dict(
        precondition='Factual current state BEFORE the next action; do not assume a future reference postcondition.',
        decision_rule='Only the immediate local corrective operation. Do not combine it with downstream actions.',
        expected_transition='Only the observed effect of that immediate operation, not eventual task completion.',
        recovery_check='Verify the local effect, then withdraw this steer before any downstream continuation.')
    for field,description in descriptions.items():
        c.SCHEMA['json_schema']['schema']['properties'][field]['description']=description
    spec=next(s for s in reuse.specs() if s['id']=='R02')
    spec.update(id='R02A',single_next_transition=True)
    case=c.prepare(spec)
    oldcase=reuse.ROOT/'fixtures/cases/R02'
    assert c.d.load(case/'pre-state.json')==c.d.load(oldcase/'pre-state.json')
    assert c.d.load(case/'context.json')==c.d.load(oldcase/'context.json')
    source=reuse.ROOT/'cases/R02'
    last=source/'guidance/teacher_structured/attempt-1/request.json'
    prior=json.loads(c.d.load(last)['messages'][1]['content'])
    feedback=prior['actual_local_verifier_feedback']
    sample=source/'teacher_structured/attempt-1'
    feedback.append(dict(actual_first_execution=c.d.load(sample/'turn-000/execution.json'),
        first_response_check=c.d.load(sample/'local-check.json'),
        subsequent_invalid_output_excluded=True,
        instruction='The first operation repeated the actual rejected decision. Revise only the immediate local rule from the verified contrast.'))
    c.d.save(R/'protocol.json',dict(parent_case='R02',task_and_state_unchanged=True,
        prior_real_guidance_attempts=2,remaining_refinements=2,
        structured_field_definitions=descriptions,source_evidence_shared=True,
        actor_seeds=selection.SEEDS,thinking=True,
        guides_and_actions_are_real_model_outputs=True,
        all_source_results_retained=True,selected_intervention_not_aggregate_performance=True))
    ours=None;chosen_evidence=None
    for attempt in [2,3]:
        e.emit('remaining_local_refinement',case=spec['id'],attempt=attempt)
        _,gpath=e.generated_guidance(spec,'teacher_structured',attempt,feedback)
        selection.R=R/f'method-refinement-{attempt}'
        result=selection.samples(spec,'teacher_structured',gpath)
        c.d.save(R/f'method-refinement-{attempt}.json',result)
        if result['found']:
            ours=result
            chosen_evidence=json.loads(c.d.load(gpath.parent/'request.json')['messages'][1]['content'])
            break
        for record in result['history']:
            feedback.append(dict(actual_first_execution=c.d.load(Path(record['sample'])/'turn-000/execution.json'),
                first_response_check=c.d.load(Path(record['sample'])/'local-check.json'),
                task_verifier=record['score']['goal'],
                instruction='Use the actual rejection to refine the next local response only.'))
    controls={};audits={}
    if ours:
        selection.R=R/'control-trials'
        c.d.save(R/'cases'/spec['id']/'teacher_structured/outcome.json',ours)
        feedback=chosen_evidence['actual_local_verifier_feedback']
        for index,role in enumerate(c.ROLES[1:]):
            _,gpath=e.generated_guidance(spec,role,0,feedback)
            actual=json.loads(c.d.load(gpath.parent/'request.json')['messages'][1]['content'])
            assert actual==chosen_evidence
            controls[role]=selection.samples(spec,role,gpath)
            c.d.save(R/'cases'/spec['id']/role/'outcome.json',controls[role])
            hits=sum(v['found'] for v in controls.values())
            if hits>=2 or hits+(2-index)<2:break
        if sum(v['found'] for v in controls.values())>=2:
            for role,record in {'teacher_structured':ours['selected'],
                    **{k:v['selected'] for k,v in controls.items() if v['found']}}.items():
                audits[role]=c.audit_selected(spec,record)
    qualified=bool(ours and sum(v['found'] for v in controls.values())>=2)
    c.d.save(R/'comparison.json',dict(case=spec['id'],qualified=qualified,ours=ours,
        controls=controls,replay_audits=audits,manual_quality_review_required=qualified,
        same_evidence_for_every_source=True,whole_episode_accuracy_claim=False))
    e.emit('remaining_refinement_complete',qualified=qualified)


if __name__=='__main__':
    try:main()
    except Exception as exc:
        c.d.save(R/'needs-review.json',dict(error=str(exc),traceback=traceback.format_exc(),
            excluded_not_a_model_failure=True))
        raise
