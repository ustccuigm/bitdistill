"""Re-intervene at real downstream student errors from existing measured cases.

Parent fixtures were explicitly constructed. The new prefix, mistaken decision,
and accepted steer memory are real saved model outputs, never handwritten ones.
"""
import argparse
import copy
import fcntl
from pathlib import Path
import traceback

import controlled_local_ablation as experiment
from constructed_ablation_designs import call

c = experiment.c
ROOT = Path('/mnt/genming/ablation-existing-recovery-checkpoints-v3-20261105')
PARENTS = Path('/mnt/genming/ablation-constructed-cases-20261104/cases')
MEASURED = Path('/mnt/genming/ablation-constructed-local-20261104/cases')


def specs():
    values = []
    for parent, identifier, title, local, oracle in [
        ('C02', 'R02', '备份副本已建立：进入归档目录再重命名', 'enter_archive_for_rename',
            [call('cd', folder='archive'), call('mv', source='research_notes.txt', destination='research_backup.txt')]),
        ('C06', 'R06', '归档目录已建立：按目录参数复制指定报告', 'copy_first_visible_report',
            [call('cp', source='a.txt', destination='Archive'), call('cp', source='b.txt', destination='Archive')]),
    ]:
        spec = copy.deepcopy(c.d.load(PARENTS/parent/'design.json'))
        selected = c.d.load(MEASURED/parent/'teacher_structured/outcome.json')['selected']
        sample = Path(selected['sample'])
        failure = sample/'turn-001/response.json'
        events = c.d.load(failure.parent/'execution.json')
        assert len(events) == 1 and events[0]['semantic_tool_error']
        if parent == 'C02':
            spec['goal']['mutable'] = ['/alex/workspace/archive/research_notes.txt']
        alignment = c.d.load(PARENTS/parent/'reference-alignment.json')
        spec.update(id=identifier, title=title, local=local, oracle=oracle,
            proposal=dict(tool=events[0]['tool'], arguments=events[0]['arguments']),
            replay_real_prefix=[str(sample/'turn-000/response.json')],
            accepted_memory_source=selected['guidance'],
            reuse_fixed_teacher_reference=alignment['teacher_source'],
            observed_failure_response=str(failure), parent_case=str(PARENTS/parent),
            aligned_reference_only=True,
            causal_transition_summary=True,
            mechanism='A real student error after a locally accepted correction: '+spec['mechanism'])
        values.append(spec)
    return values


def install():
    c.R = ROOT/'fixtures'
    experiment.R = ROOT
    c.status = experiment.emit
    old_gate, old_prepare = c.local_gate, c.prepare

    def gate(spec, current, initial, events):
        if spec['local'] == 'enter_archive_for_rename':
            return (current['cwd'] == '/alex/workspace/archive' and
                current['files'].get('/alex/workspace/research_notes.txt') ==
                initial['files']['/alex/workspace/research_notes.txt'])
        if spec['local'] == 'copy_first_visible_report':
            return (current['files'].get('/alex/reports/Archive/a.txt') ==
                initial['files']['/alex/reports/a.txt'] and
                c.evaluate(spec, current, initial, events, '')['checks']['protected_files_preserved'])
        return old_gate(spec, current, initial, events)

    def prepare(spec):
        out = old_prepare(spec)
        env, allowed, messages, _ = c.fixture(spec)
        initial = c.state(env)
        source = Path(spec['observed_failure_response'])
        raw = c.d.load(source)
        expected = c.d.load(source.parent/'execution.json')
        actual = c.execute(env, allowed, messages, c.d.parse_message(raw['choices'][0]['message']), 1,
            'reexecution of an actual saved downstream student mistake')
        assert len(actual) == len(expected)
        for a, b in zip(actual, expected):
            assert all(a[k] == b[k] for k in ['tool', 'arguments', 'response', 'before', 'after'])
        receipt = dict(verified=True, actual_model_generated_failure=True,
            source_response=str(source), source_sha256=c.d.sha(raw),
            exact_pre_state_sha256=c.d.sha(initial), execution=actual,
            error_state_replayed_exactly=True)
        c.d.save(out/'observed-failure-replay.json', receipt)
        provenance = c.d.load(out/'provenance.json')
        provenance.update(source='new checkpoint derived from real student execution on an explicitly constructed parent fixture',
            parent_case=spec['parent_case'],
            synthetic_elements=['parent task', 'parent initial fixture', 'parent diagnostic prefix'],
            actual_generated_elements=['accepted student prefix', 'accepted steer memory', 'failed student decision', 'fixed teacher reference'],
            observed_failure_receipt=str(out/'observed-failure-replay.json'))
        c.d.save(out/'provenance.json', provenance)
        counterexample = c.d.load(out/'counterexample.json')
        counterexample.update(origin='actual saved model decision, independently reexecuted at the same state',
            not_model_generated=False, source_response=str(source))
        c.d.save(out/'counterexample.json', counterexample)
        return out

    c.local_gate, c.prepare = gate, prepare
def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--validate-only', action='store_true')
    args = parser.parse_args()
    install()
    ROOT.mkdir(parents=True, exist_ok=True)
    lock = (ROOT/'controller.lock').open('w')
    fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
    values = specs()
    for spec in values:
        case = c.prepare(spec)
        reference = c.reference(spec, case)
        assert reference['verified']
        assert not c.local_gate(spec, c.d.load(case/'pre-state.json'), c.d.load(case/'pre-state.json'), [])
    c.d.save(ROOT/'validation.json', dict(passed=True, cases=[s['id'] for s in values],
        actual_failure_and_prefix_reexecuted=True, real_teacher_suffix_verified=True))
    if args.validate_only:
        experiment.emit('existing_checkpoint_validation_complete', count=len(values)); return
    c.d.save(ROOT/'protocol.json', dict(source='existing measured near-qualified cases',
        evaluation_unit='local re-intervention; episode outcome recorded separately',
        parent_fixtures_constructed=True, new_mistaken_decisions_actual_model_outputs=True,
        original_task_text_preserved=True, original_source_tools_preserved=True,
        prior_accepted_memory_actual=True, all_branches_same_state_and_reference=True,
        reference_input='only replay-verified teacher suffix from the exact current checkpoint',
        causal_comparison='explicit actual before/failed after/reference after and already accepted prefix effects, identical for all guidance sources',
        thinking=True, actor_seed=c.d.SEED, ours_refinements=4, control_trials=1,
        case_selection_not_aggregate_performance=True))
    for spec in values:
        try:
            experiment.run(spec)
        except Exception as exc:
            c.d.save(ROOT/'cases'/spec['id']/'needs-review.json',
                dict(error=str(exc), traceback=traceback.format_exc(), excluded_not_a_semantic_failure=True))
            experiment.emit('needs_review', case=spec['id'], error=str(exc))
        experiment.report()
    experiment.emit('existing_checkpoint_pass_complete', progress=experiment.report())


if __name__ == '__main__':
    main()
