"""Complete ablations only for reviewed, replay-verified BFCL candidates."""
import copy
import fcntl
import json
import os
from pathlib import Path
import time
import traceback

import discover_bfcl_candidates as d
from ablation_generation_transport import request as external_request

FIELDS = ['precondition', 'decision_rule', 'expected_transition', 'recovery_check']
SCHEMA = dict(type='json_schema', json_schema=dict(name='local_guidance', strict=True,
    schema=dict(type='object', properties={k: dict(type='string') for k in FIELDS},
        required=FIELDS, additionalProperties=False)))
R = d.R


def comparison_status(phase, **extra):
    value = dict(phase=phase, time=time.time(), pid=os.getpid(), **extra)
    d.save(R / 'comparison-active.json', value)
    print(json.dumps(value), flush=True)


d.status = comparison_status


def advisor(case, variant, dest, feedback):
    if (dest / 'guidance.json').exists():
        return d.load(dest / 'guidance.json')['text']
    alignment = d.load(case / 'reference-alignment.json')
    reference = Path(alignment['reference'])
    prompt = ('Compare this actual failed student decision with the aligned, executed first transition '
        'of a successful teacher reference from the exact same restored state and context. '
        'Give one concise, local procedural correction for the next student response. Explain the '
        'specific discrepancy, state precondition, corrective rule, expected effect, and a check for '
        'recovery. Preserve valid context. Do not assert that unexecuted operations have happened. '
        'Do not impersonate the student or provide a plan for the entire remaining task. ')
    prompt += ('Return concise free-form guidance.' if variant == 'teacher_freeform' else
        'Return one JSON object with precondition, decision_rule, expected_transition, recovery_check.')
    scope = d.load(case / 'scope.json')
    evidence = dict(task=scope['original_request'],
        current_context=d.load(case / 'anchor-context.json'),
        failed_decision=d.load(case / 'failed-decision.json')['choices'][0]['message'],
        failed_execution=d.load(case / 'failed-execution.json'),
        aligned_reference_decision=d.load(reference / 'turn-000/response.json')['choices'][0]['message'],
        aligned_reference_execution=d.load(reference / 'turn-000/execution.json'),
        reference_verification=alignment['official_score'], retry_feedback=feedback)
    # Official filesystem checker diagnostics contain Directory/File instances.
    # Match the existing on-disk score serializer when carrying native feedback
    # into refinement, preserving diagnostic text and the original verdict.
    messages = [dict(role='system', content=prompt), dict(role='user', content=json.dumps(evidence, ensure_ascii=False, default=str))]
    if variant == 'external_structured':
        import tomllib
        config = tomllib.loads(Path('/mnt/genming/.codex/config.toml').read_text())
        auth = d.load(Path('/mnt/genming/.codex/auth.json'))
        payload = dict(model='gpt-5.6-sol', messages=messages, max_tokens=32768,
            reasoning_effort=config.get('model_reasoning_effort', 'high'), response_format=SCHEMA)
        raw = external_request(payload, dest, config['openai_base_url'].rstrip('/'),
            {'Authorization': 'Bearer ' + auth['OPENAI_API_KEY']})
    else:
        raw = d.reply(messages, 'student' if variant == 'student_structured' else 'teacher',
            dest, 42, temperature=0.0, schema=None if variant == 'teacher_freeform' else SCHEMA)
    choice = raw['choices'][0]
    text = choice['message'].get('content') or ''
    if choice['finish_reason'] == 'length' or not text.strip():
        raise ValueError('Invalid guidance excluded, not a control failure')
    if variant != 'teacher_freeform':
        parsed = json.loads(text)
        if set(parsed) != set(FIELDS) or not all(isinstance(parsed[k], str) and parsed[k].strip() for k in FIELDS):
            raise ValueError('Invalid structured guidance excluded')
    d.save(dest / 'guidance.json', dict(text=text, variant=variant))
    return text


def branch(case, task, variant):
    root = case / 'ablations' / variant
    if (root / 'outcome.json').exists():
        saved = d.load(root / 'outcome.json')
        if not (variant == 'teacher_structured' and saved.get('passed') and
                not saved.get('local_accepted') and len(saved.get('attempts', [])) < 4):
            return saved
        # A successful diagnostic continuation cannot replace local acceptance.
        # Resume the remaining original refinement budget; sampled attempts stay
        # cached and are neither overwritten nor counted as semantic failures.
        (root / 'outcome.json').rename(root / ('outcome-before-local-budget-resume-' + str(time.time_ns()) + '.json'))
    context = d.load(case / 'anchor-context.json')
    prefix = d.load(case / 'prefix-execution.json')
    target = d.load(case / 'reference-alignment.json')['local_target']
    feedback, scores = [], []
    for attempt in range(4):
        d.status('ablation_branch', task=task.task_id, variant=variant, attempt=attempt)
        dest = root / f'attempt-{attempt}'
        guidance = advisor(case, variant, dest / 'advisor', feedback)
        score = d.rollout(task, 'student', dest / 'student', context, prefix,
            seed=d.SEED, guidance=guidance, local_target=target,
            goal_turn=d.load(case / 'scope.json')['goal_turn'])
        local = d.load(dest / 'student/local-comparison.json')
        restored = d.load(dest / 'student/restore.json')['state']
        # A state-changing reference requires the actual state transition. For
        # a read-only reference the actual tool observation must match as well.
        accepted = local['exact_reference_state'] and (
            target['state'] != restored or local['exact_reference_observation'])
        requests = sorted((dest / 'student').glob('turn-*/request.json'))
        assert len(requests) >= 1 and guidance in d.load(requests[0])['messages'][0]['content']
        for p in requests[1:]:
            assert d.load(p)['messages'][0] == context[0]
        receipt = dict(local_accepted=accepted, comparison_before_continuation=True,
            guidance_only_first_request=True, unsteered_requests=len(requests) - 1,
            continuation_role='accepted method continuation' if accepted else 'diagnostic continuation; not an accepted local correction',
            final_score=score)
        d.save(dest / 'receipt.json', receipt)
        scores.append(receipt)
        # Any complete valid control success is retained and disqualifies a
        # categorical control-failure claim, including alternate valid paths.
        if score['passed'] and (variant != 'teacher_structured' or accepted):
            result = dict(valid=True, passed=True, local_accepted=accepted,
                independent_continuation=len(requests) > 1, attempt=attempt, evidence=str(dest), attempts=scores)
            d.save(root / 'outcome.json', result)
            return result
        if not score['valid']:
            raise ValueError('Unfinished branch excluded, not a model failure')
        feedback.append(dict(guidance=guidance, executed_local_comparison=local,
            final_official_verification=score))
    result = dict(valid=True, passed=any(s['final_score']['passed'] for s in scores),
        local_accepted=False, independent_continuation=False, attempts=scores,
        concrete_execution_error=any(s['final_score']['semantic_errors'] for s in scores))
    d.save(root / 'outcome.json', result)
    return result


def compare(case, task):
    ours = branch(case, task, 'teacher_structured')
    if not (ours['passed'] and ours.get('local_accepted') and ours.get('independent_continuation')):
        d.save(case / 'ablation-outcome.json', dict(qualified=False, task=task.task_id,
            reason='Ours lacks accepted local correction followed by successful unsteered continuation', ours=ours))
        return
    controls = {}
    for variant in ['teacher_freeform', 'external_structured', 'student_structured']:
        controls[variant] = branch(case, task, variant)
        if sum(v['passed'] for v in controls.values()) >= 2:
            break
    failed = [k for k, v in controls.items() if v['valid'] and not v['passed'] and v.get('concrete_execution_error')]
    d.save(case / 'ablation-outcome.json', dict(qualified=False, task=task.task_id,
        pending_final_semantic_review=len(failed) >= 2, ours=ours, controls=controls,
        failed_controls=failed, required_failed_controls=2,
        note='Official mismatches require concrete semantic review; no automatic publication'))


def main():
    lock = (R / 'comparison.lock').open('w')
    fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
    tasks = {t.task_id: t for t in d.load_bfcl_dataset('multi_turn_base', None)}
    while True:
        approved = [p for p in (R / 'cases').glob('*/quality-review.json')
            if d.load(p).get('candidate_approved') and not (p.parent / 'ablation-outcome.json').exists()
            and not (p.parent / 'comparison-excluded-error.json').exists()]
        for review in approved:
            case = review.parent
            try:
                compare(case, tasks[case.name])
            except Exception as exc:
                d.save(case / 'comparison-excluded-error.json', dict(error=str(exc),
                    traceback=traceback.format_exc(), excluded_not_a_model_failure=True))
        qualified = [p for p in (R / 'cases').glob('*/ablation-outcome.json') if d.load(p).get('qualified')]
        d.save(R / 'comparison-status.json', dict(time=time.time(), pid=os.getpid(),
            qualified=len(qualified), target=10, waiting_for_review=not bool(approved)))
        comparison_status('waiting_for_review', qualified=len(qualified), target=10)
        if len(qualified) >= 10:
            return
        time.sleep(20)


if __name__ == '__main__':
    main()
