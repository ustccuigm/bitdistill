"""Bounded transport recovery; preserve every sample and never label it failure.

Local streaming preserves partial reasoning and detects a repeated exact passage.
Recovery sampling applies equally to every local role and only to invalid model
output, never to a valid semantic failure. External transport retries retain the
exact sampling settings. Prompts, task data and acceptance rules are untouched.
"""
import copy
import json
import time
import zlib
from pathlib import Path
import httpx
from rerun_v3 import dump, load


class InvalidGeneration(RuntimeError):
    pass


class DiscoveryBudgetExhausted(RuntimeError):
    """Drop an expensive search proposal without scoring any model failure."""
    pass


def repeated_reasoning(text):
    if len(text) < 10000:
        return False
    tail = text[-8000:]
    return tail.count(text[-256:]) >= 4 or len(zlib.compress(tail.encode())) / len(tail.encode()) < 0.18


def stream_local(payload, dest, endpoint, headers, wall_seconds=7200):
    message = dict(role='assistant', content='', reasoning='')
    calls = {}
    finish = None
    usage = None
    identity = {}
    started = time.monotonic()
    raw = (dest / 'stream.jsonl').open('a')
    try:
        with httpx.stream('POST', endpoint + '/chat/completions', json=payload,
                headers=headers, timeout=httpx.Timeout(connect=30, read=120, write=60, pool=30),
                trust_env=False) as response:
            if response.status_code >= 400:
                response.read()
                dump(dest / 'http-error.json', dict(status=response.status_code, body=response.text))
            response.raise_for_status()
            for line in response.iter_lines():
                if not line.startswith('data:'):
                    continue
                body = line[5:].strip()
                if body == '[DONE]':
                    break
                chunk = json.loads(body)
                raw.write(json.dumps(chunk, ensure_ascii=False) + '\n')
                raw.flush()
                identity.update({k: chunk[k] for k in ['id', 'model', 'created'] if k in chunk})
                if chunk.get('usage'):
                    usage = chunk['usage']
                for choice in chunk.get('choices', []):
                    if choice.get('index', 0) != 0:
                        continue
                    delta = choice.get('delta') or {}
                    message['content'] += delta.get('content') or ''
                    message['reasoning'] += delta.get('reasoning') or delta.get('reasoning_content') or ''
                    for call in delta.get('tool_calls') or []:
                        target = calls.setdefault(call['index'], dict(id='', type='function', function=dict(name='', arguments='')))
                        if call.get('id'):
                            target['id'] = call['id']
                        function = call.get('function') or {}
                        target['function']['name'] += function.get('name') or ''
                        target['function']['arguments'] += function.get('arguments') or ''
                    finish = choice.get('finish_reason') or finish
                if repeated_reasoning(message['reasoning']):
                    raise InvalidGeneration('repeated_exact_reasoning_passage_client_cancelled_not_a_semantic_failure')
                if time.monotonic() - started > wall_seconds:
                    if wall_seconds < 7200:
                        raise DiscoveryBudgetExhausted('candidate_discovery_time_budget_excluded_not_a_model_failure')
                    raise InvalidGeneration('local_generation_wallclock_budget_excluded')
        if calls:
            message['tool_calls'] = [calls[k] for k in sorted(calls)]
        if not finish:
            raise InvalidGeneration('stream_ended_without_native_finish_reason')
        result = dict(identity, object='chat.completion', choices=[dict(index=0, message=message, finish_reason=finish)])
        if usage is not None:
            result['usage'] = usage
        dump(dest / 'response.json', result)
        if finish == 'length':
            raise InvalidGeneration('token_budget_exhausted_not_a_semantic_failure')
        return result
    except Exception:
        dump(dest / 'partial-response.json', dict(native_finish_reason=finish, message=message,
            tool_calls_by_index=calls, usage=usage, client_interrupted=True))
        raise
    finally:
        raw.close()


def request(payload, dest, endpoint, headers=None):
    dest = Path(dest)
    dest.mkdir(parents=True, exist_ok=True)
    local = endpoint.startswith('http://127.0.0.1:3818')
    base = copy.deepcopy(payload)
    policy_file = dest / 'runtime-recovery-policy.json'
    policy = load(policy_file) if policy_file.exists() else {}
    invalid_local = int(policy.get('invalid_generation_retries', 0))
    for attempt in range(3):
        out = dest / 'transport-attempts' / f'attempt-{attempt:02d}'
        # A reload never silently overwrites a prior incomplete transport attempt.
        if out.exists():
            out = out.with_name(out.name + '-' + str(time.time_ns()))
        out.mkdir(parents=True)
        submitted = copy.deepcopy(base)
        if local:
            submitted.update(stream=True, stream_options={'include_usage': True})
            if invalid_local:
                submitted['temperature'] = min(0.2 * invalid_local, 0.6)
                submitted['seed'] = int(base.get('seed', 42)) + invalid_local
        dump(out / 'request.json', submitted)
        dump(dest / 'request.json', submitted)
        dump(dest / 'request-policy.json', dict(base_payload=base, local=local,
            recovery='Same policy for every role: retain normal samples; retry invalid output only',
            selected_attempt=str(out), invalid_generation_retries=invalid_local))
        try:
            if local:
                budget_file = dest / 'generation-budget.json'
                budget = load(budget_file) if budget_file.exists() else {}
                result = stream_local(submitted, out, endpoint, headers,
                    wall_seconds=budget.get('candidate_discovery_wall_seconds', 7200))
            else:
                response = httpx.post(endpoint + '/chat/completions', json=submitted, headers=headers,
                    timeout=httpx.Timeout(connect=30, read=600, write=60, pool=30), trust_env=False)
                if response.status_code >= 400:
                    dump(out / 'http-error.json', dict(status=response.status_code, body=response.text))
                response.raise_for_status()
                result = response.json()
                dump(out / 'response.json', result)
                if result['choices'][0]['finish_reason'] == 'length':
                    raise InvalidGeneration('external_token_budget_exhausted_not_a_semantic_failure')
            dump(dest / 'response.json', result)
            return result
        except DiscoveryBudgetExhausted as exc:
            dump(out / 'excluded-error.json', dict(type=type(exc).__name__, error=str(exc),
                excluded_not_a_semantic_failure=True, phase='candidate_discovery'))
            raise
        except (InvalidGeneration, httpx.TransportError, httpx.HTTPStatusError) as exc:
            dump(out / 'excluded-error.json', dict(type=type(exc).__name__, error=str(exc),
                excluded_not_a_semantic_failure=True))
            if isinstance(exc, httpx.HTTPStatusError) and exc.response.status_code not in [408, 429, 500, 502, 503, 504]:
                raise
            if isinstance(exc, InvalidGeneration) and local:
                invalid_local += 1
                dump(policy_file, dict(invalid_generation_retries=invalid_local, reason=str(exc)))
            if attempt == 2:
                raise
            time.sleep(3 * (attempt + 1))
