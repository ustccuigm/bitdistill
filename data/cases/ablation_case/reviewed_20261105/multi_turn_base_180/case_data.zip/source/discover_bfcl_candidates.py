"""Find genuine first-user-turn BFCL failures using the original MCP protocol.

Only emits candidates, never calls transport errors or strict-grader differences
qualified ablations. Source tasks and official checkers are read-only.
"""
import argparse
import ast
import copy
import fcntl
import hashlib
import inspect
import json
import os
from pathlib import Path
import re
import sys
import time
import traceback
from concurrent.futures import ThreadPoolExecutor

B = Path('/mnt/genming/Arctic-AWM-BitDistiller-full')
VENDOR = B / 'arctic_quant/vendor/agent-world-model'
sys.path[:0] = [str(VENDOR), str(VENDOR / '.venv/lib/python3.12/site-packages'),
    str(VENDOR / 'mcp-adapted-bench'), str(VENDOR / 'mcp-adapted-bench/third_party/bfcl-original'),
    '/mnt/genming/case-rerun-20261103']
import httpx
from mcp_adapted_bench.bfcl.dataset import load_bfcl_dataset
from mcp_adapted_bench.bfcl.environment import BFCLEnvironment
from bfcl_eval.eval_checker.multi_turn_eval.multi_turn_checker import state_checker, response_checker
from ablation_generation_transport import stream_local

R = Path('/mnt/genming/ablation-bfcl-discovery-20261104')
ENDPOINTS = {'teacher': 'http://127.0.0.1:38281/v1', 'student': 'http://127.0.0.1:38282/v1'}
WEIGHTS = {'teacher': str(B / 'arctic_quant/common/model/Arctic-AWM-8B'),
    'student': str(B / 'arctic_quant/w4a16/turn_level/common/initial-unified-awq-w4a16-g64')}
SEED = 71782826


def save(p, value):
    p.parent.mkdir(parents=True, exist_ok=True)
    tmp = p.with_name(p.name + '.tmp-' + str(os.getpid()) + '-' + str(time.time_ns()))
    tmp.write_text(json.dumps(value, ensure_ascii=False, indent=2, default=str) + '\n')
    tmp.replace(p)


def load(p):
    return json.loads(p.read_text())


def qualified_count():
    policy = R / 'selection-policy.json'
    if policy.exists():
        metric = load(policy).get('selection_progress')
        if metric and Path(metric).exists():
            return load(Path(metric)).get('qualified', 0)
    return sum(bool(load(p).get('qualified')) for p in (R / 'cases').glob('*/ablation-outcome.json'))


def status(phase, **extra):
    value = dict(phase=phase, time=time.time(), pid=os.getpid(), **extra)
    save(R / 'status.json', value)
    print(json.dumps(value), flush=True)


def canonical(obj):
    if isinstance(obj, dict):
        return {str(k): canonical(v) for k, v in sorted(obj.items(), key=lambda x: str(x[0]))}
    if isinstance(obj, (list, tuple)):
        return [canonical(x) for x in obj]
    if isinstance(obj, set):
        return sorted([canonical(x) for x in obj], key=str)
    if obj is None or isinstance(obj, (str, bool, float, int)):
        return obj
    # BFCL filesystem has parent cycles. Its official equality ignores parent
    # pointers and private modification timestamps as well.
    return {'class': type(obj).__name__, 'attributes': {
        k: canonical(v) for k, v in vars(obj).items()
        if not k.startswith('_') and k != 'parent'}}


def snapshot(env):
    return canonical(env._tool_instances)


def sha(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True, ensure_ascii=False, default=str).encode()).hexdigest()


def fresh(task):
    env = BFCLEnvironment(copy.deepcopy(task), None)
    allowed = {f['name'].split('.')[-1] for f in task.function}
    return env, allowed


def catalog(env):
    ts = env.get_mcp_tools()[1:]
    return 'Available MCP Tools (' + str(len(ts)) + ' tools):\n' + '=' * 80 + '\n\n' + env._format_new_tools_info(ts).strip()


def gold_calls(task):
    calls = []
    env, allowed = fresh(task)
    for text in task.ground_truth[0]:
        node = ast.parse(text, mode='eval').body
        if not isinstance(node, ast.Call):
            raise ValueError('Unsupported trusted gold expression')
        name = node.func.id if isinstance(node.func, ast.Name) else node.func.attr
        kwargs = {k.arg: ast.literal_eval(k.value) for k in node.keywords}
        if node.args:
            instance = env._tool_instances[env._method_to_instance[name]]
            kwargs = dict(inspect.signature(getattr(instance, name)).bind(
                *[ast.literal_eval(a) for a in node.args], **kwargs).arguments)
        calls.append((name, kwargs))
    return calls


def invoke(env, allowed, name, args):
    name = name.removeprefix('mcp_tool_').split('.')[-1]
    if name not in allowed or name.startswith('_'):
        return {'error': 'Unknown or unavailable advertised tool: ' + name}
    instance = env._tool_instances[env._method_to_instance[name]]
    # JSON arguments invoke only explicitly advertised mock methods; no eval.
    try:
        return getattr(instance, name)(**args)
    except (TypeError, ValueError, KeyError) as exc:
        return {'error': str(exc)}


def expected(task, goal_turn=0):
    env, allowed = fresh(task)
    results = []
    for user_turn in range(goal_turn + 1):
        scoped = copy.deepcopy(task)
        scoped.ground_truth = [task.ground_truth[user_turn]]
        results = [copy.deepcopy(invoke(env, allowed, n, a)) for n, a in gold_calls(scoped)]
        if any(is_error(x) for x in results):
            raise ValueError('Original gold does not execute successfully')
    if any(is_error(x) for x in results):
        raise ValueError('Original gold does not execute successfully')
    return env, results


def is_error(result):
    return (isinstance(result, dict) and bool(result.get('error'))) or (
        isinstance(result, str) and result.lower().startswith(('error:', 'error during')))


def parse_message(raw):
    msg = copy.deepcopy(raw)
    if not msg.get('tool_calls'):
        calls = []
        for i, part in enumerate(re.findall(r'<tool_call>(.*?)</tool_call>', msg.get('content') or '', re.S)):
            call = json.loads(part)
            calls.append({'id': 'bfcl_' + str(i), 'type': 'function',
                'function': {'name': call['name'], 'arguments': json.dumps(call.get('arguments') or {})}})
        if calls:
            msg['tool_calls'] = calls
    # Match the original published case's MCP history: generated reasoning is
    # retained as assistant content; advisor text is never added to that history.
    reasoning = msg.get('reasoning') or msg.get('reasoning_content')
    if reasoning:
        msg['content'] = '<think>' + reasoning + '</think>\n' + (msg.get('content') or '')
    return msg


def reply(messages, role, dest, seed, guidance='', temperature=None, schema=None):
    if (dest / 'response.json').exists():
        res = load(dest / 'response.json')
        if res['choices'][0]['finish_reason'] == 'length':
            raise ValueError('Truncated output excluded, not a model error')
        return res
    submitted = [{'role': m['role'], 'content': m.get('content') or ''} for m in messages]
    if guidance:
        submitted[0]['content'] += '\n\nLocal steering for this response only:\n' + guidance
    payload = dict(model='case-model', messages=submitted, temperature=(0.0 if role == 'teacher' else .6)
        if temperature is None else temperature, top_p=.95, top_k=20, seed=seed,
        max_tokens=32768, repetition_penalty=1.2, min_tokens=16,
        chat_template_kwargs={'enable_thinking': True})
    if schema:
        payload['response_format'] = schema
    endpoint = ENDPOINTS[role]
    count = httpx.post(endpoint.removesuffix('/v1') + '/tokenize',
        json={k: payload[k] for k in ['model', 'messages', 'chat_template_kwargs']},
        timeout=30, trust_env=False)
    count.raise_for_status()
    tokens = count.json()
    available = tokens['max_model_len'] - tokens['count'] - 64
    if available < 1024:
        raise ValueError('Context capacity excluded, not a model error')
    payload['max_tokens'] = min(32768, available)
    dest.mkdir(parents=True, exist_ok=True)
    save(dest / 'request.json', payload)
    save(dest / 'budget.json', dict(thinking=True, max_requested=32768,
        effective=payload['max_tokens'], prompt_tokens=tokens['count']))
    attempt = dest / ('transport-' + str(time.time_ns()))
    attempt.mkdir()
    wire = dict(payload, stream=True, stream_options={'include_usage': True})
    save(attempt / 'request.json', wire)
    res = stream_local(wire, attempt, endpoint, None, wall_seconds=900)
    save(dest / 'response.json', res)
    return res


def execute(env, allowed, messages, msg, turn):
    messages.append(msg)
    calls = msg.get('tool_calls') or []
    if len(calls) > 1:
        raise ValueError('Multiple calls violate original one-call MCP protocol; excluded')
    events = []
    for call in calls:
        function = call['function']
        args = function.get('arguments') or {}
        args = json.loads(args) if isinstance(args, str) else args
        before = snapshot(env)
        if function['name'] == 'list_tools':
            name, arguments, result = 'list_tools', {}, catalog(env)
        elif function['name'] == 'call_tool':
            name = args.get('tool_name', '').removeprefix('mcp_tool_')
            arguments = args.get('arguments') or {}
            arguments = json.loads(arguments) if isinstance(arguments, str) else arguments
            # Malformed invocation is a model/adapter incompatibility to review;
            # do not silently coerce or dispatch an unadvertised method.
            if not isinstance(arguments, dict):
                raise ValueError('Non-object arguments excluded')
            try:
                result = invoke(env, allowed, name, arguments)
            except (TypeError, ValueError, KeyError) as exc:
                result = {'error': str(exc)}
        else:
            raise ValueError('Unknown MCP wrapper; excluded for protocol review')
        # Some official tools return references to mutable environment dicts
        # (e.g. doorStatus). Freeze the observation at execution time so later
        # actions cannot retroactively rewrite the saved evidence.
        result = copy.deepcopy(result)
        event = dict(turn=turn, tool=name, arguments=arguments, response=result,
            before=before, after=snapshot(env), semantic_tool_error=is_error(result))
        events.append(event)
        wrapped = {'success': True, 'data': [{'type': 'text',
            'text': json.dumps(result) if not isinstance(result, str) else result}]}
        messages.append(dict(role='tool', tool_call_id=call['id'], content=json.dumps(wrapped)))
    return events


def rollout(task, role, out, context=None, prefix_events=None, seed=SEED, guidance='', local_target=None, goal_turn=0):
    if (out / 'score.json').exists():
        score = load(out / 'score.json')
        assert score.get('goal_turn', 0) == goal_turn
        return score
    env, allowed = fresh(task)
    # Restore real state by deterministic re-execution of the saved student prefix.
    prefix_events = prefix_events or []
    for event in prefix_events:
        if event['tool'] == 'list_tools':
            continue
        before = snapshot(env)
        result = invoke(env, allowed, event['tool'], event['arguments'])
        assert before == event['before'] and canonical(result) == canonical(event['response'])
        assert snapshot(env) == event['after']
    messages = copy.deepcopy(context) if context else [dict(role='system', content=env.get_system_prompt()),
        dict(role='user', content=env.get_initial_user_message())]
    save(out / 'context.json', messages)
    save(out / 'restore.json', dict(verified=True, state=snapshot(env),
        state_sha256=sha(snapshot(env)), context_sha256=sha(messages), replayed=len(prefix_events)))
    gt_env, gt_results = expected(task, goal_turn)
    all_events, finish = copy.deepcopy(prefix_events), 'turn_limit'
    for turn in range(24):
        turn_dir = out / f'turn-{turn:03d}'
        save(turn_dir / 'pre-context.json', messages)
        raw = reply(messages, role, turn_dir, seed + turn, guidance if turn == 0 else '')
        msg = parse_message(raw['choices'][0]['message'])
        save(turn_dir / 'message.json', msg)
        events = execute(env, allowed, messages, msg, turn)
        for event in events:
            event['user_turn'] = goal_turn
        all_events.extend(events)
        save(turn_dir / 'execution.json', events)
        save(out / 'execution.json', all_events)
        save(out / 'trajectory.json', dict(messages=messages, task=task.task_id))
        if turn == 0 and local_target is not None:
            # Receipt is written before any unsteered continuation. A mismatch
            # alone is never sufficient evidence that a baseline is wrong.
            save(out / 'local-comparison.json', dict(checked_before_continuation=True,
                exact_reference_state=snapshot(env) == local_target['state'],
                exact_reference_observation=canonical([e['response'] for e in events]) == local_target['responses'],
                actual_state=snapshot(env), target=local_target))
        if not msg.get('tool_calls'):
            finish = 'final_response'
            break
    actual = [str(e['response']) for e in all_events if e['tool'] != 'list_tools']
    state = state_checker(env._tool_instances, gt_env._tool_instances)
    response = response_checker(actual, [str(x) for x in gt_results], goal_turn)
    valid = finish == 'final_response'
    score = dict(valid=valid, passed=valid and state['valid'] and response['valid'],
        finish=finish, official_state=state, official_response=response,
        semantic_errors=[dict(tool=e['tool'], arguments=e['arguments'], response=e['response'])
            for e in all_events[len(prefix_events):] if e.get('user_turn', 0) == goal_turn and e['semantic_tool_error']],
        goal_turn=goal_turn,
        scope=f'User turn {goal_turn}; earlier turns must have passed unchanged original checkers',
        guidance_injected_only_first_request=bool(guidance), teacher=role == 'teacher')
    save(out / 'score.json', score)
    # Fresh and cached scores share the same JSON-safe boundary. Native checker
    # diagnostics may contain custom mock filesystem objects.
    return load(out / 'score.json')


def candidate(task, out):
    context, prefix, goal_turn = None, [], 0
    for goal_turn in range(len(task.question)):
        status('student_discovery', task=task.task_id, goal_turn=goal_turn)
        student = out / ('student' if goal_turn == 0 else f'student-user-{goal_turn:02d}')
        score = rollout(task, 'student', student, context, prefix, goal_turn=goal_turn)
        if not score['valid']:
            return dict(candidate=False, reason='Incomplete output excluded', goal_turn=goal_turn)
        if not score['passed']:
            break
        if goal_turn == len(task.question) - 1:
            return dict(candidate=False, reason='Student already passed every user turn')
        context = load(student / 'trajectory.json')['messages']
        context += copy.deepcopy(task.question[goal_turn + 1])
        prefix = load(student / 'execution.json')
    events = load(student / 'execution.json')
    # Strong first screen: actual failed tool invocation and failure to complete.
    # Strict state mismatch alone is not an interesting or established error.
    error = next((e for e in events if e.get('user_turn', 0) == goal_turn and e['semantic_tool_error']), None)
    if not error:
        review_path = out / 'failure-review.json'
        if not review_path.exists():
            return dict(candidate=False, reason='No concrete failed tool execution; manual semantic review required',
                goal_turn=goal_turn, source_student=str(student))
        review = load(review_path)
        if not review.get('approved') or review['goal_turn'] != goal_turn:
            raise ValueError('Semantic failure review does not match the actual failed turn')
        turn = review['anchor_turn']
        error = dict(turn=turn, user_turn=goal_turn, kind='reviewed_goal_failure',
            actual_model_decision=load(student / f'turn-{turn:03d}' / 'response.json')['choices'][0]['message'],
            original_official_score=score, semantic_explanation=review['explanation'],
            evidence=review['evidence'])
    turn = error['turn']
    context = load(student / f'turn-{turn:03d}' / 'pre-context.json')
    prefix = [e for e in events if e.get('user_turn', 0) < goal_turn or
        (e.get('user_turn', 0) == goal_turn and e['turn'] < turn)]
    save(out / 'anchor-context.json', context)
    save(out / 'prefix-execution.json', prefix)
    save(out / 'failed-decision.json', load(student / f'turn-{turn:03d}' / 'response.json'))
    save(out / 'failed-execution.json', error)
    save(out / 'scope.json', dict(goal_turn=goal_turn, source_student=str(student),
        original_request=task.question[goal_turn], previously_passed_user_turns=list(range(goal_turn))))
    # Temperature-zero valid failures are not resampled with different seeds:
    # that repeats the same ineffective reference instead of finding new cases.
    for attempt in range(1):
        status('same_anchor_teacher_reference', task=task.task_id, attempt=attempt)
        dest = out / 'teacher' / f'attempt-{attempt}'
        teacher = rollout(task, 'teacher', dest, context, prefix, seed=SEED + attempt, goal_turn=goal_turn)
        if teacher['passed']:
            # Reference replay is checked on fresh official instances, including
            # the complete saved prefix. No model actions are fabricated.
            env, allowed = fresh(task)
            for e in load(dest / 'execution.json'):
                assert snapshot(env) == e['before']
                actual = catalog(env) if e['tool'] == 'list_tools' else invoke(env, allowed, e['tool'], e['arguments'])
                assert canonical(actual) == canonical(e['response']) and snapshot(env) == e['after']
            first = load(dest / 'turn-000/execution.json')
            if not first or first[0]['tool'] == 'list_tools':
                return dict(candidate=False, reason='No useful aligned teacher first action')
            ref = dict(state=first[-1]['after'], responses=canonical([e['response'] for e in first]))
            save(out / 'reference-alignment.json', dict(verified=True, exact_state_replay=True,
                reference=str(dest), restored_context_sha256=sha(context), local_target=ref,
                official_score=teacher))
            return dict(candidate=True, pending_semantic_review=True, task=task.task_id,
                concrete_error=error, reference=str(dest), qualified=False,
                goal_turn=goal_turn,
                scope='One original user turn; all prior turns passed unchanged official checkers')
    return dict(candidate=False, reason='No successful same-anchor teacher reference')


def validate():
    tasks = load_bfcl_dataset('multi_turn_base', None)
    original = load(Path('/mnt/genming/workspace-case-20261028/mcp_protocol/context_before.json'))
    task = next(t for t in tasks if t.task_id == 'multi_turn_base_22')
    env, allowed = fresh(task)
    assert env.get_system_prompt() == original[0]['content']
    assert env.get_initial_user_message() == original[1]['content']
    assert catalog(env) == original[-1]['content']
    gt, results = expected(task)
    assert results[-1]['file_content'] == 'Initial analysis content.'
    assert state_checker(gt._tool_instances, copy.deepcopy(gt._tool_instances))['valid']
    save(R / 'adapter-validation.json', dict(system_prompt_identical=True,
        user_prompt_identical=True, tool_catalog_identical=True, original_gold_executed=True,
        source_task_unchanged=True, model_text_never_evaluated=True))
    print('ORIGINAL ADAPTER VALIDATED', flush=True)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--limit', type=int, default=30)
    parser.add_argument('--validate-only', action='store_true')
    args = parser.parse_args()
    R.mkdir(parents=True, exist_ok=True)
    lock = (R / 'producer.lock').open('w')
    fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
    validate()
    if args.validate_only:
        return
    for role, endpoint in ENDPOINTS.items():
        models = httpx.get(endpoint + '/models', timeout=10, trust_env=False).json()['data']
        assert models[0]['root'] == WEIGHTS[role]
    save(R / 'run-manifest.json', dict(models=WEIGHTS, endpoints=ENDPOINTS,
        thinking=True, actor_temperature=.6, advisor_temperature=0, top_p=.95, top_k=20,
        repetition_penalty=1.2, max_tokens=32768, seed=SEED, target=10,
        scope='Earliest failed original user turn, retaining all earlier real interactions and state',
        selection='Actual student tool error and unsuccessful original goal, followed by verified same-anchor teacher success',
        no_qualified_ablations_from_discovery_alone=True))
    tasks = load_bfcl_dataset('multi_turn_base', None)
    preferred = [16, 35, 38, 46, 18, 31, 5, 27, 44, 13, 20, 30, 0, 2, 6, 7, 10, 12, 14, 36]
    history = R / 'historical-priority-index.json'
    historical = [x['task'] for x in load(history)] if history.exists() else []
    by_id = {t.task_id: t for t in tasks}
    selected = [by_id[k] for k in historical if k != 'multi_turn_base_22']
    selected += [tasks[i] for i in preferred if tasks[i] not in selected]
    # Prefer real multi-step requests over more one-call directory listings.
    remainder = [t for t in tasks if t not in selected and t.task_id != 'multi_turn_base_22']
    remainder.sort(key=lambda t: (len(t.ground_truth[0]) < 2,
        -sum(w in t.question[0][0]['content'].lower() for w in ['before', 'after', 'if ', 'ensure', 'then'])))
    selected += remainder
    for task in selected[:args.limit]:
        if qualified_count() >= 10:
            status('qualified_target_reached', target=10)
            return
        out = R / 'cases' / task.task_id
        if (out / 'discovery-outcome.json').exists():
            continue
        save(out / 'task.json', vars(task))
        try:
            result = candidate(task, out)
            save(out / 'discovery-outcome.json', result)
            status('case_screened', task=task.task_id, candidate=result.get('candidate'), reason=result.get('reason'))
        except Exception as exc:
            save(out / 'excluded-error.json', dict(type=type(exc).__name__, error=str(exc),
                traceback=traceback.format_exc(), excluded_not_a_model_failure=True))
            status('case_excluded', task=task.task_id, error=str(exc))
        outcomes = [load(p) for p in (R / 'cases').glob('*/discovery-outcome.json')]
        save(R / 'progress.json', dict(screened=len(outcomes),
            candidates=sum(bool(d.get('candidate')) for d in outcomes),
            qualified=qualified_count(),
            candidate_paths=[str(p.parent) for p in (R / 'cases').glob('*/discovery-outcome.json') if load(p).get('candidate')],
            pending_ablation=True, time=time.time()))
    status('batch_finished')


if __name__ == '__main__':
    main()
