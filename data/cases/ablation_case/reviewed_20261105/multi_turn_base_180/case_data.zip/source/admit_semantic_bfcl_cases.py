"""Manually reviewed semantic failures that the API-error-only screen missed.

No original benchmark item or test file is edited. References and all advisor
and learner outputs are measured model generations, with bounded reference repair.
"""
import argparse
import copy
import fcntl
from pathlib import Path
import shutil
import time
import traceback

import targeted_bfcl_local_backfill as x

d=x.d
R=Path('/mnt/genming/ablation-reviewed-semantic-backfill-20261105')
REVIEWS={
    'multi_turn_base_10':dict(anchor_tool='mkdir',wanted=['cd'],
        reason='Created Projects in /alex rather than the explicitly requested workspace directory, then falsely reported success.'),
    'multi_turn_base_74':dict(anchor_tool=None,wanted=['round_number','fillFuelTank'],
        reason='Converted the requested fuel amount but never refueled the vehicle, despite claiming the requested action was done.'),
    'multi_turn_base_99':dict(anchor_tool=None,wanted=['set_navigation'],
        reason='Found and reported the nearest tire shop but did not navigate there after the user requested a detour conditional on pressure below 37.'),
    'multi_turn_base_12':dict(anchor_tool='touch',wanted=['cd'],
        reason='Searched Documents but created summary.txt in /alex and falsely claimed it was created inside Documents.'),
    'multi_turn_base_61':dict(anchor_tool=None,wanted=['fillFuelTank','estimate_drive_feasibility_by_mileage'],
        reason='Reported insufficient range but did not add the requested minimum integer amount of fuel.'),
    'multi_turn_base_58':dict(anchor_tool='fillFuelTank',wanted=['fillFuelTank','gallon_to_liter'],
        reason='Confused a separate 30-gallon drum conversion with the amount needed to fill the vehicle tank and left the tank below full.'),
    'multi_turn_base_95':dict(anchor_tool=None,wanted=['list_tools'],
        reason='Claimed no vehicle tools were available without discovering the domain tools through the available list_tools wrapper.'),
}


def prepare_checkpoint(task):
    case=R/'cases'/task.task_id
    if (case/'semantic-admission.json').exists():return case
    parent=x.BASE/task.task_id
    outcome=d.load(parent/'discovery-outcome.json')
    source=Path(outcome['source_student'])
    score=d.load(source/'score.json')
    assert score['valid'] and not score['passed'] and x.substantive_state_failure(score)
    goal=outcome.get('goal_turn',score['goal_turn'])
    events=d.load(source/'execution.json');review=REVIEWS[task.task_id]
    if review['anchor_tool']:
        anchor=next(e['turn'] for e in events if e.get('user_turn',0)==goal and e['tool']==review['anchor_tool'])
    else:
        path=sorted(source.glob('turn-*/response.json'))[-1]
        anchor=int(path.parent.name.split('-')[-1])
        assert not d.parse_message(d.load(path)['choices'][0]['message']).get('tool_calls')
    prefix=[e for e in events if e.get('user_turn',0)<goal or (e.get('user_turn',0)==goal and e['turn']<anchor)]
    context=d.load(source/f'turn-{anchor:03d}/pre-context.json')
    failed=d.load(source/f'turn-{anchor:03d}/response.json')
    d.save(case/'task.json',d.load(parent/'task.json'))
    d.save(case/'scope.json',dict(goal_turn=goal,source_student=str(source),
        original_request=task.question[goal],previously_passed_user_turns=list(range(goal))))
    d.save(case/'anchor-context.json',context)
    d.save(case/'prefix-execution.json',prefix)
    d.save(case/'failed-decision.json',failed)
    d.save(case/'failed-execution.json',dict(kind='reviewed actual semantic failure',
        source_response=str(source/f'turn-{anchor:03d}/response.json'),
        execution=d.load(source/f'turn-{anchor:03d}/execution.json'),
        substantive_error=review['reason'],original_official_score=score))
    # This replays the actual prefix into fresh original native tool instances.
    env,_,_,_=x.restore(task,case)
    d.save(case/'semantic-admission.json',dict(approved_candidate=True,not_yet_a_qualified_ablation=True,
        reason=review['reason'],source=str(parent),anchor_turn=anchor,
        actual_prefix_replayed=True,pre_state=d.snapshot(env),
        original_task_text_initial_config_and_checkers_unchanged=True))
    return case


def prepare(task):
    case=prepare_checkpoint(task)
    if (case/'reference-alignment.json').exists():return case
    scope=d.load(case/'scope.json');goal=scope['goal_turn']
    context=d.load(case/'anchor-context.json');prefix=d.load(case/'prefix-execution.json')
    source=case/'teacher-reference'
    x.emit('reference_generation',task=task.task_id)
    score=d.rollout(task,'teacher',source,context,prefix,seed=42,goal_turn=goal)
    assisted=False
    if score['valid'] and not score['passed']:
        # One actual verifier-directed reference repair, with raw failure retained.
        source=case/'teacher-reference-verifier-repair'
        text=('A previous attempt from this exact checkpoint failed the unchanged original native task verifier. '
            'Complete the original requested operation from this same state. Do not merely describe or '
            'recommend an operation which the user requested you perform. Actual previous verifier report:\n'+
            __import__('json').dumps(score,ensure_ascii=False,default=str))
        score=d.rollout(task,'teacher',source,context,prefix,seed=42,guidance=text,goal_turn=goal)
        assisted=True
    if not score['valid'] or not score['passed']:
        raise ValueError('Teacher reference and its bounded verifier repair did not pass; candidate retained without qualification')
    paths=sorted(source.glob('turn-*/response.json'))
    cuts=[]
    for index,path in enumerate(paths):
        events=d.load(path.parent/'execution.json')
        if any(e['tool'] in REVIEWS[task.task_id]['wanted'] and not e['semantic_tool_error'] for e in events):cuts.append(index)
    for cut in cuts:
        env,allowed,messages,events=x.restore(task,case)
        initial=d.snapshot(env);trace=[];target=None
        for turn,path in enumerate(paths[cut:]):
            raw=d.load(path);got=d.execute(env,allowed,messages,d.parse_message(raw['choices'][0]['message']),turn)
            for event in got:event['user_turn']=goal
            if turn==0:
                if not got or any(e['semantic_tool_error'] for e in got):break
                target=dict(state=d.snapshot(env),responses=d.canonical([e['response'] for e in got]))
            events.extend(got);trace.append(dict(source_response=str(path),raw=raw,execution=got))
        else:
            verdict=x.native_score(task,env,events,goal)
            if not verdict['passed']:continue
            ref=case/'aligned-teacher-reference'
            for turn,row in enumerate(trace):
                td=ref/f'turn-{turn:03d}'
                d.save(td/'response.json',row['raw']);d.save(td/'execution.json',row['execution'])
                d.save(td/'provenance.json',dict(actual_model_source=row['source_response'],
                    response_sha256=d.sha(row['raw']),not_a_new_generation=True))
            d.save(ref/'execution.json',events)
            d.save(case/'reference-alignment.json',dict(verified=True,exact_state_replay=True,
                reference=str(ref),source_successful_reference=str(source),local_target=target,
                restored_state=initial,restored_state_sha256=d.sha(initial),restored_context_sha256=d.sha(context),
                official_score=verdict,reference_verifier_assistance=assisted,
                suffix_replay=[dict(source_response=row['source_response'],execution=row['execution']) for row in trace],
                original_task_and_native_checkers_unchanged=True,teacher_outputs_never_edited=True))
            return case
    raise ValueError('No real successful teacher suffix could be verified at the reviewed checkpoint')


def main():
    parser=argparse.ArgumentParser();parser.add_argument('--prepare-only',action='store_true');args=parser.parse_args()
    R.mkdir(parents=True,exist_ok=True)
    lock=(R/'controller.lock').open('w');fcntl.flock(lock,fcntl.LOCK_EX | fcntl.LOCK_NB)
    x.R=R;x.prepare=prepare;x.audit.R=R/'native-audits';d.status=x.emit
    old_reply=d.reply
    def traced_reply(messages,role,dest,*a,**kw):
        x.emit('model_request',source=role,artifact=str(dest))
        start=time.monotonic();result=old_reply(messages,role,dest,*a,**kw)
        d.save(dest/'timing.json',dict(request_wall_seconds=time.monotonic()-start));return result
    d.reply=traced_reply
    tasks={t.task_id:t for t in d.load_bfcl_dataset('multi_turn_base',None)}
    for identifier in REVIEWS:prepare_checkpoint(tasks[identifier])
    d.save(R/'checkpoint-validation.json',dict(passed=True,reviewed_candidates=list(REVIEWS),
        all_actual_prefixes_reexecuted=True,original_benchmark_files_unchanged=True))
    if args.prepare_only:x.emit('reviewed_semantic_checkpoints_prepared');return
    d.save(R/'protocol.json',dict(source='existing measured substantive state failures missed by API-error-only screening',
        original_task_text_and_initial_state_unchanged=True,original_system_prompt=True,
        thinking=True,actor_seeds=x.SEEDS,source_models=d.WEIGHTS,
        reference_generation_attempts=1,reference_verifier_repairs=1,
        local_guide_refinements=4,all_guidance_sources_receive_same_evidence=True,
        baseline_failures='real local rejected operation OR substantive unchanged native task-state failure',
        local_and_whole_task_outcomes_reported_separately=True,
        selected_trajectories_not_an_aggregate_performance_estimate=True))
    for identifier in REVIEWS:
        index=Path('/mnt/genming/ablation-supervision-20261105/quality-index.json')
        if index.exists() and d.load(index)['approved_showcase_cases']>=10:
            x.emit('approved_target_reached',count=10);return
        try:x.run(tasks[identifier])
        except Exception as exc:
            d.save(R/'cases'/identifier/'needs-review.json',dict(error=str(exc),traceback=traceback.format_exc(),excluded_not_a_model_failure=True))
        results=[d.load(p) for p in (R/'cases').glob('*/comparison.json')]
        d.save(R/'progress.json',dict(completed=len(results),
            replay_verified_candidates=[v['task'] for v in results if v['qualified']],
            requires_manual_quality_review=True))
    x.emit('reviewed_semantic_backfill_complete')


if __name__=='__main__':main()
