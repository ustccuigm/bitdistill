"""Select illustrative individual runs, keeping every prior success and failure.

One accepted method success plus one genuine failed run from each of at least
two controls. This is selected-trajectory evidence, not an aggregate comparison.
"""
import copy
import fcntl
import hashlib
import json
from pathlib import Path
import time
import traceback

import compare_bfcl_candidates as comparison
import discover_bfcl_candidates as d

R = Path('/mnt/genming/ablation-single-trial-selection-20261104')
BASE = d.R / 'cases'
REPEATS = Path('/mnt/genming/ablation-bfcl-parallel-repeats-20261104/cases')
ROLES = ['teacher_freeform', 'student_structured', 'external_structured']
POLICY = dict(unit='selected individual trajectory', required_failed_controls=2,
    ours='One locally accepted success followed by successful unsteered continuation',
    controls='At least one valid semantically failed trajectory per selected control',
    prior_successes_disqualify=False, preserve_all_trials=True,
    additional_samples_per_control=4, additional_actor_seeds=[d.SEED+i for i in range(4)],
    no_aggregate_or_paired_seed_claim=True, target=10)


def identity(case):
    alignment = d.load(case / 'reference-alignment.json')
    scope = d.load(case / 'scope.json')
    return d.sha(dict(context=d.load(case / 'anchor-context.json'),
        prefix=d.load(case / 'prefix-execution.json'), goal_turn=scope['goal_turn'],
        reference_target=alignment['local_target']))


def state_failure(score):
    # A formatting-only response mismatch or final-directory difference does
    # not establish a substantive failed goal. Manual review remains required.
    changes = score.get('official_state', {}).get('details', {}).get('differences', {})
    critical = set(changes) - {'current_directory', 'current_dir', 'cwd', 'long_context'}
    return bool(critical)


def record_sample(case, score_path):
    student = score_path.parent
    dest = student.parent
    role = dest.parent.name
    score = d.load(score_path)
    receipt_path = dest / 'receipt.json'
    if not receipt_path.exists() or not score.get('valid') or score.get('finish') != 'final_response':
        return None
    receipt = d.load(receipt_path)
    guidance_path = dest / 'advisor/guidance.json'
    if not guidance_path.exists():
        return None
    guidance = d.load(guidance_path)['text']
    requests = sorted(student.glob('turn-*/request.json'))
    if not requests:
        return None
    first = d.load(requests[0])
    context = d.load(case / 'anchor-context.json')
    original_system = context[0]
    if not first.get('chat_template_kwargs', {}).get('enable_thinking'):
        return None
    if guidance not in first['messages'][0]['content']:
        return None
    if any(d.load(p)['messages'][0] != original_system for p in requests[1:]):
        return None
    accepted_success = bool(score['passed'] and receipt['local_accepted'] and len(requests) > 1)
    failed = bool(not score['passed'] and state_failure(score))
    return dict(case=str(case), score=str(score_path), sample=str(dest), role=role,
        accepted_success=accepted_success, failed=failed, passed=score['passed'],
        seed=first.get('seed'), guidance_sha256=d.sha(guidance),
        guidance_representation='tool-action text' if '<tool_call>' in guidance else
            ('structured JSON' if role != 'teacher_freeform' else 'free-form text'),
        guidance_only_first_request=True, unsteered_requests=len(requests)-1)


def inventory():
    groups = {}
    sources = list(BASE.iterdir()) + list(REPEATS.iterdir())
    for case in sources:
        if not case.is_dir() or not (case / 'reference-alignment.json').exists():
            continue
        task = case.name.split('-seed-')[0]
        canonical = BASE / task
        review = canonical / 'quality-review.json'
        if not review.exists() or not d.load(review).get('candidate_approved'):
            continue
        try:
            identifier = identity(case)
            if identifier != identity(canonical):
                continue
            group = groups.setdefault(identifier, dict(task=task, identity=identifier,
                canonical=str(canonical), samples={r: [] for r in ['teacher_structured']+ROLES}))
            paths = list(case.glob('ablations/*/attempt-*/student/score.json'))
            paths += list(case.glob('single-trial-samples/*/sample-*/student/score.json'))
            for p in paths:
                sample = record_sample(case, p)
                if sample and sample['role'] in group['samples']:
                    group['samples'][sample['role']].append(sample)
        except (OSError, ValueError, KeyError):
            continue
    return list(groups.values())


def replay_audit(sample):
    case = Path(sample['case'])
    student = Path(sample['score']).parent
    cache_key = d.sha(dict(score=d.load(Path(sample['score'])),
        execution=d.load(student / 'execution.json'), restore=d.load(student / 'restore.json'),
        identity=identity(case), sample=sample['sample']))
    cache = R / 'replay-audits' / (cache_key + '.json')
    if cache.exists():
        return d.load(cache)
    task_name = case.name.split('-seed-')[0]
    task = next(t for t in d.load_bfcl_dataset('multi_turn_base', None) if t.task_id == task_name)
    env, allowed = d.fresh(task)
    events = d.load(student / 'execution.json')
    for e in events:
        assert d.snapshot(env) == e['before']
        value = d.catalog(env) if e['tool'] == 'list_tools' else d.invoke(env, allowed, e['tool'], e['arguments'])
        assert d.canonical(value) == d.canonical(e['response'])
        assert d.snapshot(env) == e['after']
    goal = d.load(case / 'scope.json')['goal_turn']
    gt, results = d.expected(task, goal)
    state = d.state_checker(env._tool_instances, gt._tool_instances)
    response = d.response_checker([str(e['response']) for e in events if e['tool'] != 'list_tools'],
        [str(v) for v in results], goal)
    actual_passed = state['valid'] and response['valid']
    assert actual_passed == sample['passed']
    receipt = dict(verified=True, sample=sample, exact_action_transition_replay=True,
        original_verdict_reproduced=True, final_state=d.snapshot(env),
        official_state=state, official_response=response)
    d.save(cache, receipt)
    return receipt


def select(groups):
    approved = R / 'approved-reviews.json'
    reviews = d.load(approved) if approved.exists() else {}
    selected, pending, queue = [], [], []
    seen = set()
    for group in groups:
        ours = [s for s in group['samples']['teacher_structured'] if s['accepted_success']]
        if not ours:
            continue
        failures = {r: [s for s in group['samples'][r] if s['failed']] for r in ROLES}
        hit = [r for r in ROLES if failures[r]]
        if len(hit) >= 2:
            review = reviews.get(group['task'], {})
            chosen_ours = ours[0]
            chosen_controls = {r: failures[r][0] for r in hit}
            pinned = review.get('identity') == group['identity']
            if pinned and review.get('approved'):
                chosen_ours = next((s for s in ours if s['score'] == review.get('ours_score')), None)
                chosen_controls = {r: next((s for s in failures[r] if s['score'] == path), None)
                    for r, path in review.get('control_scores', {}).items() if r in failures}
                pinned = bool(chosen_ours and len(chosen_controls) >= 2 and all(chosen_controls.values()))
                if not pinned:
                    chosen_ours = ours[0]
                    chosen_controls = {r: failures[r][0] for r in hit}
            record = dict(task=group['task'], identity=group['identity'], canonical=group['canonical'],
                ours=chosen_ours, controls=chosen_controls,
                all_sample_paths={r: [s['score'] for s in ss] for r, ss in group['samples'].items()},
                selection_policy=POLICY)
            try:
                record['verification'] = [replay_audit(s) for s in [record['ours']]+list(record['controls'].values())]
            except Exception as exc:
                d.save(R / 'excluded' / (group['task']+'.json'), dict(error=str(exc),
                    traceback=traceback.format_exc(), excluded_not_a_semantic_failure=True))
                continue
            if pinned and review.get('approved') and group['task'] not in seen:
                record['review'] = reviews[group['task']]
                record['qualified'] = True
                selected.append(record)
                seen.add(group['task'])
            else:
                pending.append(record)
            d.save(R / 'cases' / group['task'] / 'selected-trajectories.json', record)
        else:
            queue.append(dict(group=group, known_failed_controls=hit))
    queue.sort(key=lambda q: -len(q['known_failed_controls']))
    report = dict(time=time.time(), target=10, qualified=len(selected),
        selected=selected, pending_final_review=pending,
        missing_branch_queue=[dict(task=q['group']['task'], failed=q['known_failed_controls']) for q in queue],
        selection_policy=POLICY)
    d.save(R / 'progress.json', report)
    return report, queue


def extra_sample(group, role, index):
    case = Path(group['canonical'])
    dest = case / 'single-trial-samples' / role / f'sample-{index:03d}'
    if (dest / 'student/score.json').exists() or (dest / 'excluded-error.json').exists():
        return False
    available = group['samples'][role]
    if available and any(s['seed'] == d.SEED+index and
            s['guidance_sha256'] == available[0]['guidance_sha256'] for s in available):
        return False
    comparison.comparison_status('single_trial_sample', task=group['task'], variant=role, sample=index)
    try:
        if available:
            source = Path(available[0]['sample']) / 'advisor'
            guidance = d.load(source / 'guidance.json')['text']
            d.save(dest / 'advisor/guidance.json', dict(text=guidance, variant=role))
            d.save(dest / 'advisor/provenance.json', dict(reused_generated_guidance=str(source),
                guidance_sha256=d.sha(guidance), new_advisor_generation=False))
        else:
            guidance = comparison.advisor(case, role, dest / 'advisor', [])
        task = next(t for t in d.load_bfcl_dataset('multi_turn_base', None) if t.task_id == group['task'])
        context = d.load(case / 'anchor-context.json')
        target = d.load(case / 'reference-alignment.json')['local_target']
        score = d.rollout(task, 'student', dest / 'student', context,
            d.load(case / 'prefix-execution.json'), seed=d.SEED+index, guidance=guidance,
            local_target=target, goal_turn=d.load(case / 'scope.json')['goal_turn'])
        local = d.load(dest / 'student/local-comparison.json')
        restored = d.load(dest / 'student/restore.json')['state']
        accepted = local['exact_reference_state'] and (target['state'] != restored or local['exact_reference_observation'])
        n = len(list((dest / 'student').glob('turn-*/request.json')))
        d.save(dest / 'receipt.json', dict(local_accepted=accepted, unsteered_requests=n-1,
            guidance_only_first_request=True, comparison_before_continuation=True,
            final_score=score, selection_unit='individual trajectory'))
    except Exception as exc:
        d.save(dest / 'excluded-error.json', dict(error=str(exc), traceback=traceback.format_exc(),
            excluded_not_a_model_failure=True))
    return True


def main():
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument('--once', action='store_true')
    args = parser.parse_args()
    R.mkdir(parents=True, exist_ok=True)
    lock = (R / 'selection.lock').open('w')
    fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
    d.save(R / 'selection-policy.json', POLICY)
    while True:
        report, queue = select(inventory())
        print('SINGLE_TRIAL_SELECTION', report['qualified'], 'pending_review', len(report['pending_final_review']), flush=True)
        if args.once or report['qualified'] >= 10:
            return
        ran = False
        for item in queue:
            group = item['group']
            # Fill a completely missing source before repeating a source already
            # sampled successfully. Keep known failed controls without reruns.
            roles = sorted([r for r in ROLES if r not in item['known_failed_controls']],
                key=lambda r: bool(group['samples'][r]))
            for role in roles:
                for index in range(4):
                    if extra_sample(group, role, index):
                        ran = True
                        break
                if ran:
                    break
            if ran:
                break
        if not ran:
            comparison.comparison_status('waiting_for_new_single_trial_candidates',
                qualified=report['qualified'], pending_final_review=len(report['pending_final_review']))
            time.sleep(20)


if __name__ == '__main__':
    main()
