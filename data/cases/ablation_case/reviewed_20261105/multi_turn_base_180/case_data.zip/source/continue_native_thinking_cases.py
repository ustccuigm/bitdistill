"""Follow up four reviewed native BFCL failures using their original cohort.

Arctic-AWM already emits native thinking. All actor variants share its decoder
and seed budget. Thinking is verified from actual responses, not only a flag.
The separate Gemma decoder repair is never mixed into this model cohort.
"""
import fcntl
from pathlib import Path
import time
import traceback
from concurrent.futures import ThreadPoolExecutor

import admit_semantic_bfcl_cases as a

x, d = a.x, a.d
R = Path('/mnt/genming/ablation-native-thinking-followup-20261105')
REVIEWS = {
    'multi_turn_base_180': dict(anchor_tool='set_budget_limit', wanted=['compute_exchange_rate'],
        reason='The user requested a 20,000 RMB travel budget, but the actual student set the USD-denominated budget directly to 20,000 without converting; the verified target is 2,857.14 USD.'),
    'multi_turn_base_152': dict(anchor_tool=None, wanted=['get_flight_cost', 'book_flight'],
        reason='The user authorized booking a flight if its price is below 5,000; the actual student only verified traveler details and stopped. The unchanged native cost is 4,000, so the requested booking remains unperformed.'),
    'multi_turn_base_90': dict(anchor_tool=None, wanted=['lockDoors', 'pressBrakePedal', 'startEngine'],
        reason='After correctly refueling, the actual student stopped without starting the engine; the requested operation still requires satisfying the door and foot-brake prerequisites.'),
    'multi_turn_base_59': dict(anchor_tool='fillFuelTank', wanted=['fillFuelTank'],
        reason='The user requested a full tank after earlier dialogue, but the actual student added only 10 gallons instead of the remaining 40, leaving the vehicle below full.'),
}


class TargetReached(RuntimeError):
    pass


def target_reached():
    path = Path('/mnt/genming/ablation-supervision-20261105/quality-index.json')
    return path.exists() and d.load(path)['approved_showcase_cases'] >= 10


def install_reply_audit():
    original = d.reply

    def checked(messages, role, dest, *args, **kwargs):
        if target_reached():
            raise TargetReached('Approved target reached; further requests stopped')
        x.emit('model_request', source=role, artifact=str(dest))
        start = time.monotonic()
        result = original(messages, role, dest, *args, **kwargs)
        d.save(dest / 'timing.json', dict(request_wall_seconds=time.monotonic() - start))
        request = d.load(dest / 'request.json')
        assert request['chat_template_kwargs']['enable_thinking'] is True
        msg = result['choices'][0]['message']
        thought = msg.get('reasoning') or msg.get('reasoning_content') or ''
        count = (result.get('usage', {}).get('completion_tokens_details') or {}).get('reasoning_tokens')
        actor = role == 'student' and 'trials' in dest.parts
        if actor and not msg.get('tool_calls') and not (msg.get('content') or '').strip():
            raise ValueError('Empty native final response excluded, not a control failure')
        decision = dest.name == 'turn-000' or bool(d.parse_message(msg).get('tool_calls'))
        verified = isinstance(thought, str) and len(thought.strip()) >= 32 and (count or 0) > 0
        d.save(dest / 'native-thinking-verification.json', dict(
            thinking_enabled=True, native_reasoning_tokens=count,
            native_reasoning_characters=len(thought), explicit_thinking_verified=verified,
            actor_decision_requires_positive_thinking=actor and decision,
            final_message_after_completed_actions_may_have_short_thinking=True))
        if actor and decision and not verified:
            raise ValueError('Actor decision has no substantive native thinking; sample excluded, not a control failure')
        return result

    d.reply = checked
    advisor = x.advisor

    def guarded_advisor(*args, **kwargs):
        if target_reached():
            raise TargetReached('Approved target reached; further guidance requests stopped')
        return advisor(*args, **kwargs)

    x.advisor = guarded_advisor


def run(task):
    if target_reached():
        return
    try:
        x.run(task)
        case = R / 'cases' / task.task_id
        receipts = []
        for p in case.glob('trials/*/guide-*/seed-*/turn-*/native-thinking-verification.json'):
            proof = d.load(p)
            if proof['actor_decision_requires_positive_thinking']:
                receipts.append(dict(path=str(p), **proof))
        d.save(case / 'actor-thinking-audit.json', dict(
            actual_native_reasoning_checked=True, decision_receipts=receipts,
            selected_case_semantic_review_still_required=True))
    except TargetReached:
        x.emit('approved_target_reached', task=task.task_id)
    except Exception as exc:
        d.save(R / 'cases' / task.task_id / 'needs-review.json', dict(
            error=str(exc), traceback=traceback.format_exc(), excluded_not_a_model_failure=True))
    results = [d.load(p) for p in (R / 'cases').glob('*/comparison.json')]
    d.save(R / 'progress.json', dict(completed=len(results),
        replay_verified_candidates=[v['task'] for v in results if v['qualified']],
        manual_quality_review_required=True))


def main():
    R.mkdir(exist_ok=True)
    lock = (R / 'controller.lock').open('w')
    fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
    a.R = R
    a.REVIEWS = REVIEWS
    x.R = R
    d.R = R
    x.prepare = a.prepare
    x.audit.R = R / 'native-audits'
    d.status = x.emit
    install_reply_audit()
    d.save(R / 'protocol.json', dict(
        source='four manually reviewed existing substantive BFCL state failures',
        model_cohort='Arctic-AWM-8B BF16 teacher and its frozen initial quantized student',
        source_models=d.WEIGHTS, actor_seeds=x.SEEDS, actor_temperature=0.6,
        thinking=True, actual_native_thinking_required_for_actor_decisions=True,
        requested_max_tokens=32768, original_task_system_prompt_and_checkers_unchanged=True,
        same_state_reference_and_feedback_for_all_guidance_sources=True,
        reference_generation_attempts=1, bounded_verifier_directed_reference_repairs=1,
        method_guidance_refinements=4, all_valid_successes_and_failures_preserved=True,
        selected_case_evidence_not_an_aggregate_performance_claim=True,
        stop_at_manually_approved_cases=10, plan=REVIEWS))
    d.save(R / 'benchmark-contradiction-not-selected.json', dict(
        task='multi_turn_base_171', selected=False,
        reason='Original gold books a 10,000 USD flight despite a 10,000 RMB (1,428.57 USD) budget. It cannot serve as an example of respecting the user budget.',
        original_benchmark_files_unchanged=True))
    tasks = {t.task_id: t for t in d.load_bfcl_dataset('multi_turn_base', None)}
    for identifier in REVIEWS:
        a.prepare_checkpoint(tasks[identifier])
    with ThreadPoolExecutor(max_workers=2) as pool:
        futures = [pool.submit(run, tasks[identifier]) for identifier in REVIEWS if not target_reached()]
        for future in futures:
            future.result()
    x.emit('native_thinking_followup_complete')


if __name__ == '__main__':
    main()
