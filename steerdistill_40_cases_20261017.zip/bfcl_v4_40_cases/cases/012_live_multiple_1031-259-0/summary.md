# Case 012 — live_multiple_1031-259-0

## 原始任务

第 1 轮：

Get the dashboard for "dashing".

完整工具定义、初始状态及其他任务字段见 task.json。

## 七种方法的实际表现

### BF16：通过

实际任务调用 1 次；[完整 CoT 和工具返回](BF16/cot_and_actions.txt)。

<details><summary>实际动作序列</summary>

```json
[
  {
    "user_turn": 1,
    "action_in_turn": 1,
    "message_index": 4,
    "action": {
      "wrapper": "call_tool",
      "name": "mcp_tool_get_custom_dashboard",
      "arguments": {
        "customDashboardId": "dashing"
      }
    }
  }
]
```

</details>

### Ours：通过

实际任务调用 1 次；[完整 CoT 和工具返回](Ours/cot_and_actions.txt)。

<details><summary>实际动作序列</summary>

```json
[
  {
    "user_turn": 1,
    "action_in_turn": 1,
    "message_index": 4,
    "action": {
      "wrapper": "call_tool",
      "name": "mcp_tool_get_custom_dashboard",
      "arguments": {
        "customDashboardId": "dashing"
      }
    }
  }
]
```

</details>

### GPTQ：未通过

实际任务调用 0 次；[完整 CoT 和工具返回](GPTQ/cot_and_actions.txt)。

<details><summary>实际动作序列</summary>

```json
[]
```

</details>

### EfficientQAT：未通过

实际任务调用 0 次；[完整 CoT 和工具返回](EfficientQAT/cot_and_actions.txt)。

<details><summary>实际动作序列</summary>

```json
[]
```

</details>

### BitDistiller：未通过

实际任务调用 0 次；[完整 CoT 和工具返回](BitDistiller/cot_and_actions.txt)。

<details><summary>实际动作序列</summary>

```json
[]
```

</details>

### On-Policy QAD：未通过

实际任务调用 0 次；[完整 CoT 和工具返回](On-Policy%20QAD/cot_and_actions.txt)。

<details><summary>实际动作序列</summary>

```json
[]
```

</details>

### QeRL：未通过

实际任务调用 0 次；[完整 CoT 和工具返回](QeRL/cot_and_actions.txt)。

<details><summary>实际动作序列</summary>

```json
[]
```

</details>

## 分歧位置

消息编号从 0 开始，用户轮和动作编号从 1 开始。按同一用户轮的任务动作序号与 BF16 比较，忽略 list_tools。最早动作差异不一定就是失败起点：正确的工具顺序、补救步骤也可能不同；评分失败位置另见下一节。

- Ours：按用户轮和动作序号比较，任务动作序列与 BF16 相同。

### GPTQ

最早动作差异：第 1 个用户轮，第 1 个任务动作；BF16 消息 4，本方法消息 None。

该位置没有对应任务调用；该轮 assistant 消息为 [2, 4]。

```json
[
  {
    "field": "$",
    "reference": {
      "wrapper": "call_tool",
      "name": "mcp_tool_get_custom_dashboard",
      "arguments": {
        "customDashboardId": "dashing"
      }
    },
    "actual": null
  }
]
```

### EfficientQAT

最早动作差异：第 1 个用户轮，第 1 个任务动作；BF16 消息 4，本方法消息 None。

该位置没有对应任务调用；该轮 assistant 消息为 [2, 4]。

```json
[
  {
    "field": "$",
    "reference": {
      "wrapper": "call_tool",
      "name": "mcp_tool_get_custom_dashboard",
      "arguments": {
        "customDashboardId": "dashing"
      }
    },
    "actual": null
  }
]
```

### BitDistiller

最早动作差异：第 1 个用户轮，第 1 个任务动作；BF16 消息 4，本方法消息 None。

该位置没有对应任务调用；该轮 assistant 消息为 [2, 4]。

```json
[
  {
    "field": "$",
    "reference": {
      "wrapper": "call_tool",
      "name": "mcp_tool_get_custom_dashboard",
      "arguments": {
        "customDashboardId": "dashing"
      }
    },
    "actual": null
  }
]
```

### On-Policy QAD

最早动作差异：第 1 个用户轮，第 1 个任务动作；BF16 消息 4，本方法消息 None。

该位置没有对应任务调用；该轮 assistant 消息为 [2, 4]。

```json
[
  {
    "field": "$",
    "reference": {
      "wrapper": "call_tool",
      "name": "mcp_tool_get_custom_dashboard",
      "arguments": {
        "customDashboardId": "dashing"
      }
    },
    "actual": null
  }
]
```

### QeRL

最早动作差异：第 1 个用户轮，第 1 个任务动作；BF16 消息 4，本方法消息 None。

该位置没有对应任务调用；该轮 assistant 消息为 [2, 4]。

```json
[
  {
    "field": "$",
    "reference": {
      "wrapper": "call_tool",
      "name": "mcp_tool_get_custom_dashboard",
      "arguments": {
        "customDashboardId": "dashing"
      }
    },
    "actual": null
  }
]
```

## 失败原因

用户要求获取 dashing 仪表盘。五个 baseline 的评分记录没有得到符合要求的调用数量；具体是未调用还是额外调用，见逐方法动作序列。

### GPTQ

评分指出的失败位置/原因：

```text
["Wrong number of functions."]
```

### EfficientQAT

评分指出的失败位置/原因：

```text
["Wrong number of functions."]
```

### BitDistiller

评分指出的失败位置/原因：

```text
["Wrong number of functions."]
```

### On-Policy QAD

评分指出的失败位置/原因：

```text
["Wrong number of functions."]
```

### QeRL

评分指出的失败位置/原因：

```text
["Wrong number of functions."]
```

