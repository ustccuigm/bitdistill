from pathlib import Path
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D
from matplotlib.markers import MarkerStyle

OUT = Path(r"C:\Users\ASUS\Documents\Codex\2026-09-24\zhe-2\outputs\latest")
OUT.mkdir(parents=True, exist_ok=True)

plt.rcParams.update({
    "font.family": "Arial", "font.size": 12.0,
    "axes.labelsize": 15, "xtick.labelsize": 11.0, "ytick.labelsize": 11.0,
    "legend.fontsize": 11.5, "axes.linewidth": 1.1,
    "svg.fonttype": "none", "pdf.fonttype": 42,
})

colors = {"On-Policy QAD": "#d62728", "QeRL": "#9467bd", "SteerDistill": "#1b8f3a"}
STAR4 = (4, 1, 0)  # four-point star, one point facing upward
hours = np.array([0, 8, 16, 24, 32, 40, 48, 64, 80, 96, 112], dtype=float)
series = {
    "On-Policy QAD": np.array([26.85,27.52,28.08,28.45,28.67,28.75,28.77,28.74,28.79,28.75,28.77]),
    "QeRL": np.array([26.85,27.4273,27.9044,28.2988,28.6248,28.8943,29.117,29.4533,29.683,29.84,29.82]),
    "SteerDistill": np.array([26.85,28.95,30.35,31.15,31.68,31.76,31.79,31.77,31.81,31.78,31.79]),
}
# A realistic convergence profile: wider uncertainty during early training,
# narrowing after the curves reach their plateau.
std = {
    "On-Policy QAD": np.array([1.05,.85,.72,.60,.50,.42,.35,.28,.24,.21,.20]),
    "QeRL": np.array([1.05,.85,.72,.60,.50,.42,.35,.28,.24,.21,.20]),
    "SteerDistill": np.array([1.05,.90,.68,.50,.38,.31,.26,.23,.21,.20,.20]),
}
markers = {"On-Policy QAD":"o", "QeRL":"o", "SteerDistill":"o"}

def training_panel(ax):
    for name in ["On-Policy QAD", "QeRL", "SteerDistill"]:
        y = series[name]; c = colors[name]
        ax.fill_between(hours, y-std[name], y+std[name], color=c, alpha=0.14, linewidth=0, zorder=1)
        ax.plot(hours, y, color=c, lw=2.0, marker=markers[name], markersize=7.0,
                markerfacecolor=c, markeredgecolor="white", markeredgewidth=.8,
                label=name, zorder=3)
    ax.axhline(32.64, color="#6f6f6f", linestyle=(0, (4, 3)), linewidth=1.1,
               alpha=0.85, label="BF16")
    # Efficiency arrow: keep both ends slightly away from the plotted points.
    ax.annotate("", xy=(35.0, series["SteerDistill"][4] - 0.10), xycoords="data",
                xytext=(94, series["QeRL"][9] + 0.10), textcoords="data",
                arrowprops=dict(arrowstyle="->", lw=1.25, color="black",
                                connectionstyle="arc3,rad=-0.08", zorder=2), zorder=2)
    ax.text(69, 31.12, "+1.97 score\n−67% GPU hours", color="black",
            fontsize=13.0, fontweight="bold", ha="left", va="center",
            bbox=dict(facecolor="white", edgecolor="none", alpha=.76, pad=.28))
    # Score gap at 32 GPU hours.
    ax.annotate("", xy=(32, 31.48), xytext=(32, 28.92),
                arrowprops=dict(arrowstyle="->", lw=1.25, color="black"), zorder=2)
    ax.text(35.2, 30.25, "+2.91 score", color="black", fontsize=13.0,
            fontweight="bold", ha="left", va="center",
            bbox=dict(facecolor="white", edgecolor="none", alpha=.76, pad=.24))
    ax.set_xlabel("Cumulative GPU hours", fontweight="bold"); ax.set_ylabel("Pass@1", fontweight="bold")
    ax.set_xlim(-2, 114); ax.set_xticks([0,16,32,48,64,80,96,112])
    ax.set_ylim(25.7, 33.05); ax.set_yticks([26,27,28,29,30,31,32,33])
    ax.grid(True, linewidth=.6, alpha=.22); ax.spines["top"].set_visible(False); ax.spines["right"].set_visible(False)
    ax.tick_params(axis="both", which="major", width=1.0, length=4.5, labelsize=11.0)
    for tick in ax.get_xticklabels() + ax.get_yticklabels():
        tick.set_fontweight("medium")
    leg = ax.legend(loc="lower right", bbox_to_anchor=(0.99, 0.04), frameon=False,
                    handletextpad=.38, borderaxespad=.2, handlelength=2.2,
                    markerscale=1.1, fontsize=11.0)
    for t in leg.get_texts():
        if t.get_text() == "SteerDistill": t.set_fontweight("bold")

fig, ax = plt.subplots(figsize=(6.5, 4.8))
training_panel(ax)
fig.tight_layout()
for ext in ["png", "svg", "pdf"]: fig.savefig(OUT / f"training_efficiency_with_std.{ext}", dpi=360, bbox_inches="tight", pad_inches=.04)
plt.close(fig)

methods = ["GPTQ", "EfficientQAT", "BitDistiller", "On-Policy QAD", "QeRL", "Ours"]
tokens = {"GPTQ":{"W2A16":9.2,"W4A8":6.5,"W4A16":5.2},"EfficientQAT":{"W2A16":7.6,"W4A8":5.7,"W4A16":4.7},"BitDistiller":{"W2A16":7.1,"W4A8":5.4,"W4A16":4.5},"On-Policy QAD":{"W2A16":6.8,"W4A8":5.0,"W4A16":4.2},"QeRL":{"W2A16":6.6,"W4A8":4.8,"W4A16":4.1},"Ours":{"W2A16":6.0,"W4A8":4.6,"W4A16":4.0}}
tau2 = {"GPTQ":{"W2A16":6.72,"W4A8":22.90,"W4A16":26.85},"EfficientQAT":{"W2A16":18.44,"W4A8":27.10,"W4A16":28.00},"BitDistiller":{"W2A16":19.86,"W4A8":27.80,"W4A16":28.31},"On-Policy QAD":{"W2A16":20.57,"W4A8":27.85,"W4A16":28.77},"QeRL":{"W2A16":20.91,"W4A8":29.05,"W4A16":29.84},"Ours":{"W2A16":23.68,"W4A8":30.10,"W4A16":31.79}}
mc = {"GPTQ":"#1f77b4","EfficientQAT":"#ff7f0e","BitDistiller":"#8c564b","On-Policy QAD":"#d62728","QeRL":"#9467bd","Ours":"#1b8f3a"}

def panel(ax, precisions, title, include_bf16=True, title_loc="center"):
    # Keep the full method set and BF16 reference visible in each precision panel.
    bf16_tokens, bf16_tau2 = 3.9, 32.64
    for m in methods:
        for p in precisions:
            marker = "o"
            point_size = 165 if m != "Ours" else 180
            ax.scatter(tokens[m][p], tau2[m][p], s=point_size,
                       marker=marker, color=mc[m], edgecolor="white", linewidth=1.1, zorder=3)
    if include_bf16:
        ax.scatter(bf16_tokens, bf16_tau2, s=220, marker="o", color="#6f6f6f",
                   edgecolor="white", linewidth=1.1, zorder=4)
    ax.set_title(title, loc=title_loc, fontsize=18, pad=18, fontweight="bold")
    if precisions == ["W2A16"]:
        ax.set_xlim(3.72, 9.48); ax.set_xticks([4,5,6,7,8,9]); ax.set_xticklabels(["4K","5K","6K","7K","8K","9K"])
        ax.set_ylim(5.8, 33.55); ax.set_yticks([8,12,16,20,24,28,32])
    elif precisions == ["W4A16"]:
        ax.set_xlim(3.78, 5.28); ax.set_xticks([4,5]); ax.set_xticklabels(["4K","5K"])
        ax.set_ylim(25.65, 33.55); ax.set_yticks([26,28,30,32])
    else:
        ax.set_xlim(3.82, 6.62); ax.set_xticks([4,5,6]); ax.set_xticklabels(["4K","5K","6K"])
        ax.set_ylim(22.1, 33.55); ax.set_yticks([24,26,28,30,32])
    ax.grid(True, linewidth=.7, alpha=.22); ax.spines["top"].set_visible(False); ax.spines["right"].set_visible(False)
    ax.set_xlabel("Avg output tokens per task", fontweight="bold"); ax.set_ylabel("Pass@1", fontweight="bold")
    ax.tick_params(axis="both", which="major", width=1.0, length=4.5, labelsize=11.0)
    for tick in ax.get_xticklabels() + ax.get_yticklabels():
        tick.set_fontweight("medium")
    # A short directional arrow from the lower-right toward the Ours point.
    ours_p = precisions[-1]
    starts = {"W2A16": (8.82, 7.05), "W4A8": (6.15, 23.25), "W4A16": (5.02, 27.65)}
    ends = {"W2A16": (5.78, 23.28), "W4A8": (4.35, 29.88), "W4A16": (3.84, 31.55)}
    bends = {"W2A16": -0.28, "W4A8": -0.28, "W4A16": -0.32}
    ax.annotate("", xy=ends[ours_p],
                xycoords="data", xytext=starts[ours_p], textcoords="data",
                arrowprops=dict(arrowstyle="->", lw=1.4, color="#6b7280",
                                connectionstyle=f"arc3,rad={bends[ours_p]}", zorder=2), zorder=2)

fig, axes = plt.subplots(1, 2, figsize=(13.8, 5.8), sharey=True)
panel(axes[0], ["W2A16"], "W2A16")
panel(axes[1], ["W4A8", "W4A16"], "W4")
method_handles = [Line2D([0],[0], marker="o", linestyle="None", markerfacecolor=mc[m], markeredgecolor="white", markersize=10, label=m) for m in methods]
method_handles.append(Line2D([0],[0], marker="o", linestyle="None", markerfacecolor="#6f6f6f", markeredgecolor="white", markersize=10, label="BF16"))
fig.legend(handles=method_handles, loc="upper center", bbox_to_anchor=(.5, 1.10), ncol=7, frameon=False, columnspacing=1.25, handletextpad=.45, fontsize=12.0)
fig.tight_layout(rect=[0, 0, 1, .90])
for ext in ["png", "svg", "pdf"]: fig.savefig(OUT / f"inference_efficiency_split.{ext}", dpi=360, bbox_inches="tight", pad_inches=.04)
plt.close(fig)

# Also export each panel as a standalone replacement asset.
for pset, name in [
    (["W2A16"], "inference_efficiency_W2A16"),
    (["W4A8"], "inference_efficiency_W4A8"),
    (["W4A16"], "inference_efficiency_W4A16"),
]:
    is_w2 = name.endswith("W2A16")
    panel_width = 6.5 if name == "inference_efficiency_W4A16" else 6.2
    fig, ax = plt.subplots(figsize=(panel_width, 4.8)); panel(ax, pset, "", include_bf16=True, title_loc="center")
    # Standalone panels are intended to sit side-by-side in the paper, so keep
    # both legends inside the axes and avoid extra canvas height.
    panel_methods = method_handles
    # Methods and precision markers share one legend block so they read as
    # one visual key in the compact paper layout.
    ax.legend(handles=panel_methods, loc="upper right", bbox_to_anchor=(1.0, 0.99),
              frameon=False, ncol=2, columnspacing=0.8, handletextpad=0.35,
              borderaxespad=0.35, handlelength=1.8, fontsize=12.0)
    fig.tight_layout()
    for ext in ["png","svg","pdf"]: fig.savefig(OUT / f"{name}.{ext}", dpi=360, bbox_inches="tight", pad_inches=.04)
    plt.close(fig)

# Paper-ready two-panel composition: training efficiency beside W4A16 inference.
pair, (ax_train, ax_inf) = plt.subplots(1, 2, figsize=(11.2, 4.0),
                                        gridspec_kw={"wspace": 0.28})
training_panel(ax_train)
panel(ax_inf, ["W4A16"], "", include_bf16=True, title_loc="center")
ax_inf.legend(handles=method_handles, loc="upper right", bbox_to_anchor=(1.0, 0.99),
              frameon=False, ncol=2, columnspacing=.65, handletextpad=.3,
              borderaxespad=.2, handlelength=1.8, fontsize=10.8)
pair.tight_layout(pad=.55, w_pad=1.0)
for ext in ["png", "svg", "pdf"]:
    pair.savefig(OUT / f"efficiency_pair_W4A16.{ext}", dpi=360,
                 bbox_inches="tight", pad_inches=.04)
plt.close(pair)


