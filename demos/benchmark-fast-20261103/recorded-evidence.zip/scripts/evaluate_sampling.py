import argparse,json,os,time,hashlib,sys,traceback
from pathlib import Path
ROOT=Path('/mnt/genming/steerdistill-scalewob')
sys.path[:0]=[str(ROOT),str(ROOT/'examples/scalewob')]
from collect_comparison import ComparisonPolicy as GreedyComparisonPolicy
from verl.experimental.scalewob.steer_runtime import PackedVisualPolicy
class ComparisonPolicy(GreedyComparisonPolicy):
 def act(self, **kwargs):
  if kwargs.get('steering'): raise ValueError('No guidance in evaluation')
  kwargs['temperature']=0.2
  if not self.warmed:
   PackedVisualPolicy.act(self, **kwargs);self.warmed=True
  start=time.perf_counter();result=PackedVisualPolicy.act(self, **kwargs)
  result.update(inference_seconds=time.perf_counter()-start,inference_backend=self.backend,output_tokens=len(result['completion_token_ids']),warmup_excluded=True)
  return result
from verl.experimental.scalewob.browser import ScaleWoBBrowser,ScaleWoBBrowserConfig
from verl.experimental.scalewob.collection_step import collection_step

def save(p,d): p.write_text(json.dumps(d,ensure_ascii=False,indent=2))
def main():
 a=argparse.ArgumentParser();a.add_argument('--label',required=True);a.add_argument('--model',required=True);a.add_argument('--output',type=Path,required=True);a=a.parse_args()
 a.output.mkdir(parents=True,exist_ok=False)
 old=Path('/mnt/genming/steerdistill-scalewob-runs/brownie-full-20261027/benchmark-step7-20261028')
 history=json.loads((old/'summary.json').read_text());tasks=[dict(env_id=x['env_id'],task_id=x['task_id'],description=x['description']) for x in history['task_results'] if x['success'] and x['env_id'] in ['slack','wps']]
 save(a.output/'provenance.json',dict(label=a.label,model=a.model,teacher_guidance=False,artifact_role='benchmark_evaluation',tasks=tasks,prompt_sha256=hashlib.sha256((ROOT/'verl/experimental/scalewob/prompt.py').read_bytes()).hexdigest(),max_steps=30,max_tokens=256,repeats=3,seeds=[0,1,2],temperature=0.2,gpu=os.environ.get('CUDA_VISIBLE_DEVICES'),timing='perf_counter from first observation acquisition after reset/warmup through evaluator done; recordings saved afterward; model loading and reset excluded',baseline_limit='Historical QAD uses Qwen3-VL base; ours and BF16 use brownie fine-tune. Not a matched-training ablation.'))
 provenance=json.loads((a.output/'provenance.json').read_text())
 provenance.update(enforce_eager=False,max_num_seqs=1,kv_cache_memory_bytes=2*1024**3,enable_prefix_caching=True,experiment='Same-device optimized episode evaluation; all repetitions retained')
 save(a.output/'provenance.json',provenance)
 policy=ComparisonPolicy(a.model,steer_root='/mnt/genming/steerdistill-scalewob-method-source',enforce_eager=False,max_num_seqs=1,kv_cache_memory_bytes=2*1024**3,enable_prefix_caching=True);results=[]
 cfg=ScaleWoBBrowserConfig(backend='playwright',proxy_server=None,chrome_executable='/mnt/genming/steerdistill-scalewob-assets/browser/chromium-1248/chrome-linux64/chrome',browser_operation_timeout_seconds=90,reset_retries=2)
 try:
  for rep in range(3):
   for task in tasks:
    d=a.output/f'repeat-{rep+1}'/f"{task['env_id']}-{task['task_id']}";d.mkdir(parents=True)
    browser=ScaleWoBBrowser(cfg);rows=[];frames=[]
    try:
     browser.reset(task);meta=browser.get_task_metadata()
     if meta is None:raise RuntimeError('missing canonical metadata')
     if not policy.warmed:
      policy.act(description=task['description'],image=browser.screenshot(),history=[],params_schema=meta.get('params'),max_tokens=256,seed=rep)
      browser.reset(task);meta=browser.get_task_metadata()
     history_rows=[];outcome={'done':True,'info':{'success':False,'reason':'step_limit'}}
     start=time.perf_counter()
     for step in range(30):
      screen=browser.screenshot();frames.append(screen)
      pred=policy.act(description=task['description'],image=screen,history=history_rows,params_schema=meta.get('params'),max_tokens=256,seed=rep)
      before=time.perf_counter()
      if pred['valid'] and not pred['truncated']:res=collection_step(browser.step,pred['action'])
      else:res={'done':True,'reward':0,'info':{'success':False,'error':'invalid_or_truncated_completion'}}
      elapsed=time.perf_counter()-start
      rows.append(dict(assistant_turn=step,task_description=task['description'],task_params_schema=meta.get('params'),action_history=list(history_rows),**pred,result=res,environment_seconds=time.perf_counter()-before,episode_elapsed_seconds=elapsed))
      history_rows.append(dict(thought=pred['thought'],raw_action=pred['raw_action']))
      if res['done']:outcome=res;break
     end=time.perf_counter();wall=end-start
     browser.screenshot().save(d/'final.png')
     for i,im in enumerate(frames):im.save(d/f'{i:03d}.png')
     (d/'turns.jsonl').write_text(''.join(json.dumps(x,ensure_ascii=False)+'\n' for x in rows));save(d/'outcome.json',outcome)
     rec=dict(label=a.label,repeat=rep+1,**task,success=outcome.get('info',outcome).get('success') is True,steps=len(rows),episode_seconds=wall,inference_seconds=sum(x['inference_seconds'] for x in rows),output_tokens=sum(x['output_tokens'] for x in rows),initial_image_sha256=hashlib.sha256(frames[0].tobytes()).hexdigest(),directory=str(d),status='completed')
     save(d/'metrics.json',rec);results.append(rec)
    except Exception as e:
     rec=dict(label=a.label,repeat=rep+1,**task,status='infrastructure_error',error=str(e),directory=str(d));save(d/'error.json',dict(**rec,traceback=traceback.format_exc()));results.append(rec)
    finally:browser.close()
    save(a.output/'summary.json',results);print(json.dumps(rec,ensure_ascii=False),flush=True)
 finally:policy.close()
if __name__=='__main__':main()
