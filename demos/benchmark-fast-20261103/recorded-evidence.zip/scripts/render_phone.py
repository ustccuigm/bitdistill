"""Portrait replay for the existing three-column demo layout."""
import json,subprocess,textwrap,shutil
from pathlib import Path
from PIL import Image,ImageDraw,ImageFont
from render import font,BASE,PAPER,INK,BLUE,MUTED
def build(source,records,out,label):
 source=Path(source);out=Path(out).resolve();out.mkdir(parents=True,exist_ok=True);tmp=out/'render';tmp.mkdir(exist_ok=True)
 tr=json.loads(Path(records).read_text());concat=[]
 for i,step in enumerate(tr['steps']):
  before=Image.open(source/f'{i:03d}.png').convert('RGB');after_path=source/f'{i+1:03d}.png'
  if not after_path.exists():after_path=source/'final.png' if (source/'final.png').exists() else source/f'{i:03d}.png'
  after=Image.open(after_path).convert('RGB')
  for phase,seconds in [('Before',2),('Action',2),('After',3)]:
   im=Image.new('RGB',(780,1920),PAPER);d=ImageDraw.Draw(im)
   d.text((30,16),label,font=font(29),fill=BLUE);d.text((30,60),f'Step {i+1:02d} / {len(tr["steps"]):02d}',font=font(24),fill=MUTED);d.text((600,60),phase,font=font(24),fill=BLUE)
   screen=after if phase=='After' else before;im.paste(screen.resize((780,1688)),(0,100))
   if phase=='Action' and step['point']:
    x,y=step['point'];x*=2;y=y*2+100
    d.ellipse((x-36,y-36,x+36,y+36),outline='white',width=12);d.ellipse((x-33,y-33,x+33,y+33),outline='#b94b36',width=6);d.line((x-15,y,x+15,y),fill='#b94b36',width=4);d.line((x,y-15,x,y+15),fill='#b94b36',width=4)
   caption=step['caption'] if phase!='After' else ('Inspect the resulting page' if step['view_changed'] else 'Next recorded observation')
   if step['last'] and phase=='After':caption='Evaluator: '+('SUCCESS' if tr['success'] else 'FAILED')
   for k,line in enumerate(textwrap.wrap(caption,48)):d.text((28,1801+k*36),line,font=font(28),fill=INK)
   elapsed=step.get('episode_elapsed_seconds',0)
   d.text((28,1882),f'Recorded clock: {elapsed:.1f} s · slowed replay',font=font(21),fill=MUTED)
   f=tmp/f'{i:03d}-{phase}.png';im.save(f);concat.extend([f"file '{f}'",f'duration {seconds}'])
   if i==min(8,len(tr['steps'])-1) and phase=='Action':im.save(out/'poster.jpg',quality=93)
 concat.append(f"file '{f}'");(out/'concat.txt').write_text('\n'.join(concat)+'\n')
 subprocess.run(['ffmpeg','-y','-loglevel','error','-f','concat','-safe','0','-i',str(out/'concat.txt'),'-r','24','-c:v','libx264','-threads','4','-preset','fast','-crf','21','-pix_fmt','yuv420p','-movflags','+faststart',str(out/'replay.mp4')],check=True)
 shutil.rmtree(tmp);(out/'concat.txt').unlink()
if __name__=='__main__':
 import argparse
 p=argparse.ArgumentParser();p.add_argument('--source',required=True);p.add_argument('--records',required=True);p.add_argument('--out',required=True);p.add_argument('--label',required=True);a=p.parse_args();build(a.source,a.records,a.out,a.label)
