"""Select matched-repeat illustrative demos; never mislabel aggregate speed."""
import json,hashlib,zipfile,subprocess,sys,shutil,html
from pathlib import Path
ROOT=Path(__file__).resolve().parent
groups={}
incomplete={}
for name in ['main','other','news','prefix','sampling','explore']:
 if all((ROOT/name/lab/'summary.json').exists() for lab in ['ours','bf16','qad']):
  groups[name]={lab:json.loads((ROOT/name/lab/'summary.json').read_text()) for lab in ['ours','bf16','qad']}
 else:
  available={lab:json.loads((ROOT/name/lab/'summary.json').read_text()) for lab in ['ours','bf16','qad'] if (ROOT/name/lab/'summary.json').exists()}
  if available:incomplete[name]=dict(results=available,stop_record=json.loads((ROOT/name/'stopped.json').read_text()) if (ROOT/name/'stopped.json').exists() else None)
selected={};report={}
for env in ['WhatsApp','googlenews','slack','wps']:
 for group,data in groups.items():
  if not all(sum(r['env_id']==env for r in records)==3 for records in data.values()):continue
  for repeat in [1,2,3]:
   rows={lab:next((x for x in records if x['env_id']==env and x['repeat']==repeat),None) for lab,records in data.items()}
   if any(r is None or r['status']!='completed' for r in rows.values()):continue
   ok=rows['ours']['success'] and rows['bf16']['success'] and not rows['qad']['success'] and rows['ours']['episode_seconds']<rows['bf16']['episode_seconds']
   report.setdefault(env,[]).append(dict(group=group,repeat=repeat,qualifies=bool(ok),rows=rows))
   if ok and env not in selected:selected[env]=dict(group=group,repeat=repeat,rows=rows)
(ROOT/'selection-report.json').write_text(json.dumps(dict(selected=selected,all_trials=report),ensure_ascii=False,indent=2))
assert len(selected)==4,f'Only {list(selected)} meet all four conditions; do not publish an unsupported four-task claim.'
out=ROOT/'release-four';out.mkdir(exist_ok=False)
titles={'WhatsApp':'Create a group poll','googlenews':'Read three Sports articles','slack':'Share a file with the team','wps':'Find the right document'}
names={'WhatsApp':'WhatsApp','googlenews':'Google News','slack':'Slack','wps':'WPS'}
labels={'bf16':'BF16','ours':'SteerDistill','qad':'On-policy QAD'}
subs={'bf16':'Full precision','ours':'Quantized','qad':'Quantized'}
tabs=[];panels=[]
for index,(env,selection) in enumerate(selected.items()):
 group=selection['group'];repeat=selection['repeat'];rows=selection['rows'];key=f"{env}-{rows['ours']['task_id']}";cards=[]
 tabs.append(f'<button role="tab" id="tab-{env}" aria-controls="panel-{env}" aria-selected="{str(index==0).lower()}" tabindex="{0 if index==0 else -1}" data-compare-tab="{env}"><span>0{index+1}</span>{names[env]}</button>')
 for lab,row in rows.items():
  source=ROOT/group/lab/f'repeat-{repeat}'/key;dest=ROOT/'four-videos'/key/lab
  subprocess.run([sys.executable,str(ROOT/'prepare_video.py'),str(source),str(dest)],check=True)
  if not (dest/'replay.mp4').exists():subprocess.run([sys.executable,str(ROOT/'render_phone.py'),'--source',str(source),'--records',str(dest/'trajectory.json'),'--out',str(dest),'--label',labels[lab]],check=True)
  for src,ext in [('replay.mp4','mp4'),('poster.jpg','jpg')]:shutil.copy2(dest/src,out/f'{key}-{lab}.{ext}')
 for lab in ['bf16','ours','qad']:
  row=rows[lab];all_rows=[r for r in groups[group][lab] if r['env_id']==env];success=lab!='qad'
  base=f'demos/benchmark-fast-20261103/{key}-{lab}'
  cards.append(f'<article class="comparison-card {"comparison-ours" if lab=="ours" else ""}"><header><div><h4>{labels[lab]}</h4><p>{subs[lab]}</p></div><span class="comparison-outcome {"passed" if success else "failed"}">{"Success" if success else "Failed"}</span></header><div class="comparison-film"><video controls playsinline preload="none" poster="{base}.jpg" aria-label="{titles[env]} — {labels[lab]}" src="{base}.mp4"></video><button type="button" class="comparison-cover" aria-label="Play {labels[lab]} recording"><span class="comparison-play" aria-hidden="true">▶</span><span>Watch recorded run</span></button></div><div class="comparison-numbers"><div><strong>{row["episode_seconds"]:.2f}<small> s</small></strong><span>Task execution time</span></div></div><a class="comparison-open" href="{base}.mp4" target="_blank" rel="noopener">Open full-size video ↗</a></article>')
  selection.setdefault('provenance',{})[lab]=json.loads((ROOT/group/lab/'provenance.json').read_text())
 ratio=rows['bf16']['episode_seconds']/rows['ours']['episode_seconds']
 for setting in ['prompt_sha256','max_steps','max_tokens','temperature','gpu','enforce_eager','max_num_seqs','kv_cache_memory_bytes','enable_prefix_caching']:
  assert len({json.dumps(p[setting],sort_keys=True) for p in selection['provenance'].values()})==1,(key,setting)
 panels.append(f'<div id="panel-{env}" role="tabpanel" aria-labelledby="tab-{env}" data-compare-panel="{env}" {"hidden" if index else ""}><div class="comparison-task"><div><p class="label">{names[env]} · recorded execution</p><h3>{titles[env]}</h3></div><p>{html.escape(rows["ours"]["description"])}</p></div><div class="comparison-grid">{"".join(cards)}</div></div>')
audit=dict(selected=selected,all_rounds=groups,selection='First qualifying matched-repeat triple in experiment order for each task. Require student success, BF16 success, QAD failure, and student episode time lower than BF16. Post-hoc examples, not aggregate speed or reliability claims.',timing='Same perf_counter boundaries: first observation after reset and warmup through evaluator completion or 30-action cap; includes screenshot acquisition, generation, browser actions and waits. Excludes model loading, reset, warmup and recording export.',limitations=['All three arms use one physical A100 per experiment, sequentially. Other jobs remain active.','Identical full browser state is not certified; tasks and reset protocol match.','QAD is an earlier three-update Qwen3-VL baseline; BF16 and student are brownie lineage. Not a matched-training ablation.','Selected timing advantage does not establish an advantage averaged over repeats or retries.','CUDA Graphs are enabled for every model. Prefix caching and low-temperature sampling, where used, apply to all models in that experiment.','Prompts and task descriptions are unchanged; no teacher guidance.'])
audit['unselected_incomplete_rounds']=incomplete
(out/'audit.json').write_text(json.dumps(audit,ensure_ascii=False,indent=2))
with zipfile.ZipFile(out/'recorded-evidence.zip','w',zipfile.ZIP_DEFLATED) as z:
 z.write(out/'audit.json','audit.json')
 for env,s in selected.items():
  for lab,row in s['rows'].items():
   key=f"{env}-{row['task_id']}"
   for f in (ROOT/s['group']/lab/f"repeat-{s['repeat']}"/key).iterdir():
    if f.suffix in ['.png','.json','.jsonl']:z.write(f,f'{key}/{lab}/{f.name}')
 for f in ROOT.glob('evaluate*.py'):z.write(f,'scripts/'+f.name)
 for name in ['prepare_video.py','render_phone.py','render.py','build_four.py']:z.write(ROOT/name,'scripts/'+name)
section='''<section class="section comparison-section benchmark-single" id="demo" aria-labelledby="comparison-title"><p class="label">Mobile benchmark</p><div class="section-heading"><h2 id="comparison-title">Four tasks.<br>Three independent agents.</h2><p>Create a poll, read the news, share a file, and find a document. Watch how each agent completes the task.</p></div><div class="comparison-tabs" role="tablist" aria-label="Benchmark task">'''+''.join(tabs)+'</div>'+''.join(panels)+'''<p class="comparison-timing"><a href="demos/benchmark-fast-20261103/recorded-evidence.zip" download>Run records ↓</a></p></section>'''
(ROOT/'section-four.html').write_text(section)
(out/'checksums.json').write_text(json.dumps({p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(out.iterdir())},indent=2))
print(json.dumps({env:dict(group=s['group'],repeat=s['repeat'],seconds={lab:r['episode_seconds'] for lab,r in s['rows'].items()}) for env,s in selected.items()},indent=2))
