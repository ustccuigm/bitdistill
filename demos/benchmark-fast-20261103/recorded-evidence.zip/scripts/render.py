"""Build honest, deliberately slowed screen replays from recorded evaluations."""
import argparse,json,subprocess,textwrap,hashlib,shutil
from pathlib import Path
from PIL import Image,ImageDraw,ImageFont
BASE=Path(__file__).resolve().parent
PAPER='#fffefa';INK='#292825';BLUE='#315f78';MUTED='#696760';LINE='#dedbd2'
def font(n,serif=False):return ImageFont.truetype(str(BASE/'fonts'/('serif.ttf' if serif else 'sans.ttf')),n)
def wrapped(draw,text,xy,width=43,size=25,color=INK):
 y=xy[1]
 ff=ImageFont.truetype(str(BASE/'fonts/NotoSansCJK-Regular.ttc'),size,index=2) if any(ord(c)>0x2e80 for c in text) else font(size)
 for line in textwrap.wrap(text,width=width,break_long_words=True):draw.text((xy[0],y),line,font=ff,fill=color);y+=size*1.45
 return y
def build(source,out,title,label):
 source=source.resolve();out=out.resolve()
 out.mkdir(parents=True,exist_ok=True);rows=[json.loads(l) for l in (source/'turns.jsonl').read_text().splitlines()]
 metrics=json.loads((source/'metrics.json').read_text()) if (source/'metrics.json').exists() else None
 outcome=json.loads((source/'outcome.json').read_text());success=outcome.get('info',outcome).get('success') is True
 frames=out/'frames';frames.mkdir(exist_ok=True);video_frames=out/'render';video_frames.mkdir(exist_ok=True)
 records=[];concat=[]
 for i,row in enumerate(rows):
  before=source/f'{i:03d}.png';after=source/f'{i+1:03d}.png'
  if not after.exists():after=source/'final.png' if (source/'final.png').exists() else before
  before_im=Image.open(before).convert('RGB');after_im=Image.open(after).convert('RGB')
  for name,im in [('before',before_im),('after',after_im)]:im.save(frames/f'{i:03d}-{name}.webp',quality=92)
  action=row['result'].get('info',{}).get('executed_action') or row['action'];kind=action.get('action');point=None
  if kind in ['tap','click','long_press']:
   point=[action['x'],action['y']]
   if not row['result'].get('info',{}).get('executed_action'):point=[round(point[0]*389/1000),round(point[1]*843/1000)]
  caption={'tap':'Tap the highlighted control','click':'Tap the highlighted control','type':'Enter text','swipe':'Scroll through the page','wait':'Wait for the app','finish':'Submit task completion'}.get(kind,kind or 'Recorded action')
  original_captions={
   'WhatsApp-7':['Continue from the welcome screen','Select the phone number field','Enter the test phone number','Continue sign-in','Wait for verification','Select the profile name field','Enter the profile name','Finish profile setup','Open Project Alpha','Inspect the group menu','Open More options','Try the attachment menu','Choose Poll','Select the question field','Enter: Next meeting?','Select the first option','Enter: Monday','Select the second option','Enter: Tuesday','Send the poll','Submit task completion'],
   'googlenews-4':['Select the email field','Enter the test email','Continue sign-in','Enter the simulator test password','Finish sign-in','Open Sports','Open the first article','Wait for the article to load','Navigate back','Return to the category list','Open another article','Navigate back','Return to the category list','Return to Sports','Open a third article','Wait for the article to load','Submit task completion'],
   'slack-5':['Open Acme Corp','Enter the design-team channel','Open attachments','Choose Photo Library','Wait for the upload','Wait for upload completion','Reopen attachments','Choose Photo Library again','Wait for the upload','Wait for upload completion','Submit task completion'],
   'wps-9':['Open document search','Search for Apple MACBook','Open the matching document','Wait for the document to load','Scroll to inspect the document','Submit the document filename']}
  if 'history' in source.parts and source.name in original_captions and len(rows)==len(original_captions[source.name]):caption=original_captions[source.name][i]
  raw=row.get('raw_action',json.dumps(action,ensure_ascii=False))
  record=dict(step=i+1,before=f'frames/{i:03d}-before.webp',after=f'frames/{i:03d}-after.webp',action=action,raw_action=raw,caption=caption,point=point,size=list(before_im.size),last=i==len(rows)-1,after_available=after!=before,view_changed=before_im.tobytes()!=after_im.tobytes())
  records.append(record)
  for phase,duration in [('Observe',2),('Act',2),('Result',3)]:
   im=Image.new('RGB',(1280,960),PAPER);d=ImageDraw.Draw(im)
   d.text((50,18),'SteerDistill  /  Benchmark replay',font=font(19),fill=MUTED);d.line((50,49,1230,49),fill=LINE,width=1)
   screen=after_im if phase=='Result' else before_im;im.paste(screen,(80,72));d.rectangle((79,71,470,916),outline=LINE,width=1)
   d.text((535,80),label.upper(),font=font(18),fill=BLUE)
   y=wrapped(d,title,(535,120),width=32,size=36)
   d.text((535,y+28),f'STEP {i+1:02d} / {len(rows):02d}  ·  {phase.upper()}',font=font(21),fill=BLUE)
   wrapped(d,caption if phase!='Result' else ('Page changed — inspect the next view' if record['view_changed'] else 'Next recorded view'),(535,y+80),width=38,size=27)
   wrapped(d,raw,(535,y+175),width=48,size=20,color=MUTED)
   if phase=='Act' and point:
    x,yy=point;px=80+x;py=72+yy
    d.ellipse((px-23,py-23,px+23,py+23),outline='#ffffff',width=7);d.ellipse((px-21,py-21,px+21,py+21),outline='#b94b36',width=4)
    d.line((px-9,py,px+9,py),fill='#b94b36',width=3);d.line((px,py-9,px,py+9),fill='#b94b36',width=3)
    crop=screen.crop((max(0,min(x-100,190)),max(0,min(yy-55,734)),max(0,min(x-100,190))+200,max(0,min(yy-55,734))+110)).resize((400,220))
    im.paste(crop,(535,620));d.rectangle((534,619,936,841),outline=BLUE,width=2);d.text((535,850),'Click target · enlarged',font=font(18),fill=MUTED)
   if i==len(rows)-1 and phase=='Result':
    d.text((535,580),'Evaluator: '+('SUCCESS' if success else 'FAILED'),font=font(29),fill=BLUE if success else '#a33a31')
   d.text((535,906),'Slowed replay · 7 seconds per step · not real-time',font=font(18),fill=MUTED)
   d.rectangle((50,942,50+1180*(i+({'Observe':0,'Act':.3,'Result':.7}[phase]))/len(rows),946),fill=BLUE)
   f=video_frames/f'{i:03d}-{phase}.png';im.save(f);concat.extend([f"file '{f}'",f'duration {duration}'])
   if i==0 and phase=='Act':im.save(out/'poster.jpg',quality=92)
 concat.append(f"file '{f}'");(out/'concat.txt').write_text('\n'.join(concat)+'\n')
 subprocess.run(['ffmpeg','-y','-loglevel','error','-f','concat','-safe','0','-i',str(out/'concat.txt'),'-r','24','-c:v','libx264','-threads','4','-preset','fast','-crf','22','-pix_fmt','yuv420p','-movflags','+faststart',str(out/'replay.mp4')],check=True)
 (out/'trajectory.json').write_text(json.dumps(dict(title=title,label=label,success=success,metrics=metrics,steps=records),ensure_ascii=False,indent=2))
 shutil.rmtree(video_frames);(out/'concat.txt').unlink()
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('--source',type=Path,required=True);p.add_argument('--output',type=Path,required=True);p.add_argument('--title',required=True);p.add_argument('--label',required=True);a=p.parse_args();build(a.source,a.output,a.title,a.label)
