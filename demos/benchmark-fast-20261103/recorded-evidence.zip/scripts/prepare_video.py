"""Build replay metadata from measured actions, without rewriting trajectories."""
import json,sys
from pathlib import Path
from PIL import Image
source=Path(sys.argv[1]);out=Path(sys.argv[2]);out.mkdir(parents=True,exist_ok=True)
rows=[json.loads(x) for x in (source/'turns.jsonl').read_text().splitlines()]
metrics=json.loads((source/'metrics.json').read_text());steps=[]
for i,row in enumerate(rows):
    executed=row['result'].get('info',{}).get('executed_action')
    action=executed or row['action'];kind=action.get('action');point=None
    before=Image.open(source/f'{i:03d}.png').convert('RGB')
    nxt=source/f'{i+1:03d}.png'
    if not nxt.exists():nxt=source/'final.png'
    after=Image.open(nxt).convert('RGB')
    if kind in ['tap','click','long_press']:
        point=[action['x'],action['y']]
        if not executed:point=[round(point[0]*(before.width-1)/1000),round(point[1]*(before.height-1)/1000)]
    caption={'tap':'Tap the highlighted control','click':'Tap the highlighted control','type':'Enter text','swipe':'Scroll through the page','wait':'Wait for the app','finish':'Submit task completion','press_enter':'Press Enter','back':'Navigate back'}.get(kind,kind or 'Recorded action')
    if kind=='type':caption='Enter: '+str(action.get('text',''))
    if kind=='finish' and action.get('status')=='infeasible':caption='Declare the task infeasible'
    steps.append(dict(point=point,caption=caption,last=i==len(rows)-1,view_changed=before.tobytes()!=after.tobytes(),episode_elapsed_seconds=row['episode_elapsed_seconds']))
(out/'trajectory.json').write_text(json.dumps(dict(success=metrics['success'],metrics=metrics,steps=steps),ensure_ascii=False,indent=2))
