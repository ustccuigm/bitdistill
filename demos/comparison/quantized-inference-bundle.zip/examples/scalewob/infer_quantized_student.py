"""Accelerated, unguided ScaleWoB inference for exported Quantized Students.

Use the verified packed runtime as --model. The production prompt, image
resolution, greedy decoding and task evaluator remain unchanged. A single
interactive session uses CUDA graphs with concurrency one, avoiding unused
graph batch sizes. BF16 is available only as an explicit comparison control.
All outputs are evaluation artifacts and are rejected by the training audit.
"""
import json
from pathlib import Path
import sys

import collect_comparison as comparison


class AcceleratedStudentPolicy(comparison.ComparisonPolicy):
    def __init__(self, runtime_path, **kwargs):
        kwargs.update(enforce_eager=False, max_num_seqs=1, kv_cache_memory_bytes=2 * 1024**3)
        super().__init__(runtime_path, **kwargs)


def main():
    allow_bf16 = '--allow-bf16-reference' in sys.argv
    if allow_bf16:
        sys.argv.remove('--allow-bf16-reference')
    if '--model' not in sys.argv:
        raise SystemExit('Supply --model PACKED_RUNTIME and the normal collect_comparison.py task/output arguments')
    model = Path(sys.argv[sys.argv.index('--model') + 1])
    config = json.loads((model / 'config.json').read_text())
    quantization = config.get('quantization_config')
    if not quantization and not allow_bf16:
        raise ValueError('Expected a verified packed quantized runtime; BF16 controls require --allow-bf16-reference')
    if quantization:
        q = json.loads((model / 'quant_config.json').read_text())
        if q.get('w_bit') != 4 or q.get('q_group_size') != 64:
            raise ValueError('This trained model requires the original INT4/g64 quantizer')
    comparison.ComparisonPolicy = AcceleratedStudentPolicy
    comparison.main()
    output = Path(sys.argv[sys.argv.index('--output') + 1])
    (output / 'acceleration.json').write_text(json.dumps(dict(
        model=str(model.resolve()), quantization=quantization, cuda_graphs=True,
        max_num_seqs=1, kv_cache_memory_bytes=2 * 1024**3, prefix_caching=False, warmup_excluded=True,
        guidance=False, prompt_modified=False, decoding='greedy, max 256 tokens',
        note='Latency measures blocking model inference; browser operations excluded. Speedup requires matched controls.'), indent=2))


if __name__ == '__main__':
    main()
