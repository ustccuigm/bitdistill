"""Unguided evaluation with the same vLLM stack for BF16 and quantized models.

Wraps the unchanged production collector and prompt builder. Latencies include
prompt preparation and blocking generation, exclude browser work and warmup.
"""
import json
import os
import sys
import time
from pathlib import Path

import collect_visual_rollouts as collector
from verl.experimental.scalewob.steer_runtime import PackedVisualPolicy
from verl.experimental.scalewob.browser import ScaleWoBBrowser
from verl.experimental.scalewob.steer_replay import VerifiedBestBuyReplay


class EvaluationBrowser(ScaleWoBBrowser):
    artifact_output = None

    def step(self, action):
        result = super().step(action)
        if result.get('done'):
            directory = self.artifact_output / f'{self._env_id}-{self._task_id}'
            # Capture asynchronous UI completion after the evaluator result.
            # This wait is outside the measured model inference time.
            backend = self._ensure_automation()
            self._call_with_timeout(backend._run, lambda: backend._page.wait_for_timeout(1200))
            self.screenshot().save(directory / 'final.png')
            state = VerifiedBestBuyReplay(self)._state()
            (directory / 'final-state.json').write_text(json.dumps(dict(
                state=state, evaluator_result=result, post_completion_wait_ms=1200)))
        return result


class ComparisonPolicy(PackedVisualPolicy):
    def __init__(self, runtime_path, **kwargs):
        from transformers import AutoProcessor
        from vllm import LLM, SamplingParams
        self.steer_root = kwargs.get('steer_root')
        self.processor = AutoProcessor.from_pretrained(runtime_path, local_files_only=True)
        config = json.loads((Path(runtime_path) / 'config.json').read_text())
        quantized = bool(config.get('quantization_config'))
        self.engine = LLM(model=str(runtime_path), quantization='awq_marlin' if quantized else None,
            dtype='bfloat16', tensor_parallel_size=1, max_model_len=4096,
            gpu_memory_utilization=0.40, enforce_eager=kwargs.get('enforce_eager', True), enable_prefix_caching=False,
            max_num_seqs=kwargs.get('max_num_seqs', 256),
            kv_cache_memory_bytes=kwargs.get('kv_cache_memory_bytes'),
            limit_mm_per_prompt={'image': 1}, mm_processor_kwargs={'max_pixels': 1048576}, seed=0)
        self.sampling_params = SamplingParams
        self.warmed = False
        self.backend = 'vllm_awq_marlin' if quantized else 'vllm_bf16'

    def act(self, **kwargs):
        if kwargs.get('steering') or kwargs.get('temperature', 0):
            raise ValueError('Comparison requires unguided greedy inference')
        if not self.warmed:
            super().act(**kwargs)
            self.warmed = True
        start = time.perf_counter()
        result = super().act(**kwargs)
        elapsed = time.perf_counter() - start
        result.update(inference_seconds=elapsed, inference_backend=self.backend,
            output_tokens=len(result['completion_token_ids']), warmup_excluded=True)
        return result


def main():
    if '--awq-runtime' in sys.argv or '--teacher-guidance' in sys.argv or '--counterfactual-from' in sys.argv:
        raise ValueError('Use --model for either precision; guidance forbidden')
    if '--artifact-role' not in sys.argv:
        sys.argv += ['--artifact-role', 'demo_evaluation']
    if sys.argv[sys.argv.index('--artifact-role') + 1] != 'demo_evaluation':
        raise ValueError('Comparison artifacts must never enter training')
    collector.VisualPolicy = ComparisonPolicy
    collector.PackedVisualPolicy = ComparisonPolicy
    EvaluationBrowser.artifact_output = Path(sys.argv[sys.argv.index('--output') + 1])
    collector.ScaleWoBBrowser = EvaluationBrowser
    collector.main()
    out = Path(sys.argv[sys.argv.index('--output') + 1])
    model = Path(sys.argv[sys.argv.index('--model') + 1])
    quantized = bool(json.loads((model / 'config.json').read_text()).get('quantization_config'))
    for path in out.glob('provenance-*.json'):
        provenance = json.loads(path.read_text())
        provenance.update(quantized=quantized, inference_backend='vllm',
            awq_runtime=str(model) if quantized else None, warmup_excluded=True,
            prefix_caching=False, memory_fraction=0.40)
        path.write_text(json.dumps(provenance, indent=2))
    result = []
    for file in sorted(out.glob('*/outcome.json')):
        outcome = json.loads(file.read_text())
        rows = [json.loads(line) for line in (file.parent / 'turns.jsonl').read_text().splitlines()]
        for row in rows:
            row['policy'] = 'quantized_awq_marlin' if quantized else 'bf16_vllm'
        (file.parent / 'turns.jsonl').write_text(''.join(json.dumps(row) + '\n' for row in rows))
        result.append(dict(task=file.parent.name, success=outcome.get('info', outcome).get('success') is True,
            actions=len(rows), inference_seconds=sum(r['inference_seconds'] for r in rows),
            output_tokens=sum(r['output_tokens'] for r in rows)))
    (out / 'comparison-summary.json').write_text(json.dumps(dict(
        tasks=result, successes=sum(t['success'] for t in result),
        physical_devices=os.environ.get('CUDA_VISIBLE_DEVICES'),
        note='Shared-GPU exploratory latency; trajectories can differ. Not a matched-input speed benchmark.'), indent=2))


if __name__ == '__main__':
    main()
