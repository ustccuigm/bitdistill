"""Collect complete screenshot/action trajectories and actual evaluator results.

These are raw sampling artifacts, not audited SteerDistill training targets.
Failures still require counterfactual recovery before materialization.
"""
import argparse
import hashlib
import json
from pathlib import Path
import pandas as pd
from verl.experimental.scalewob.browser import ScaleWoBBrowser, ScaleWoBBrowserConfig
from verl.experimental.scalewob.steer_runtime import VisualPolicy, PackedVisualPolicy
from verl.experimental.scalewob.steer_replay import VerifiedBestBuyReplay
from verl.experimental.scalewob.task_schedule import select_tasks


def main():
    p = argparse.ArgumentParser()
    p.add_argument('--model', required=True)
    p.add_argument('--train', '--data', dest='train', required=True)
    p.add_argument('--split', choices=('train', 'validation'), default='train')
    p.add_argument('--task-keys', type=Path, help='JSON list of [env_id, task_id] pairs from this split')
    p.add_argument('--env-id', default='BestBuy')
    p.add_argument('--count', type=int, help='Omit to collect all selected tasks')
    p.add_argument('--shard-index', type=int, default=0)
    p.add_argument('--num-shards', type=int, default=1)
    p.add_argument('--capture-replay', action='store_true')
    p.add_argument('--counterfactual-from', type=Path)
    p.add_argument('--initial-state-from', type=Path,
                   help='Independent demo evaluation from a verified saved initial state; adds no guidance')
    p.add_argument('--artifact-role', choices=('rollout', 'demo_evaluation'), default='rollout')
    p.add_argument('--teacher-guidance', action='store_true',
                   help='Grounded reference-only guidance; never used for student or validation collection')
    p.add_argument('--teacher-temperature', type=float, default=0.0)
    p.add_argument('--seed', type=int, default=0)
    p.add_argument('--max-steps', type=int, default=30)
    p.add_argument('--output', type=Path, required=True)
    p.add_argument('--proxy')
    p.add_argument('--chrome-executable')
    p.add_argument('--steer-root')
    p.add_argument('--clip')
    p.add_argument('--quantized', action='store_true')
    p.add_argument('--awq-runtime', type=Path)
    a = p.parse_args()
    if a.initial_state_from and (a.counterfactual_from or not a.capture_replay or a.artifact_role != 'demo_evaluation'):
        raise ValueError('Independent initial-state replay requires demo evaluation and checked replay')
    # All counterfactual references use the same documented reference policy.
    if a.counterfactual_from:
        a.teacher_guidance = True
    if a.teacher_guidance and (not a.counterfactual_from or a.awq_runtime or a.quantized or a.split != 'train'):
        raise ValueError('Teacher guidance is restricted to BF16 training-reference collection')
    if a.teacher_temperature and (not a.teacher_guidance or not 0 < a.teacher_temperature <= 1):
        raise ValueError('Stochastic generation is restricted to teacher references')
    import torch
    torch.manual_seed(a.seed)
    if a.quantized and not a.clip and not a.awq_runtime:
        raise ValueError('Initial W4 sampling requires calibrated clipping')
    if not 0 <= a.shard_index < a.num_shards:
        raise ValueError('Invalid shard index')
    data_stem = Path(a.train).stem
    if data_stem in ('train', 'validation') and data_stem != a.split:
        raise ValueError('Dataset filename and declared split disagree')
    if a.split == 'validation' and (a.capture_replay or a.counterfactual_from):
        raise ValueError('Validation must not generate repair or training evidence')
    tasks = select_tasks([r['scalewob'] for r in pd.read_parquet(a.train).extra_info],
                         a.env_id, a.count,
                         json.loads(a.task_keys.read_text()) if a.task_keys else None)
    if a.capture_replay and any(t['env_id'] != 'BestBuy' for t in tasks):
        raise ValueError('Causal replay adapters for these applications are not certified yet')
    a.output.mkdir(parents=True, exist_ok=True)
    provenance = dict(model=str(Path(a.model).resolve()), quantized=a.quantized or bool(a.awq_runtime),
                      clip_sha256=hashlib.sha256(Path(a.clip).read_bytes()).hexdigest() if a.clip else None,
                      dataset_sha256=hashlib.sha256(Path(a.train).read_bytes()).hexdigest(),
                      dataset_split=a.split,
                      artifact_role=a.artifact_role,
                      initial_state_from=str(a.initial_state_from) if a.initial_state_from else None,
                      teacher_guidance=a.teacher_guidance,
                      teacher_temperature=a.teacher_temperature, seed=a.seed,
                      adapter_sha256=hashlib.sha256(Path('verl/experimental/scalewob/playwright_backend.py').read_bytes()).hexdigest(),
                      selected_task_keys=[[t['env_id'], str(t['task_id'])] for t in tasks],
                      awq_runtime=str(a.awq_runtime) if a.awq_runtime else None,
                      max_steps=a.max_steps, shard_index=a.shard_index, num_shards=a.num_shards)
    with (a.output / f'provenance-{a.shard_index}.json').open('x') as f:
        json.dump(provenance, f, indent=2)
    policy = (PackedVisualPolicy(a.awq_runtime, steer_root=a.steer_root) if a.awq_runtime else
              VisualPolicy(a.model, steer_root=a.steer_root, clip=a.clip, quantized=a.quantized))
    browser = ScaleWoBBrowser(ScaleWoBBrowserConfig(backend='playwright', proxy_server=a.proxy,
        chrome_executable=a.chrome_executable, browser_operation_timeout_seconds=90, reset_retries=2))
    try:
        for task in tasks[a.shard_index::a.num_shards]:
            source = None
            if a.counterfactual_from:
                source = a.counterfactual_from / f'{task["env_id"]}-{task["task_id"]}'
                from repair_visual_batch import success
                if success(source):
                    continue
                if not a.capture_replay:
                    raise ValueError('Counterfactual collection requires checked replay')
            if a.initial_state_from:
                source = a.initial_state_from / f'{task["env_id"]}-{task["task_id"]}'
            directory = a.output / f'{task["env_id"]}-{task["task_id"]}'
            directory.mkdir(exist_ok=False)
            replay = VerifiedBestBuyReplay(browser) if a.capture_replay else None
            if replay:
                initial = replay.reset(task)
                if source:
                    initial = json.loads((source / 'initial-state.json').read_text())
                    replay.initial = initial
                    evidence = replay.restore(initial)
                    (directory / 'initial-restore-evidence.json').write_text(json.dumps(evidence))
                (directory / 'initial-state.json').write_text(json.dumps(initial))
            else:
                browser.reset(task)
            metadata = browser.get_task_metadata()
            if metadata is None:
                raise ValueError('Missing canonical task metadata')
            history = []
            previous_image = None
            outcome = {'success': False, 'reason': 'step_limit'}
            with (directory / 'turns.jsonl').open('x') as f:
                for step in range(a.max_steps):
                    image = browser.screenshot()
                    screenshot = (directory / f'{step:03d}.png').resolve()
                    image.save(screenshot)
                    if replay:
                        (directory / f'{step:03d}-anchor.json').write_text(json.dumps(replay.checkpoint()))
                    description = metadata.get('description') or task['description']
                    guidance = None
                    image_digest = hashlib.sha256(image.tobytes()).hexdigest()
                    if a.teacher_guidance:
                        guidance = ('Use visible controls and verify progress after each action. '
                            'If an action leaves the screen unchanged, diagnose the target or navigation '
                            'instead of repeating the same action indefinitely. Finish only after the '
                            'requested state change is visibly complete. For form entries, use the '
                            'specified value; if no value is specified, use a format-valid demo value, '
                            'never a placeholder such as new_phone_number. Do not invent UI elements.')
                        guidance += (' An option missing on the current screen does not prove the task '
                            'infeasible. Inspect relevant navigation, scrollable content and the profile '
                            'header before giving up. If a menu is unhelpful, return and try another '
                            'visible entry. Use only the screenshot and actual action outcomes as evidence.')
                        if image_digest == previous_image and history:
                            guidance += ' The screen is pixel-identical to before your last action: ' + history[-1]['raw_action']
                    generation = {'temperature': a.teacher_temperature} if a.teacher_guidance else {}
                    prediction = policy.act(description=description, image=image, history=history,
                                            params_schema=metadata.get('params'), steering=guidance,
                                            max_tokens=512 if a.teacher_guidance else 256, **generation)
                    previous_image = image_digest
                    if prediction['valid'] and not prediction['truncated']:
                        result = (replay.step if replay else browser.step)(prediction['action'])
                    else:
                        result = {'done': True, 'reward': 0, 'info': {'success': False, 'error': 'invalid_or_truncated_completion'}}
                    row = dict(task, dataset_split=a.split, artifact_role=a.artifact_role,
                               task_description=description, task_params_schema=metadata.get('params'),
                               action_history=list(history), screenshot_path=str(screenshot), assistant_turn=step,
                               source_run=str(directory.resolve()), task_key=f'{task["env_id"]}:{task["task_id"]}', policy='w4_awq_marlin' if a.awq_runtime else ('w4_fake_quant' if a.quantized else 'bf16'),
                               **prediction, result=result)
                    if guidance:
                        row['reference_guidance'] = guidance
                    f.write(json.dumps(row) + '\n')
                    f.flush()
                    print(json.dumps({'task': task['task_id'], 'step': step, 'action': prediction['raw_action'], 'result': result}), flush=True)
                    history.append({'thought': prediction['thought'], 'raw_action': prediction['raw_action']})
                    if result['done']:
                        outcome = result
                        break
            (directory / 'outcome.json').write_text(json.dumps(outcome, indent=2))
    finally:
        try:
            browser.close()
        finally:
            if isinstance(policy, PackedVisualPolicy):
                policy.close()


if __name__ == '__main__':
    main()
