"""Matched-input, fixed-output-length inference benchmark; no task rewards."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import statistics
import subprocess
import time

from PIL import Image
from collect_comparison import ComparisonPolicy
from verl.experimental.scalewob.prompt import build_prompt_messages


def main():
    p = argparse.ArgumentParser()
    p.add_argument('--model', required=True)
    p.add_argument('--screens', type=Path, required=True)
    p.add_argument('--output', type=Path, required=True)
    p.add_argument('--cuda-graphs', action='store_true')
    a = p.parse_args()
    policy = ComparisonPolicy(a.model, enforce_eager=not a.cuda_graphs,
        max_num_seqs=1 if a.cuda_graphs else 256,
        kv_cache_memory_bytes=2 * 1024**3 if a.cuda_graphs else None)
    records = []
    try:
        sources = json.loads(a.screens.read_text())
        for source in sources:
            row = json.loads(Path(source['turns']).read_text().splitlines()[source['index']])
            image = Image.open(row['screenshot_path']).convert('RGB')
            messages = build_prompt_messages(task_description=row['task_description'], screenshot=image,
                action_history=row['action_history'], action_history_len=4,
                task_params_schema=row.get('task_params_schema'))
            prompt = policy.processor.apply_chat_template(messages, tokenize=False, add_generation_prompt=True)
            request = {'prompt': prompt, 'multi_modal_data': {'image': image}}
            sampling = policy.sampling_params(temperature=0, max_tokens=64, min_tokens=64, ignore_eos=True)
            policy.engine.generate(request, sampling_params=sampling, use_tqdm=False)
            for repeat in range(3):
                gpu = subprocess.check_output(['nvidia-smi', '--query-gpu=index,uuid,utilization.gpu,memory.used',
                    '--format=csv,noheader'], text=True)
                start = time.perf_counter()
                output = policy.engine.generate(request, sampling_params=sampling, use_tqdm=False)[0]
                elapsed = time.perf_counter() - start
                tokens = len(output.outputs[0].token_ids)
                if tokens != 64:
                    raise ValueError('Fixed token budget violated')
                records.append(dict(source=source, repeat=repeat, seconds=elapsed, output_tokens=tokens,
                    prompt_tokens=len(output.prompt_token_ids), prompt_sha256=hashlib.sha256(prompt.encode()).hexdigest(),
                    image_sha256=hashlib.sha256(image.tobytes()).hexdigest(), gpu_snapshot=gpu))
    finally:
        policy.close()
    a.output.write_text(json.dumps(dict(model=a.model, physical_devices=os.environ.get('CUDA_VISIBLE_DEVICES'),
        samples=records, cuda_graphs=a.cuda_graphs, kv_cache_memory_bytes=2 * 1024**3 if a.cuda_graphs else None,
        median_seconds=statistics.median(r['seconds'] for r in records),
        note='Fixed 64-token throughput probe, warm multimedia cache, no prefix cache; shared GPU exploratory measurement.'), indent=2))


if __name__ == '__main__':
    main()
