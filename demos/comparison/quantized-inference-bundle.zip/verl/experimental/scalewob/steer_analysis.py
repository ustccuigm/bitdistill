"""Run the existing causal analyzer with a local visual teacher."""
import json
import sys
from pathlib import Path
import torch
from PIL import Image


def analyze(policy, steer_root, failed, reference, focus, previous, feedback):
    sys.path.insert(0, str(Path(steer_root)))
    import analyze_skills as core
    from common import canonical_decision, causal_action_delta

    def decision(row):
        action = row['action']
        return canonical_decision({'role': 'assistant', 'tool_calls': [{'type': 'function',
            'function': {'name': action['action'], 'arguments': json.dumps(action)}}]})

    delta = causal_action_delta(decision(failed[focus]), decision(reference[focus]), 'action_mismatch')
    evidence = {'task': failed[0]['task_description'], 'declared_first_divergence': {'assistant_turn': focus},
                'action_delta': delta, 'failure_type': delta['failure_type'],
                'failed_actions': [r['raw_action'] for r in failed],
                'verified_teacher_actions': [r['raw_action'] for r in reference],
                'teacher_final_result': reference[-1]['result'],
                'previous_steer': previous, 'retry_feedback': feedback, 'same_recovery_lineage': True}
    original = core.call_analyzer

    @torch.inference_mode()
    def local_analyzer(api_url, api_key, model, payload):
        content = [{'type': 'text', 'text': payload + '\nThe decision field must be create, revise, retain, or retire. Use revise, never revision, for decision.'
            '\nExamine retry_feedback before proposing guidance. If the previous guidance produced '
            'the same failed actions, explain why it failed and revise the actionable rule, rather '
            'than paraphrasing it. A bare instruction to avoid repetition is insufficient: identify '
            'the visible target, the expected observable change, and how to check that change. '
            'Do not invent coordinates, UI elements, or successful outcomes. Distinguish a missed '
            'click or unchanged screen from a prematurely chosen finish action using the evidence. '
            'Use the intermediate teacher screens to distinguish separate UI transitions. '
            'Do not claim one action achieves a later transition that required another action. '
            'If retry_feedback shows the proposed rule failed, identify the missing operation '
            'from the successful reference rather than repeating the same rule with synonyms.'}]
        screens = [('Causal anchor', failed[focus]),
                   ('Latest failed screen', {'screenshot_path': feedback[-1]['retry_screenshot_path']} if feedback else failed[-1])]
        # The next row is the observed screen AFTER the preceding action.
        # Show the short successful continuation, not just its final screen.
        indices = list(range(focus + 1, min(len(reference), focus + 6)))
        if len(reference) - 1 not in indices:
            indices.append(len(reference) - 1)
        for index in indices:
            screens.append((f'Teacher screen after {reference[index - 1]["raw_action"]}; '
                            f'next teacher action: {reference[index]["raw_action"]}', reference[index]))
        for label, row in screens:
            with Image.open(row['screenshot_path']) as image:
                content.extend([{'type': 'text', 'text': label}, {'type': 'image', 'image': image.convert('RGB')}])
        inputs = policy.processor.apply_chat_template(
            [{'role': 'system', 'content': [{'type': 'text', 'text': core.SYSTEM_PROMPT}]},
             {'role': 'user', 'content': content}],
            tokenize=True, add_generation_prompt=True, return_dict=True, return_tensors='pt').to(policy.device)
        if inputs['input_ids'].shape[1] + 2048 > 32768:
            raise ValueError('Causal analysis exceeds the context limit')
        output = policy.model.generate(**inputs, max_new_tokens=2048, do_sample=False)
        suffix = output[0, inputs['input_ids'].shape[1]:]
        if len(suffix) == 2048 and suffix[-1].item() != policy.processor.tokenizer.eos_token_id:
            raise ValueError('Causal analysis was truncated')
        return core.extract_object(policy.processor.tokenizer.decode(suffix, skip_special_tokens=True))

    try:
        core.call_analyzer = local_analyzer
        result = core.grounded_analysis('local', '', 'Qwen3-VL', evidence, previous)
    finally:
        core.call_analyzer = original
    result['causal_signature'] = delta['signature']
    return result
