"""Fresh BF16 evidence from an exact student anchor; never training targets."""
import hashlib
import json

from .steer_replay import ReplayMismatch


def collect_anchor_reference(policy, browser, replay, anchor, failed, focus,
                             output, max_steps, success_check):
    output.mkdir(parents=True, exist_ok=False)
    restore = replay.restore(anchor)
    history = list(failed[focus]['action_history'])
    rows = [dict(row) for row in failed[:focus]]
    outcome = {'done': True, 'info': {'success': False, 'reason': 'step_limit'}}
    for step in range(focus, max_steps):
        image = browser.screenshot()
        if step == focus and hashlib.sha256(image.convert('RGB').tobytes()).hexdigest() != restore['image_sha256']:
            raise ReplayMismatch('Fresh teacher input changed after anchor restoration')
        screen = (output / f'{step:03d}.png').resolve()
        image.save(screen)
        # Ordinary policy invocation: no steering or changed task prompt.
        prediction = policy.act(description=failed[0]['task_description'], image=image,
                                history=history, params_schema=failed[0].get('task_params_schema'))
        if prediction['valid'] and not prediction['truncated']:
            outcome = replay.step(prediction['action'])
        else:
            outcome = {'done': True, 'info': {'success': False, 'reason': 'invalid_or_truncated_completion'}}
        row = dict(failed[0])
        for key in ('prompt_token_ids', 'completion_token_ids', 'steering_text',
                    'repair_verified', 'repair_evidence_path', 'repair_evidence_sha256'):
            row.pop(key, None)
        row.update(prediction)
        row.update(screenshot_path=str(screen), action_history=list(history), assistant_turn=step,
                   result=outcome, source_run=str(output.resolve()),
                   policy='bf16_anchor_continuation', artifact_role='teacher_evidence',
                   distill_mode='ordinary_opd')
        rows.append(row)
        history.append({'thought': prediction['thought'], 'raw_action': prediction['raw_action']})
        if outcome['done']:
            break
    verified = success_check(rows, outcome)
    (output / 'turns.jsonl').write_text(''.join(json.dumps(row) + '\n' for row in rows))
    (output / 'verification.json').write_text(json.dumps(
        dict(restore=restore, outcome=outcome, verified=verified,
             role='teacher_evidence_only', generation='fresh_from_student_anchor'), indent=2))
    return rows, outcome, verified
