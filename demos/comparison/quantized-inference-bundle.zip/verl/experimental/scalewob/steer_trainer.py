"""Adapt visual inputs without replacing SteerDistill's loss or scheduling."""
import os
import logging

import torch


def visual_trainer_class(base_trainer):
    class VisualSkillKDTrainer(base_trainer):
        def __init__(self, *args, **kwargs):
            model = kwargs.get('model')
            if model is None:
                raise ValueError('Visual learner requires an explicit model keyword')
            # Convert the actual Parameter storage before FSDP and optimizer
            # construction. Some installed Accelerate FSDP2 versions merely
            # assign a local `param = param.to(float32)`, leaving the model in
            # BF16 despite an "upcast" warning. Small Adam updates then round
            # away at every step. Forward mixed precision remains BF16.
            count = 0
            for parameter in model.parameters():
                # FSDP's outer root also owns frozen vision parameters and
                # requires uniform original dtype within its parameter group.
                # Cast those too; their requires_grad flag stays unchanged.
                if parameter.is_floating_point():
                    parameter.data = parameter.data.to(torch.float32)
                if parameter.requires_grad:
                    count += 1
            logging.getLogger(__name__).warning(
                'VISUAL_MASTER_PRECISION trainable_parameters=%d dtype=float32 forward=bf16', count)
            super().__init__(*args, **kwargs)
            self._master_precision_verified = False

        def training_step(self, model, inputs, num_items_in_batch=None):
            if not self._master_precision_verified:
                wrong = [(name, str(p.dtype)) for name, p in model.named_parameters()
                         if p.requires_grad and p.dtype != torch.float32]
                if wrong:
                    raise ValueError(f'Learner master parameters are not FP32: {wrong[:3]}')
                if self.optimizer is not None:
                    for state in self.optimizer.state.values():
                        for name in ('exp_avg', 'exp_avg_sq'):
                            value = state.get(name)
                            if value is not None and value.dtype != torch.float32:
                                raise ValueError(f'Optimizer {name} must accumulate in FP32')
                self._master_precision_verified = True
            return super().training_step(model, inputs, num_items_in_batch)

        def compute_loss(self, model, inputs, return_outputs=False, num_items_in_batch=None):
            if torch.distributed.is_initialized() and torch.distributed.get_world_size() > 1:
                if 'online_row_mask' not in inputs or os.environ.get('STEER_BACKWARD_CHUNKS', '').lower() not in {'1', 'true', 'yes'}:
                    raise ValueError('Distributed visual training requires online trajectory batches and chunked backward')
            inputs = dict(inputs)
            visual = {key: inputs[key] for key in ('pixel_values', 'image_grid_thw')}
            skill_types = inputs.pop('skill_mm_token_type_ids', None)

            def preserve_image(module, args, kwargs):
                # The upstream trainer constructs the steered branch using its
                # own input_ids/attention_mask. Supply the same screen to that
                # branch and its frozen W4 reference as to the ordinary branch.
                for key, value in visual.items():
                    kwargs.setdefault(key, value)
                if skill_types is not None:
                    kwargs.setdefault('mm_token_type_ids', skill_types)
                return args, kwargs

            handles = []
            try:
                for target in (model, self.teacher_model, self.skill_reference_model):
                    handles.append(target.register_forward_pre_hook(preserve_image, with_kwargs=True))
                return super().compute_loss(
                    model, inputs, return_outputs=return_outputs,
                    num_items_in_batch=num_items_in_batch,
                )
            finally:
                for handle in handles:
                    handle.remove()

    return VisualSkillKDTrainer
