"""Auditable target selection; raw on-policy trajectories remain untouched."""
import collections
import hashlib
from PIL import Image

from .steer_audit import verify_repair


def audit_retained(rows, discovery):
    """Reject a whole unverified retry and fall back to its original rollout.

    The rejected retry stays on disk for diagnosis. Neither its corrected action
    nor its later actions enter training. This also handles saved phases from
    before the input-image check was added to the collector.
    """
    import json
    grouped = collections.defaultdict(list)
    for row in rows:
        grouped[row['task_key']].append(row)
    accepted, rejected = [], []
    for task, trajectory in grouped.items():
        try:
            for row in trajectory:
                verify_repair(row)
        except ValueError as exc:
            first = trajectory[0]
            source = discovery / f"{first['env_id']}-{first['task_id']}" / 'turns.jsonl'
            original = [json.loads(line) for line in source.read_text().splitlines()]
            if not original or any(r['task_key'] != task or r.get('distill_mode', 'ordinary_opd') != 'ordinary_opd' for r in original):
                raise ValueError('Invalid original trajectory for rejected repair') from exc
            for row in original:
                verify_repair(row)
            rejected.append(dict(task_key=task, reason=str(exc), rejected_source=first['source_run'],
                                 fallback_source=str(source.parent)))
            accepted.extend(original)
        else:
            accepted.extend(trajectory)
    return accepted, rejected


def select_targets(rows, min_repairs=1, repeat_limit=2, min_correction_tasks=1):
    if min_repairs < 1 or repeat_limit < 1 or min_correction_tasks < 1:
        raise ValueError('Positive correction and repeat limits are required')
    kept, seen = [], collections.Counter()
    excluded = collections.Counter()
    repairs = 0
    correction_tasks = set()
    ordinary_tokens = correction_tokens = 0
    for row in rows:
        verify_repair(row)
        if not row.get('valid', False) or row.get('truncated', False):
            excluded['invalid_or_truncated'] += 1
            continue
        corrected = row.get('distill_mode', 'ordinary_opd') != 'ordinary_opd'
        with Image.open(row['screenshot_path']) as image:
            image = image.convert('RGB')
            digest = hashlib.sha256(str(image.size).encode() + image.tobytes()).hexdigest()
        key = (row['task_key'], digest, row.get('raw_action', ''))
        seen[key] += 1
        if not corrected and seen[key] > repeat_limit:
            excluded['repeated_screen_and_action'] += 1
            continue
        kept.append(row)
        repairs += int(corrected)
        if corrected:
            correction_tasks.add(row['task_key'])
            correction_tokens += len(row.get('completion_token_ids', []))
        else:
            ordinary_tokens += len(row.get('completion_token_ids', []))
    original_tasks = {r['task_key'] for r in rows}
    retained_tasks = {r['task_key'] for r in kept}
    reasons = []
    if repairs < min_repairs:
        reasons.append('insufficient_verified_corrections')
    if len(correction_tasks) < min_correction_tasks:
        reasons.append('insufficient_correction_task_coverage')
    if original_tasks != retained_tasks:
        reasons.append('task_without_valid_targets')
    return kept, dict(passed=not reasons, reasons=reasons, input_turns=len(rows),
                     retained_turns=len(kept), excluded=dict(excluded),
                     verified_correction_turns=repairs, min_repairs=min_repairs,
                     min_correction_tasks=min_correction_tasks,
                     verified_correction_tasks=sorted(correction_tasks),
                     correction_tokens=correction_tokens, ordinary_tokens=ordinary_tokens,
                     correction_token_fraction=correction_tokens / max(1, correction_tokens + ordinary_tokens),
                     excluded_fraction=sum(excluded.values()) / max(1, len(rows)),
                     original_tasks=len(original_tasks), retained_tasks=len(retained_tasks),
                     note='A passed gate permits training; it does not establish policy improvement.')
