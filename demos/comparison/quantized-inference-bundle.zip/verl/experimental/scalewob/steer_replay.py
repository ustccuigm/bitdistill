"""Fail-closed BestBuy causal-anchor replay with observable state verification.

This adapter supports the inspected BestBuy AppStore/AppRouter contract only.
Replay is accepted only when app state, storage, DOM, controls, scroll, cookies,
and screenshot match. It does not claim generic browser VM checkpoint support.
"""
import copy
import hashlib
import json


_STATE = """() => {
  if (!window.AppStore || !window.AppRouter) throw Error('Unsupported state API');
  return {
    app: JSON.parse(JSON.stringify(window.AppStore.state)),
    route: window.AppRouter.currentRoute,
    history: history.state,
    local: {...localStorage}, session: {...sessionStorage},
    dom: document.documentElement.outerHTML,
    controls: Array.from(document.querySelectorAll('input,textarea,select')).map(e =>
      ({value:e.value, checked:e.checked, selectedIndex:e.selectedIndex,
        selectionStart:e.selectionStart, selectionEnd:e.selectionEnd})),
    focus: Array.from(document.querySelectorAll('*')).indexOf(document.activeElement),
    scroll: Array.from(document.querySelectorAll('*')).map((e,i) =>
      [i,e.scrollLeft,e.scrollTop]).filter(x => x[1] || x[2]),
    windowScroll: [scrollX,scrollY]
  };
}"""


class ReplayMismatch(ValueError):
    """A counterfactual could not reproduce the required state exactly."""


class VerifiedBestBuyReplay:
    def __init__(self, browser):
        if browser.config.backend != 'playwright':
            raise ValueError('Replay requires the inspected Playwright backend')
        self.browser = browser
        self.task = None
        self.initial = None
        self.actions = []

    def _state(self):
        backend = self.browser._ensure_automation()
        def read():
            state = backend._page.evaluate(_STATE)
            state['cookies'] = backend._context.cookies()
            return state
        return self.browser._call_with_timeout(backend._run, read)

    def checkpoint(self):
        image = self.browser.screenshot()
        state = self._state()
        digest = hashlib.sha256(image.tobytes()).hexdigest()
        encoded = json.dumps(state, sort_keys=True, separators=(',', ':')).encode()
        return {'state': state, 'state_sha256': hashlib.sha256(encoded).hexdigest(),
                'image_sha256': digest, 'image_size': list(image.size),
                'task': copy.deepcopy(self.task), 'actions': copy.deepcopy(self.actions)}

    def reset(self, task):
        if task.get('env_id') != 'BestBuy':
            raise ValueError('Only BestBuy state semantics have been inspected')
        self.task = copy.deepcopy(task)
        self.actions = []
        self.browser.reset(task)
        if self.browser.get_task_metadata() is None:
            raise ValueError('Missing canonical BestBuy task')
        self.initial = self.checkpoint()
        if self.initial['state']['route'] != 'onboarding':
            raise ValueError('Expected a fresh BestBuy onboarding state')
        return self.initial

    def step(self, action):
        result = self.browser.step(action)
        if result['info'].get('invalid_action'):
            raise RuntimeError(f'Cannot replay a failed browser operation: {result}')
        if not result['done']:
            backend = self.browser._ensure_automation()
            def wait_for_save():
                # BestBuy simulates profile persistence with a one-second
                # timer. Fast replay must wait for the UI save to finish, just
                # as a real action/generation cycle does, before evaluation.
                backend._page.wait_for_function(
                    "!document.querySelector('#save-profile-btn')?.textContent.includes('Saving...')")
            self.browser._call_with_timeout(backend._run, wait_for_save)
        self.actions.append(copy.deepcopy(action))
        return result

    def restore(self, anchor):
        if self.initial is None or anchor['task'] != self.task:
            raise ValueError('Anchor belongs to another task')
        if any(a.get('action') == 'finish' for a in anchor['actions']):
            raise ValueError('Cannot restore an already terminated trajectory')
        self.browser.reset(self.task)
        if self.browser.get_task_metadata() is None:
            raise ValueError('Missing canonical BestBuy task')
        backend = self.browser._ensure_automation()
        initial = self.initial['state']
        def initialize():
            backend._context.clear_cookies()
            if initial['cookies']:
                backend._context.add_cookies(initial['cookies'])
            backend._page.evaluate("""s => {
                window.AppStore.state = structuredClone(s.app);
                window.AppRouter.navigate(s.route, s.history?.params || {}, false);
                // Navigation can update taskSignals; restore the captured initial values.
                window.AppStore.state = structuredClone(s.app);
                localStorage.clear(); sessionStorage.clear();
                for (const [k,v] of Object.entries(s.local)) localStorage.setItem(k,v);
                for (const [k,v] of Object.entries(s.session)) sessionStorage.setItem(k,v);
                history.replaceState(s.history, '', location.pathname + location.search);
            }""", initial)
        self.browser._call_with_timeout(backend._run, initialize)
        self.actions = []
        self._settled_checkpoint(self.initial, phase='initial')
        for action in anchor['actions']:
            self.browser.screenshot()  # establish coordinate conversion dimensions
            self.step(action)
        # Browser focus can differ after a delayed UI transition even when
        # replay reconstructs identical app/DOM state. Restore this captured
        # writable UI state explicitly, then verify the entire checkpoint.
        current = self._state()
        expected = anchor['state']
        if current['focus'] != expected['focus']:
            if current['dom'] != expected['dom'] or current['app'] != expected['app']:
                raise ReplayMismatch('Cannot restore focus onto a different DOM or application state')
            def restore_focus():
                backend._page.evaluate('''index => {
                    const target = document.querySelectorAll('*')[index];
                    if (!target) throw Error('Saved focus target is absent');
                    if (target === document.body) document.activeElement?.blur();
                    else target.focus({preventScroll: true});
                    if (document.activeElement !== target) throw Error('Cannot restore saved focus');
                }''', expected['focus'])
            self.browser._call_with_timeout(backend._run, restore_focus)
            self.browser._post_action_wait()
        restored = self._settled_checkpoint(anchor)
        return {'verified': True, 'method': 'bestbuy_state_checked_action_replay',
                'state_sha256': restored['state_sha256'], 'image_sha256': restored['image_sha256'],
                'prefix_length': len(self.actions)}

    def _settled_checkpoint(self, anchor, phase='causal_anchor'):
        restored = self.checkpoint()
        # Fast replay can reach the correct state before a CSS transition
        # finishes. Wait only while every captured state field remains exact;
        # the final image must still match byte for byte.
        for _ in range(8):
            if restored['state_sha256'] != anchor['state_sha256'] or restored['image_sha256'] == anchor['image_sha256']:
                break
            self.browser._post_action_wait()
            restored = self.checkpoint()
        self._assert_equal(anchor, restored, phase)
        return restored

    @staticmethod
    def _assert_equal(expected, actual, phase):
        for key in ('state_sha256', 'image_sha256', 'image_size'):
            if expected[key] != actual[key]:
                differing = [k for k in expected['state'] if expected['state'][k] != actual['state'].get(k)]
                raise ReplayMismatch(f'{phase} replay mismatch: {key}; state fields={differing}')
