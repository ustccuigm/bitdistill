"""Image-preserving batches for the existing SteerDistill trainer.

One microbatch contains one screenshot turn. Trajectory batching and token
normalization are still owned by SteerDistill's OnlineGlobalBatches.
"""
from pathlib import Path

import torch
from PIL import Image

from .prompt import build_prompt_messages
from .steer_prompt import inject_steering


class ScaleWoBSteerCollator:
    MODES = {'ordinary_opd': 0, 'skill_recovery': 1, 'teacher_rescue': 2, 'steer_forward': 3}

    def __init__(self, processor, max_length=32768, steer_root=None):
        self.processor = processor
        self.steer_root = steer_root
        self.max_length = max_length

    def _prefix(self, messages):
        return dict(self.processor.apply_chat_template(
            messages, tokenize=True, add_generation_prompt=True,
            return_dict=True, return_tensors='pt',
        ))

    def __call__(self, rows):
        if len(rows) != 1:
            raise ValueError('ScaleWoB visual microbatches require exactly one turn')
        row = rows[0]
        if row.get('dataset_split', 'train') != 'train':
            raise ValueError('Validation trajectories cannot be training targets')
        mode = row.get('distill_mode', 'ordinary_opd')
        if mode not in self.MODES:
            raise ValueError(f'Unknown distillation mode: {mode}')
        if mode != 'ordinary_opd' and row.get('repair_verified') is not True:
            raise ValueError('Repair targets require verified environment recovery')
        with Image.open(Path(row['screenshot_path'])) as source:
            image = source.convert('RGB')
        messages = build_prompt_messages(
            task_description=row['task_description'], screenshot=image,
            action_history=row.get('action_history', []), action_history_len=4,
            task_params_schema=row.get('task_params_schema'),
        )
        base = self._prefix(messages)
        skill = base
        if mode in {'skill_recovery', 'steer_forward'}:
            if not row.get('steering_text'):
                raise ValueError('Steered targets require steering_text')
            # A new prefix is tokenized with the same screenshot; image tokens
            # cannot be reconstructed using the text tokenizer alone.
            messages = inject_steering(messages, row['steering_text'], self.steer_root)
            skill = self._prefix(messages)
        sampled_prefix = skill if mode in {'skill_recovery', 'steer_forward'} else base
        if row.get('prompt_token_ids') is not None and sampled_prefix['input_ids'][0].tolist() != row['prompt_token_ids']:
            raise ValueError('Training prompt tokens differ from the actual sampling context')
        # vLLM returns the actual sampled suffix IDs.  Do not re-tokenize that
        # suffix from decoded text: a small number of valid token sequences are
        # non-bijective under decode -> encode (for example, adjacent byte or
        # special-token boundaries).  Re-tokenizing would either reject a real
        # sample or silently train on different tokens.  We instead use the
        # stored IDs after proving that this tokenizer decodes them to precisely
        # the recorded completion text.
        sampled_completion = row.get('completion_token_ids')
        if sampled_completion is None:
            completion = self.processor.tokenizer.encode(row['completion'], add_special_tokens=False)
        else:
            if not isinstance(sampled_completion, list) or not all(isinstance(token, int) for token in sampled_completion):
                raise ValueError('Stored completion tokens must be a list of integer IDs')
            vocab_size = len(self.processor.tokenizer)
            if any(token < 0 or token >= vocab_size for token in sampled_completion):
                raise ValueError('Stored completion token is outside the collection tokenizer vocabulary')
            if self.processor.tokenizer.decode(sampled_completion, skip_special_tokens=False) != row['completion']:
                raise ValueError('Stored completion text differs from the sampled token IDs')
            completion = sampled_completion
        if not completion:
            raise ValueError('Empty completion')
        labels = list(completion)
        if mode == 'steer_forward':
            mask = row.get('decision_token_mask')
            if not isinstance(mask, list) or len(mask) != len(completion) or not any(mask):
                raise ValueError('Steer targets require an aligned nonempty decision mask')
            labels = [token if active else -100 for token, active in zip(completion, mask)]

        def append(prefix):
            ids = prefix['input_ids']
            n = ids.shape[1]
            if n + len(completion) > self.max_length:
                raise ValueError('Visual prompt and full completion exceed max_length')
            output = dict(prefix)
            output['input_ids'] = torch.cat([ids, torch.tensor([completion], dtype=ids.dtype)], dim=1)
            output['attention_mask'] = torch.ones_like(output['input_ids'])
            output['labels'] = torch.tensor([[-100] * n + labels])
            if 'mm_token_type_ids' in output:
                output['mm_token_type_ids'] = torch.cat([
                    output['mm_token_type_ids'], torch.zeros((1, len(completion)), dtype=torch.long),
                ], dim=1)
            return output

        base, skill = append(base), append(skill)
        for key in ('pixel_values', 'image_grid_thw'):
            if key not in base or key not in skill or not torch.equal(base[key], skill[key]):
                raise ValueError(f'Base and steered contexts must preserve identical {key}')
        base.update(
            skill_input_ids=skill['input_ids'],
            skill_attention_mask=skill['attention_mask'],
            skill_labels=skill['labels'],
            skill_distill_modes=torch.tensor([self.MODES[mode]]),
        )
        if 'mm_token_type_ids' in skill:
            base['skill_mm_token_type_ids'] = skill['mm_token_type_ids']
        return base
