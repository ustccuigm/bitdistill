"""Use the method's original system-message injection for visual prompts."""
from functools import lru_cache
import importlib.util
import os
from pathlib import Path
import sys


@lru_cache(maxsize=4)
def _injector(root):
    source = Path(root).resolve() / 'common.py'
    if not source.is_file():
        raise FileNotFoundError(source)
    sys.path.insert(0, str(source.parent))
    spec = importlib.util.spec_from_file_location('_scalewob_method_common', source)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module.inject_skill


def inject_steering(messages, steering, steer_root=None):
    root = steer_root or os.environ.get('STEERDISTILL_ROOT')
    if root is None:
        raise ValueError('Steered visual prompts require STEERDISTILL_ROOT')
    return _injector(str(root))(messages, steering)
