"""Reconcile branch logs against the exact retained rollout tokens."""
import re


def audit_checkpoint_precision(checkpoint):
    """Check trusted, locally produced DCP metadata, including saved moments."""
    import pickle
    from collections import Counter
    from pathlib import Path
    result = {}
    for name in ('pytorch_model_fsdp_0', 'optimizer_0'):
        path = Path(checkpoint) / name / '.metadata'
        metadata = pickle.loads(path.read_bytes())
        counts = Counter(str(value.properties.dtype)
                         for value in metadata.state_dict_metadata.values()
                         if hasattr(value, 'properties'))
        if not counts or set(counts) != {'torch.float32'}:
            raise ValueError(f'{name} checkpoint is not FP32: {dict(counts)}')
        result[name] = dict(counts)
    return dict(status='passed', saved_tensor_dtypes=result)


def audit_branch_signals(rows, log):
    names = {'ordinary_opd': 'ordinary', 'skill_recovery': 'skill',
             'teacher_rescue': 'rescue', 'steer_forward': 'steer'}
    losses = {'ordinary': 'ordinary_reverse', 'skill': 'skill_forward',
              'rescue': 'rescue_forward', 'steer': 'steer_forward'}
    expected = {name: 0 for name in names.values()}
    observed = dict(expected)
    sums = {name: 0.0 for name in expected}
    for row in rows:
        name = names[row.get('distill_mode', 'ordinary_opd')]
        tokens = row['completion_token_ids']
        expected[name] += sum(bool(x) for x in row['decision_token_mask']) if name == 'steer' else len(tokens)
    for line in log.splitlines():
        if 'SKILL_OPD_SIGNAL:' not in line:
            continue
        fields = dict(re.findall(r'(\w+)=([^\s]+)', line.split('SKILL_OPD_SIGNAL:', 1)[1]))
        for name in expected:
            count = int(fields[name + '_tokens'])
            observed[name] += count
            sums[name] += float(fields[losses[name]]) * count
    if observed != expected:
        raise ValueError(f'Training branch token coverage mismatch: expected={expected}, observed={observed}')
    total = sum(observed.values())
    if not total:
        raise ValueError('No training tokens')
    import math
    if not all(math.isfinite(value) and value >= -1e-5 for value in sums.values()):
        raise ValueError('Invalid branch KL signal')
    return dict(status='passed', expected_tokens=expected, observed_tokens=observed,
                token_weighted_loss=sum(sums.values()) / total,
                branch_mean_kl={name: sums[name] / max(1, observed[name]) for name in expected},
                branch_loss_contribution={name: sums[name] / total for name in expected},
                note='Coverage and objective audit; does not establish policy improvement or gradient direction.')
