"""Deterministic, split-preserving task scheduling for full ScaleWoB runs."""
import random


def task_key(task):
    return task['env_id'], str(task['task_id'])


def epoch_batches(tasks, batch_size=16, seed=0, epoch=0):
    if batch_size < 1 or not tasks:
        raise ValueError('Require tasks and a positive batch size')
    keys = [task_key(t) for t in tasks]
    if len(set(keys)) != len(keys):
        raise ValueError('Duplicate task identities')
    shuffled = list(tasks)
    random.Random(seed + epoch).shuffle(shuffled)
    return [shuffled[i:i + batch_size] for i in range(0, len(shuffled), batch_size)]


def select_tasks(tasks, env_id, count, task_keys=None):
    selected = [t for t in tasks if env_id == '*' or t['env_id'] == env_id]
    if task_keys is not None:
        requested = [tuple(map(str, key)) for key in task_keys]
        if len(set(requested)) != len(requested):
            raise ValueError('Duplicate requested tasks')
        indexed = {(str(t['env_id']), str(t['task_id'])):t for t in selected}
        missing = set(requested) - indexed.keys()
        if missing:
            raise ValueError(f'Tasks absent from selected split/environment: {sorted(missing)}')
        selected = [indexed[key] for key in requested]
    if count is not None:
        if count < 1 or len(selected) < count:
            raise ValueError(f'Invalid task count {count}; available {len(selected)}')
        selected = selected[:count]
    if not selected:
        raise ValueError('No tasks selected')
    return selected
