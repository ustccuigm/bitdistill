"""Qwen3-VL inference with the same language-only W4 quantizer as the learner."""
import sys
from pathlib import Path

import torch
from transformers import AutoProcessor, Qwen3VLForConditionalGeneration

from .actions import parse_action
from .prompt import build_prompt_messages
from .steer_prompt import inject_steering


class VisualPolicy:
    def __init__(self, model_path, *, device='cuda:0', steer_root=None, clip=None, quantized=False):
        self.steer_root = steer_root
        self.processor = AutoProcessor.from_pretrained(model_path, local_files_only=True)
        self.model = Qwen3VLForConditionalGeneration.from_pretrained(
            model_path, dtype=torch.bfloat16, attn_implementation='sdpa', local_files_only=True,
        ).eval()
        if clip is not None or quantized:
            if steer_root is None:
                raise ValueError('SteerDistill source is required for W4 inference')
            sys.path.insert(0, str(Path(steer_root) / 'quantization'))
            from clip_utils import apply_clip, validate_clip_quantizer_metadata
            from qlinear import convertModelToQuant
            if clip is not None:
                bounds = torch.load(clip, map_location='cpu', weights_only=True)
                validate_clip_quantizer_metadata(bounds, 4, 64)
                apply_clip(self.model, bounds)
            if quantized:
                self.model, _ = convertModelToQuant(
                    self.model, quant_type='int4-asym', w_bit=4, q_group_size=64,
                )
        self.model.requires_grad_(False).to(device)
        if quantized:
            # Freeze the original fake-quant result once for inference. The
            # learner still keeps BF16 master weights and the STE quantizer.
            # This reference path uses dequantized BF16 storage, not AWQ kernels.
            from qlinear import QLinear
            with torch.no_grad():
                for module in self.model.modules():
                    if isinstance(module, QLinear):
                        module.weight.copy_(module.weight_quantizer(module.weight.to(module.compute_dtype)))
                        module.weight_quantizer = torch.nn.Identity()
        self.device = device

    @torch.inference_mode()
    def act(self, *, description, image, history, params_schema=None, steering=None, max_tokens=256, temperature=0.0):
        messages = build_prompt_messages(
            task_description=description, screenshot=image, action_history=history,
            action_history_len=4, task_params_schema=params_schema,
        )
        if steering:
            messages = inject_steering(messages, steering, self.steer_root)
        inputs = self.processor.apply_chat_template(
            messages, tokenize=True, add_generation_prompt=True, return_dict=True, return_tensors='pt',
        ).to(self.device)
        generation = dict(do_sample=temperature > 0)
        if temperature > 0:
            generation.update(temperature=temperature, top_p=0.95)
        output = self.model.generate(**inputs, max_new_tokens=max_tokens, **generation)
        ids = output[0, inputs['input_ids'].shape[1]:].tolist()
        # Retain the exact sampled token suffix, including EOS, for distillation.
        text = self.processor.tokenizer.decode(ids, skip_special_tokens=False)
        parsed = parse_action(self.processor.tokenizer.decode(ids, skip_special_tokens=True))
        eos = self.model.generation_config.eos_token_id
        eos_ids = set(eos if isinstance(eos, list) else [eos])
        return {'completion': text, 'completion_token_ids': ids,
                'prompt_token_ids': inputs['input_ids'][0].tolist(),
                'action': parsed.action, 'valid': bool(parsed.is_action_valid),
                'thought': parsed.thought, 'raw_action': parsed.raw_action,
                'truncated': len(ids) >= max_tokens and (not ids or ids[-1] not in eos_ids)}


class PackedVisualPolicy:
    """Inference through the exported AWQ-Marlin checkpoint, with exact tokens."""
    def __init__(self, runtime_path, *, max_model_len=4096, memory_fraction=0.45, steer_root=None):
        self.steer_root = steer_root
        import json
        from vllm import LLM, SamplingParams
        config = json.loads((Path(runtime_path) / 'quant_config.json').read_text())
        if config.get('w_bit') != 4 or config.get('q_group_size') != 64:
            raise ValueError('This runtime requires the original INT4/g64 export')
        text_config = json.loads((Path(runtime_path) / 'config.json').read_text())['text_config']
        if 'rope_parameters' in text_config and 'rope_scaling' not in text_config:
            raise ValueError('Re-export with the visual adapter: vLLM requires legacy mRoPE configuration')
        self.processor = AutoProcessor.from_pretrained(runtime_path, local_files_only=True)
        self.engine = LLM(model=str(runtime_path), quantization='awq_marlin', dtype='bfloat16',
                          tensor_parallel_size=1, max_model_len=max_model_len,
                          gpu_memory_utilization=memory_fraction, enforce_eager=True,
                          limit_mm_per_prompt={'image': 1}, mm_processor_kwargs={'max_pixels': 1048576})
        self.sampling_params = SamplingParams

    def act(self, *, description, image, history, params_schema=None, steering=None, max_tokens=256,
            temperature=0.0, seed=None):
        messages = build_prompt_messages(task_description=description, screenshot=image,
            action_history=history, action_history_len=4, task_params_schema=params_schema)
        if steering:
            messages = inject_steering(messages, steering, self.steer_root)
        prompt = self.processor.apply_chat_template(messages, tokenize=False, add_generation_prompt=True)
        sampling = self.sampling_params(temperature=temperature, seed=seed,
            top_p=0.95 if temperature > 0 else 1.0, max_tokens=max_tokens, skip_special_tokens=False)
        request = self.engine.generate({'prompt': prompt, 'multi_modal_data': {'image': image}},
                                       sampling_params=sampling, use_tqdm=False)[0]
        output = request.outputs[0]
        ids = list(output.token_ids)
        text = self.processor.tokenizer.decode(ids, skip_special_tokens=False)
        parsed = parse_action(self.processor.tokenizer.decode(ids, skip_special_tokens=True))
        return {'completion': text, 'completion_token_ids': ids,
                'prompt_token_ids': list(request.prompt_token_ids), 'action': parsed.action,
                'valid': bool(parsed.is_action_valid), 'thought': parsed.thought,
                'raw_action': parsed.raw_action, 'truncated': output.finish_reason == 'length',
                'sampling_temperature': temperature, 'sampling_seed': seed}

    def close(self):
        # Explicit cleanup is required on browser exceptions: multiprocessing
        # may otherwise wait for EngineCore indefinitely during interpreter exit.
        self.engine.llm_engine.engine_core.shutdown()
