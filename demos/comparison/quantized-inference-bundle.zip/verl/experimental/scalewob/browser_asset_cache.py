"""Pin original image response bytes across browser workers and replays."""
import fcntl
import hashlib
import json
from pathlib import Path


class UncacheableImageResponse(ValueError):
    def __init__(self, response, url):
        self.response = response
        super().__init__(f'Cannot pin image response: {response.status} {url}')


def cached_image(directory, url, fetch):
    root = Path(directory)
    root.mkdir(parents=True, exist_ok=True)
    key = hashlib.sha256(url.encode()).hexdigest()
    body_path, meta_path = root / (key + '.bin'), root / (key + '.json')
    with (root / (key + '.lock')).open('a') as lock:
        fcntl.flock(lock, fcntl.LOCK_EX)
        if meta_path.exists():
            meta = json.loads(meta_path.read_text())
            body = body_path.read_bytes()
            if meta['url'] != url or hashlib.sha256(body).hexdigest() != meta['sha256']:
                raise ValueError('Pinned browser image checksum mismatch')
            return body, meta['content_type']
        response = fetch()
        mime = response.headers.get('content-type', '').split(';')[0]
        if response.status != 200 or not mime.startswith('image/'):
            raise UncacheableImageResponse(response, url)
        body = response.body()
        if not body:
            raise ValueError('Cannot pin an empty image')
        meta = dict(url=url, content_type=mime, sha256=hashlib.sha256(body).hexdigest())
        temporary = root / (key + '.tmp')
        temporary.write_bytes(body)
        temporary.replace(body_path)
        temporary.write_text(json.dumps(meta))
        temporary.replace(meta_path)
        return body, mime
