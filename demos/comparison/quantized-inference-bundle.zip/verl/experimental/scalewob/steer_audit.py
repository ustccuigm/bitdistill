"""Require actual restore and environment-verifier evidence for repair rows."""
import hashlib
import json
from pathlib import Path
from PIL import Image


def verify_repair(row):
    if row.get('artifact_role', 'rollout') != 'rollout':
        raise ValueError('Demo evaluation trajectories cannot be training targets')
    if row.get('dataset_split', 'train') != 'train':
        raise ValueError('Validation trajectories cannot be training targets')
    if row.get('distill_mode', 'ordinary_opd') == 'ordinary_opd':
        return
    if row.get('repair_verified') is not True:
        raise ValueError('Repair was not accepted')
    path = row.get('repair_evidence_path')
    if not path or not row.get('repair_evidence_sha256'):
        raise ValueError('A repair_verified flag is insufficient without verifier evidence')
    raw = Path(path).read_bytes()
    if hashlib.sha256(raw).hexdigest() != row['repair_evidence_sha256']:
        raise ValueError('Repair evidence hash mismatch')
    proof = json.loads(raw)
    if proof.get('accepted') is not True or proof.get('restore', {}).get('verified') is not True:
        raise ValueError('Repair lacks verified state recovery')
    if proof.get('outcome', {}).get('info', {}).get('success') is not True:
        raise ValueError('Environment rejected the repaired trajectory')
    with Image.open(row['screenshot_path']) as image:
        digest = hashlib.sha256(image.convert('RGB').tobytes()).hexdigest()
    if digest != proof['restore']['image_sha256']:
        raise ValueError('Repair screenshot differs from the verified causal anchor')
