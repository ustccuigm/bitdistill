"""Bound subprocess lifetime and clean up only descendants owned by this run."""
import subprocess
import time
import psutil


def run_guarded(command, *, cwd, env, log_path, timeout=3600, idle_timeout=600):
    with log_path.open('w') as stream:
        process = subprocess.Popen(command, cwd=cwd, env=env, stdout=stream,
                                   stderr=subprocess.STDOUT, start_new_session=True)
        root = psutil.Process(process.pid)
        owned = {}
        start = changed = time.monotonic()
        size = 0
        try:
            while process.poll() is None:
                for child in root.children(recursive=True):
                    owned[(child.pid, child.create_time())] = child
                current = log_path.stat().st_size
                if current != size:
                    changed, size = time.monotonic(), current
                if time.monotonic() - start > timeout or time.monotonic() - changed > idle_timeout:
                    raise subprocess.TimeoutExpired(command, timeout)
                time.sleep(1)
            if process.returncode:
                raise subprocess.CalledProcessError(process.returncode, command)
        finally:
            # psutil checks process identity (including creation time), avoiding
            # accidental signals to a recycled PID or unrelated GPU job.
            targets = list(owned.values()) + [root]
            for child in reversed(targets):
                try:
                    child.terminate()
                except psutil.NoSuchProcess:
                    pass
            _, alive = psutil.wait_procs(targets, timeout=5)
            for child in alive:
                try:
                    child.kill()
                except psutil.NoSuchProcess:
                    pass
            process.wait()
