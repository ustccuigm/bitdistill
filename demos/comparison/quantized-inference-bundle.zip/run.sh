#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
export PYTHONPATH="$PWD${PYTHONPATH:+:$PYTHONPATH}"
export VLLM_WORKER_MULTIPROC_METHOD=spawn
export HF_HOME="${QUANT_CACHE_DIR:?Set QUANT_CACHE_DIR on a large disk}/huggingface"
export VLLM_CACHE_ROOT="$QUANT_CACHE_DIR/vllm"
export TORCHINDUCTOR_CACHE_DIR="$QUANT_CACHE_DIR/torch-inductor"
export TMPDIR="$QUANT_CACHE_DIR/tmp"
mkdir -p "$TMPDIR"
exec "${PYTHON_BIN:-python3}" examples/scalewob/infer_quantized_student.py "$@"
